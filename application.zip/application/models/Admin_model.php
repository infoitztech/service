<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
date_default_timezone_set('Asia/Kolkata');
class Admin_model extends CI_Model
{
    public function loginAuthentication($username, $password)
    {
        $query = $this->db->get_where('admin', array('username'=>$username, 'password'=>md5($password)));
        return $query->row_array();
    }

    public function adminLoginLog($user_id)
    {
        $admin_data = array(
            'message'=>"Admin Login",
            'user_id'=>$user_id,
            'ip_address'=>$this->input->ip_address(),
            'platform'=>$this->agent->platform(),
            'browser'=> $this->agent->browser(),
            'browser_version'=>$this->agent->version(),
            'time'=>date("h:i:sa"),
            'created_date'=>date("d-m-Y h:i:sa")
        );
        $inserted =  $this->db->insert('admin_log',$admin_data);
        return $inserted;
    }
 public function getnotification()
    {
        $query = $this->db->get_where('notification', array('name'=>'notification'));
        return $query->row_array();
    }
    public function admin($username)
    {
        $query = $this->db->get_where('admin', array('username'=>$username));
        return $query->row_array();
    }

    public function userscount($admin)
    {
        $query=$this->db->query("select count(user_id) as users from user where admin='$admin'");
        return $query->result();
    }

    
    
    public function studentcount($admin)
    {
        $query=$this->db->query("select count(id) as users from student where admin='$admin'");
        return $query->result();
    }

    public function coinscount($admin)
    {
        $query=$this->db->query("select coins as coins from admin where id='$admin'");
        return $query->result();
    }

    public function checkoldpassword($username, $old_password)
    {
        $query = $this->db->get_where('admin', array('username'=>$username, 'password'=>md5($old_password)));
        return $query->row_array();
    }

    public function changepasswordAth($user_id, $new_password)
    {
        $updated_data = array(
            'password' => md5($new_password),
            'modification_date'=>date("d-m-Y h:i:sa")
         );
        $this->db->where('id', $user_id);
        $updated = $this->db->update('admin',$updated_data);

        $admin_data = array(
            'message'=>"Password Changed by Admin",
            'user_id'=>$user_id,
            'ip_address'=>$this->input->ip_address(),
            'platform'=>$this->agent->platform(),
            'browser'=> $this->agent->browser(),
            'browser_version'=>$this->agent->version(),
            'time'=>date("h:i:sa"),
            'created_date'=>date("d-m-Y h:i:sa")
        );
        $inserted =  $this->db->insert('admin_log',$admin_data);

        return $updated;
    }

    public function updateprofile($user_id, $name, $email, $phone, $upload_file)
    {
        $query_status = FALSE;
        $updated_data = array(
            'name' => $name,
            'email' => $email,
            'contact' => $phone,
            'profile' => $upload_file,
            'modification_date' =>date("d-m-Y h:i:sa")
            );
        $this->db->where('id', $user_id);
        $task_status_updated = $this->db->update('admin',$updated_data); 

        if($task_status_updated == TRUE)
        {
            $admin_data = array(
                'message'=>"Profile has been Updated by Admin",
                'user_id'=>$user_id,
                'ip_address'=>$this->input->ip_address(),
                'platform'=>$this->agent->platform(),
                'browser'=> $this->agent->browser(),
                'browser_version'=>$this->agent->version(),
                'time'=>date("h:i:sa"),
                'created_date'=>date("d-m-Y h:i:sa")
            );
            $admin_log_data_inserted =  $this->db->insert('admin_log',$admin_data);
            $query_status = TRUE;
        }
        return $query_status;
    }
//     public function checkRetailerExist($username, $contact)
// {
//     $this->db->where('username', $username);
//     $this->db->or_where('mobile', $contact);
//     $query = $this->db->get('user');
//     return $query->row_array();
// }


    public function checkRetailerExist($username)
    {
        $query = $this->db->get_where('user', array('username'=>$username));
        return $query->row_array();
    }
    //  public function checkRetailerExist($contact)
    // {
    //     $query = $this->db->get_where('user', array('contact'=>$contact));
    //     return $query->row_array();
    // }
    public function checkEmployeeExist($username)
    {
        $query = $this->db->get_where('employee', array('username'=>$username));
        return $query->row_array();
    }

    public function createretailer($name, $contact, $email, $username, $password, $profile, $user_id)
    // public function createretailer($name, $contact, $email, $username, $password, $profile, $state, $pin_code, $user_id)

    {
       $user_data = array(
    'name'=>$name,
    'contact'=>$contact,
    'email'=>$email,
    'profile'=>$profile,
    'status'=> '1',
    'username'=>$username,
    'password'=>md5($password),
    'admin'=>$user_id,
    'state'=>$state,
    'pin_code'=>$pin_code,
    'created_at'=>date("d-m-Y h:i:sa")
);

        // $user_data = array(
        //     'name'=>$name,
        //     'contact'=>$contact,
        //     'email'=>$email,
        //     'profile'=>$profile,
        //     'status'=> '1',
        //     'username'=>$username,
        //     'password'=>md5($password),
        //     'admin'=>$user_id,
        //     'created_at'=>date("d-m-Y h:i:sa")
        // );
        $inserted =  $this->db->insert('user',$user_data);

        $admin_data = array(
            'message'=>"New Retailer created",
            'user_id'=>$user_id,
            'ip_address'=>$this->input->ip_address(),
            'platform'=>$this->agent->platform(),
            'browser'=> $this->agent->browser(),
            'browser_version'=>$this->agent->version(),
            'time'=>date("h:i:sa"),
            'created_date'=>date("d-m-Y h:i:sa")
        );
        $inserted =  $this->db->insert('admin_log',$admin_data);
        return $inserted;
    }

    public function createemployee($name, $contact, $email, $status, $username, $password, $profile, $user_id)
    {
        $user_data = array(
            'name'=>$name,
            'contact'=>$contact,
            'email'=>$email,
            'profile'=>$profile,
            'status'=> $status,
            'username'=>$username,
            'password'=>md5($password),
            'admin'=>$user_id,
            'created_at'=>date("d-m-Y h:i:sa")
        );
        $inserted =  $this->db->insert('employee',$user_data);

        $admin_data = array(
            'message'=>"New Employee created",
            'user_id'=>$user_id,
            'ip_address'=>$this->input->ip_address(),
            'platform'=>$this->agent->platform(),
            'browser'=> $this->agent->browser(),
            'browser_version'=>$this->agent->version(),
            'time'=>date("h:i:sa"),
            'created_date'=>date("d-m-Y h:i:sa")
        );
        $inserted =  $this->db->insert('admin_log',$admin_data);
        return $inserted;
    }

    public function users($admin)
    {
        $this->db->select('user.profile as profile,  user.name as name, user.contact as contact,user.email as email, user.username as username, user.status as status, user.print_status as print_status, user.user_id as user_id, user.coins as coins');
        $this->db->from('user');
        $this->db->where('admin', $admin);
        $this->db->order_by("user.user_id", "desc");
        $query = $this->db->get();
        return $query->result_array();
    }

    public function employees($admin)
    {
        $this->db->select('employee.profile as profile,  employee.name as name, employee.contact as contact,employee.email as email, employee.username as username, employee.status as status, employee.id as user_id');
        $this->db->from('employee');
        $this->db->where('admin', $admin);
        $this->db->order_by("employee.id", "desc");
        $query = $this->db->get();
        return $query->result_array();
    }

    public function getRetailerByUserId($retailer_id)
    {
        $query = $this->db->get_where('user', array('user_id'=>$retailer_id));
        return $query->row_array();
    }

    public function deleteRetailer($retailer_id, $user_id, $username)
    {
        $this->db->where('user_id', $retailer_id);
        $this->db->delete('user');

        $admin_data = array(
            'message'=>$username." user has been deleted by Admin",
            'user_id'=>$user_id,
            'ip_address'=>$this->input->ip_address(),
            'platform'=>$this->agent->platform(),
            'browser'=> $this->agent->browser(),
            'browser_version'=>$this->agent->version(),
            'time'=>date("h:i:sa"),
            'created_date'=>date("d-m-Y h:i:sa")
        );
        $inserted =  $this->db->insert('admin_log',$admin_data);
        return $inserted;
    }

    public function changeViewStatus($status, $user_id, $admin_id)
    {
        if($status == 1)
        {
            $user_status = "Activated";
        }
        else
        {
            $user_status = "Deactivated";
        }
        $updated_data = array(
                'print_status' => $status,
                'modified_at' =>date("d-m-Y h:i:sa")
             );
        
        $this->db->where('user_id', $user_id);
        $this->db->update('user',$updated_data); 

        $admin_data = array(
            'message'=>$user_id." Retailer View has been ".$user_status." by Admin",
            'user_id'=>$admin_id,
            'ip_address'=>$this->input->ip_address(),
            'platform'=>$this->agent->platform(),
            'browser'=> $this->agent->browser(),
            'browser_version'=>$this->agent->version(),
            'time'=>date("h:i:sa"),
            'created_date'=>date("d-m-Y h:i:sa")
        );
        $inserted =  $this->db->insert('admin_log',$admin_data);
        return $inserted;
    }

    public function rechargedone($admin_id, $retailer_id, $coins)
    {
        $rechargeadded = array(
            'retailer_id'=>$retailer_id,
            'coins'=>$coins,
            'created_at'=>date("Y-m-d h:i:sa")
        );
        $inserted =  $this->db->insert('retailer_coin',$rechargeadded);

        $admin_data = array(
            'message'=>"Recharge with Id #".$retailer_id." Done Successfully",
            'user_id'=>$admin_id,
            'ip_address'=>$this->input->ip_address(),
            'platform'=>$this->agent->platform(),
            'browser'=> $this->agent->browser(),
            'browser_version'=>$this->agent->version(),
            'time'=>date("h:i:sa"),
            'created_date'=>date("d-m-Y h:i:sa")
        );
        $inserted =  $this->db->insert('admin_log',$admin_data);
        return $inserted;
    }

    public function updatecoins($retailer_id, $coins)
    {
        $this->db->set('coins', 'coins + ' . (int) $coins, FALSE);
        $this->db->where('user_id', $retailer_id);
        $task_updated = $this->db->update('user');
        return $task_updated;
    }
    
    public function updateadmincoins($admin_id, $coins)
    {
        $this->db->set('coins', 'coins - ' . (int) $coins, FALSE);
        $this->db->where('id', $admin_id);
        $task_updated = $this->db->update('admin');
        return $task_updated;
    }

    public function retailer($retailer_username)
    {
        $this->db->select('*');
        $this->db->from('user');
        $this->db->where('username', $retailer_username);
        $query = $this->db->get();
        return $query->result_array();
    }
}
?>