<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
date_default_timezone_set('Asia/Kolkata');
class RetailerApi_model extends CI_Model
{
    public function retailerLogin($username, $password)
    {
        $query = $this->db->get_where('user', array('username'=>$username, 'password'=>md5($password),'status'=>'1'));
        return $query->row_array();
    }

    public function retailerLoginLog($user_id)
    {
        $administrator_data = array(
            'message'=>"Retailer Logged in",
            'user_id'=>$user_id,
            'ip_address'=>$this->input->ip_address(),
            'platform'=>$this->agent->platform(),
            'browser'=> $this->agent->browser(),
            'browser_version'=>$this->agent->version(),
            'time'=>date("h:i:sa"),
            'created_date'=>date("d-m-Y h:i:sa")
        );
        $inserted =  $this->db->insert('user_log',$administrator_data);
        return $inserted;
    }

    public function checkstudentexist($name)
    {
        $query = $this->db->get_where('student', array('name'=>$name));
        return $query->row_array();
    }
    
    public function getavailablecoins($retailer_id)
    {
        $query_data = $this->db->get_where('user', array('user_id'=>$retailer_id));
        $retailer_data = $query_data->row_array();
        if($retailer_data)
        {
            return $coins = $retailer_data['coins'];
        }
        else
        {
            return 0;
        }
        
    }
        

    public function addstudent($retailer_id, $vle_id, $name, $contact, $dob, $purpose, $adhaar_no, $type, $remark1, $filename1, $filename2, $filename3, $filename4, $filename5, $admin_id)
    {
        $coins = $this->getavailablecoins($retailer_id);
        if($coins >=1)
        {
            $student_data = array(
                'name'=>$name,
                'retailer_id'=>$retailer_id,
                'vle_id'=>$vle_id,
                'contact'=>$contact,
                'dob'=>$dob,
                'purpose'=>$purpose,
                'adhaar_no'=>$adhaar_no,
                'type'=>$type,
                'remark1'=>$remark1,
                'photo1'=>$filename1,
                'photo2'=> $filename2,
                'photo3'=>$filename3,
                'photo4'=>$filename4,
                'photo5'=>$filename5,
                'admin'=>$admin_id,
                'created_at'=>date("d-m-Y h:i:sa"),
                'entry_dae'=>date("Y-m-d h:i:sa")
            );
            $inserted =  $this->db->insert('student',$student_data);
            if($inserted)
            {
                $this->db->set('coins', 'coins - ' . (int) '1', FALSE);
                $this->db->where('user_id', $retailer_id);
                $task_updated = $this->db->update('user');
            }    
            return $task_updated;
            
        }
        
    }

    public function studentcreatedLog($retailer_id, $student)
    {
        $administrator_data = array(
            'message'=>"Student ".$student." Created",
            'user_id'=>$retailer_id,
            'ip_address'=>$this->input->ip_address(),
            'platform'=>$this->agent->platform(),
            'browser'=> $this->agent->browser(),
            'browser_version'=>$this->agent->version(),
            'time'=>date("h:i:sa"),
            'created_date'=>date("d-m-Y h:i:sa")
        );
        $inserted =  $this->db->insert('user_log',$administrator_data);
        return $inserted;
    }

    public function getRetailerDetails($retailer_id)
    {
        $query = $this->db->get_where('user', array('user_id'=>$retailer_id));
        return $query->row_array();
    }

    public function getMemberRecord($retailer_id)
    {
        $this->db->select('*');
        $this->db->from('student');
        $this->db->where('retailer_id', $retailer_id);
        $this->db->where('visible_to_retailer', 1);
        $this->db->order_by("id", "desc");
        $query = $this->db->get();
        return $query->result_array();
    }
    
    public function getnotification()
    {
        $query = $this->db->get_where('notification', array('name'=>'notification'));
        return $query->row_array();
    }


    
    public function sendmessage($message, $retailer)
    {
        $data = array(
            'retailer'=>$retailer,
            'message'=>$message,
            'created_at'=>date("y-m-d h:i:sa")
        );
        $inserted =  $this->db->insert('message',$data);
        return $inserted;
    }
    
    public function checkrefexist($vle_id)
    {
        $query = $this->db->get_where('student', array('vle_id'=>$vle_id));
        return $query->row_array();
    }
    
    public function savefingers($retailer_id, $vle_id, $filename)
    {
        $data = array(
            'retailer_id'=>$retailer_id,
            'ref_id'=>$vle_id,
            'finger_print'=>$filename,
            'created_date'=>date("d-m-Y h:i:sa")
        );
        $inserted =  $this->db->insert('temp_finger',$data);
        return $inserted;
    }
    
    public function addedfingerslist($vle_id, $retailer_id)
    {
        $this->db->select('*');
        $this->db->from('temp_finger');
        $this->db->where('retailer_id', $retailer_id);
        $this->db->where('ref_id', $vle_id);
        $this->db->order_by("id", "asc");
        $query = $this->db->get();
        return $query->result_array();
    }
    
    public function getsavedfingers($vle_id, $retailer_id)
    {
        $this->db->select('*');
        $this->db->from('temp_finger');
        $this->db->where('ref_id', $vle_id);
        $this->db->where('retailer_id', $retailer_id);
        $this->db->order_by("id", "desc");
        $query = $this->db->get();
        return $query->result_array();
    }
    
    public function profile($user_id)
    {
        $query = $this->db->get_where('user', array('user_id'=>$user_id));
        return $query->row_array();
    }
    
    public function updateremarks($member_id, $remark2, $employee_id, $status)
    {
        $employee = $employee_id;
        $task_updated = true;
        if($status == "Cancelled")
        {
            $query = $this->db->get_where('student', array('id'=>$member_id));
            $studentfinger =  $query->row_array();
            $retailer_id = $studentfinger['retailer_id'];
            $coins = 1;
            $this->db->set('coins', 'coins+' . (int) $coins, FALSE);
            $this->db->where('user_id', $retailer_id);
            $task_updated = $this->db->update('user');
        }
        
        if($task_updated)
        {
            $updated_data = array(
                'remark2'=>$remark2,
                'status'=>$status,
                'employee_name'=>$employee,
                'employee_show'=>'1',
                'employee_remark_date'=>date("Y-m-d h:i:sa")
             );
            $this->db->where('vle_id', $member_id);
            return $updated = $this->db->update('student',$updated_data);
        }
    }
    
}
?>