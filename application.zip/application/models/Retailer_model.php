<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
date_default_timezone_set('Asia/Kolkata');
class Retailer_model extends CI_Model
{
    public function loginAuthentication($okt_username, $okt_password)
    {
        $query = $this->db->get_where('user', array('username'=>$okt_username, 'password'=>md5($okt_password)));
        return $query->row_array();
    }

    public function logineAuthentication($okt_username, $okt_password)
    {
        $query = $this->db->get_where('employee', array('username'=>$okt_username, 'password'=>md5($okt_password)));
        return $query->row_array();
    }

    public function retailerLoginLog($user_id)
    {
        $administrator_data = array(
            'message'=>"Retailer Logged in",
            'user_id'=>$user_id,
            'ip_address'=>$this->input->ip_address(),
            'platform'=>$this->agent->platform(),
            'browser'=> $this->agent->browser(),
            'browser_version'=>$this->agent->version(),
            'time'=>date("h:i:sa"),
            'created_date'=>date("d-m-Y h:i:sa")
        );
        $inserted =  $this->db->insert('user_log',$administrator_data);
        return $inserted;
    }

    public function employeeLoginLog($user_id)
    {
        $administrator_data = array(
            'message'=>"Employee Logged in",
            'user_id'=>$user_id,
            'ip_address'=>$this->input->ip_address(),
            'platform'=>$this->agent->platform(),
            'browser'=> $this->agent->browser(),
            'browser_version'=>$this->agent->version(),
            'time'=>date("h:i:sa"),
            'created_date'=>date("d-m-Y h:i:sa")
        );
        $inserted =  $this->db->insert('employee_log',$administrator_data);
        return $inserted;
    }

    public function user($username)
    {
        $query = $this->db->get_where('user', array('username'=>$username));
        return $query->row_array();
    }

    public function employee($username)
    {
        $query = $this->db->get_where('employee', array('username'=>$username));
        return $query->row_array();
    }

    public function students($retailer_id)
    {
        $this->db->select("*");
        $this->db->where('retailer_id', $retailer_id);
        $this->db->where('visible_to_retailer', 1);
        $this->db->order_by('id', 'desc');
        $query=$this->db->get('student');
        return $result=$query->result();
    }

    public function studentsfingers($student_id)
    {
        $query = $this->db->get_where('student', array('id'=>$student_id));
        return $query->row_array();
    }

    public function checkoldpassword($username, $old_password)
    {
        $query = $this->db->get_where('user', array('username'=>$username, 'password'=>md5($old_password)));
        return $query->row_array();
    }

    public function checkoldpasswords($username, $old_password)
    {
        $query = $this->db->get_where('employee', array('username'=>$username, 'password'=>md5($old_password)));
        return $query->row_array();
    }

    public function changepasswordAth($username, $new_password)
    {
        $updated_data = array(
            'password' => md5($new_password),
            'modified_at'=>date("d-m-Y h:i:sa")
         );
        $this->db->where('username', $username);
        $updated = $this->db->update('user',$updated_data);
    }

    public function changepasswordAths($username, $new_password)
    {
        $updated_data = array(
            'password' => md5($new_password),
            'modified_at'=>date("d-m-Y h:i:sa")
         );
        $this->db->where('username', $username);
        $updated = $this->db->update('employee',$updated_data);
    }

    public function searchath($vle_id)
    {
        $this->db->select('*');
        $this->db->from('student');
        $this->db->where('vle_id', $vle_id);
        $this->db->where('employee_show!=', '1');
        $query = $this->db->get();
        return $query->result_array();
    }

    public function updateremark($remark2, $member_id, $status, $employee)
    {
        $task_updated = true;
        if($status == "Cancelled")
        {
            $query = $this->db->get_where('student', array('id'=>$member_id));
            $studentfinger =  $query->row_array();
            if(isset($studentfinger) && $studentfinger['status'] != "Cancelled")
            {
                $retailer_id = $studentfinger['retailer_id'];
                $coins = 1;
                $this->db->set('coins', 'coins+' . (int) $coins, FALSE);
                $this->db->where('user_id', $retailer_id);
                $task_updated = $this->db->update('user');
            }
        }
        if($task_updated)
        {
            $updated_data = array(
                'remark2'=>$remark2,
                'status'=>$status,
                'employee_name'=>$employee,
                'employee_show'=>'1',
                'employee_remark_date'=>date("Y-m-d h:i:sa")
             );
            $this->db->where('id', $member_id);
            return $updated = $this->db->update('student',$updated_data);
        }  
    }
    
    public function coinscount($retailer_id)
    {
        $query=$this->db->query("select coins as coins from user where user_id='$retailer_id'");
        return $query->result();
    }

    public function keyverification($key, $username)
    {
        $found = false;
        $updated = false;
        $query = $this->db->get_where('user', array('activation_key'=>$key, 'username'=>$username, 'is_activated'=>0));
        $found = $query->row_array();
        if($found)
        {
            $updated_data = array(
                'is_activated'=>1,
                'modified_at'=>date("Y-m-d h:i:sa")
             );
            $this->db->where('username', $username);
            $updated = $this->db->update('user',$updated_data);
        }
        return $updated;
    }

    public function employeekeyverification($key, $username)
    {
        $found = false;
        $updated = false;
        $query = $this->db->get_where('employee', array('activation_key'=>$key, 'username'=>$username, 'is_activated'=>0));
        $found = $query->row_array();
        if($found)
        {
            $updated_data = array(
                'is_activated'=>1,
                'modified_at'=>date("Y-m-d h:i:sa")
             );
            $this->db->where('username', $username);
            $updated = $this->db->update('employee',$updated_data);
        }
        return $updated;
    }
    
    public function getemployeebyid($user_id)
    {
        $query = $this->db->get_where('employee', array('id'=>$user_id));
        return $query->row_array();
    }
    
    public function getmemberbyvleid($vle_id)
    {
         $query = $this->db->get_where('student', array('vle_id'=>$vle_id));
        return $query->row_array();
    }

    public function getChatByUserId($user_id)
    {
        $this->db->select('*');
        $this->db->from('chat');
        $this->db->or_where("send_id", $user_id);
        $this->db->or_where("receiver_id", $user_id);
      //  $this->db->order_by("created_date", "desc");
        $query = $this->db->get();
        return $result = $query->result_array();
    }
    
    public function sendmessage($user_id, $text_message)
    {
        $message_data = array(
            'send_id'=>$user_id,
            'receiver_id'=>'admin',
            'chat_content'=>$text_message,
            'content_type'=>1,
            'created_date'=>date("d-m-y H:i:s")
        );
        $inserted =  $this->db->insert('chat',$message_data);
        return $inserted;
    }
    
    

}
?>