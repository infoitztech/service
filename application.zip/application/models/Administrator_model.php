<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
date_default_timezone_set('Asia/Kolkata');
class Administrator_model extends CI_Model
{
    public function loginAuthentication($okt_username, $okt_password)
    {
        $query = $this->db->get_where('administrator', array('username'=>$okt_username, 'password'=>md5($okt_password)));
        return $query->row_array();
    }
    
    public function memeberdetails($member_id)
    {
        $query = $this->db->get_where('student', array('id'=>$member_id));
        return $query->row_array();
    }

    public function getretailerdatta($id)
    {
        $query = $this->db->get_where('user', array('user_id'=>$id));
        return $query->row_array();
    }
    
    public function getadministratorbyemail($email)
    {
        $query = $this->db->get_where('administrator', array('email'=>$email));
        return $query->row_array();
    }

    public function administratorLoginLog($user_id)
    {
        $administrator_data = array(
            'message'=>"Administrator Login",
            'user_id'=>$user_id,
            'ip_address'=>$this->input->ip_address(),
            'platform'=>$this->agent->platform(),
            'browser'=> $this->agent->browser(),
            'browser_version'=>$this->agent->version(),
            'time'=>date("h:i:sa"),
            'created_date'=>date("d-m-Y h:i:sa")
        );
        $inserted =  $this->db->insert('administrator_log',$administrator_data);
        return $inserted;
    }

    public function administrator($username)
    {
        $this->db->select('administrator.profile as profile, administrator.email as email, administrator.contact as contact, role.role as role, administrator.name as name, administrator.username as username, administrator.status as status, administrator.user_id as user_id, administrator.created_at as created_at, role.id as role_id');
        $this->db->from('administrator');
        $this->db->join('role', 'administrator.role = role.id','left');
        $this->db->where('username', $username);
        $query = $this->db->get();
        return $query->result_array();
    }

    public function administratorlog()
    {
        $this->db->select('administrator.username as username, administrator_log.message as message, administrator_log.ip_address as ip_address, administrator_log.platform as platform, administrator_log.browser as browser, administrator_log.browser_version as browser_version, administrator_log.created_date as created_date');
        $this->db->from('administrator_log');
        $this->db->join('administrator', 'administrator_log.user_id = administrator.user_id','left');
        $this->db->order_by("administrator_log.id", "desc");
        $query = $this->db->get();
        return $query->result_array();
    }

    public function userlog()
    {
        $this->db->select('user.username as username, user_log.message as message, user_log.ip_address as ip_address, user_log.platform as platform, user_log.browser as browser, user_log.browser_version as browser_version, user_log.created_date as created_date');
        $this->db->from('user_log');
        $this->db->join('user', 'user_log.user_id = user.user_id','left');
        $this->db->order_by("user_log.id", "desc");
        $query = $this->db->get();
        return $query->result_array();
    }

    public function employeelog()
    {
        $this->db->select('employee.username as username, employee_log.message as message, employee_log.ip_address as ip_address, employee_log.platform as platform, employee_log.browser as browser, employee_log.browser_version as browser_version, employee_log.created_date as created_date');
        $this->db->from('employee_log');
        $this->db->join('employee', 'employee_log.user_id = employee.id','left');
        $this->db->order_by("employee_log.id", "desc");
        $query = $this->db->get();
        return $query->result_array();
    }

    public function adminlog()
    {
        $this->db->select('admin.username as username, admin_log.message as message, admin_log.ip_address as ip_address, admin_log.platform as platform, admin_log.browser as browser, admin_log.browser_version as browser_version, admin_log.created_date as created_date');
        $this->db->from('admin_log');
        $this->db->join('admin', 'admin_log.user_id = admin.id','left');
        $this->db->order_by("admin_log.id", "desc");
        $query = $this->db->get();
        return $query->result_array();
    }

    public function role()
    {
        $this->db->select('*');
        $this->db->from('role');
        $query = $this->db->get();
        return $result = $query->result_array();
    }

    public function administrators()
    {
        $this->db->select('administrator.profile as profile, role.role as role, administrator.name as name, administrator.username as username, administrator.status as status, administrator.user_id as user_id');
        $this->db->from('administrator');
        $this->db->join('role', 'administrator.role = role.id','left');
        $this->db->order_by("administrator.user_id", "asc");
        $query = $this->db->get();
        return $query->result_array();
    }

    public function users()
    {
        $this->db->select('user.profile as profile,  user.name as name, user.username as username,user.password as password,user.contact as contact, user.status as status, user.print_status as print_status, user.user_id as user_id, user.coins, admin.username as admin_user');
        $this->db->from('user');
        $this->db->join('admin', 'user.admin = admin.id','left');
        $this->db->order_by("user.user_id", "desc");
        $query = $this->db->get();
        return $query->result_array();
    }
    
    public function members()
    {
        $this->db->select('student.vle_id as ref_id, student.name as member_name, student.type as type,student.remark2 as remark2, student.purpose as purpose,student.status as status,admin.username as username,student.created_at as created_date,student.id as id, user.username as retailer');
        $this->db->from('student');
        $this->db->join('admin', 'student.admin = admin.id');
        $this->db->join('user', 'student.retailer_id = user.user_id');
        $this->db->order_by("student.id", "desc");
        $query = $this->db->get();
        return $query->result_array();
    }

    public function filtermembers($type, $status, $admin, $retailer, $employee, $start_date, $end_date, $remark_start_date, $remark_end_date)
    {
        $data = array($type, $status, $admin, $retailer, $start_date, $end_date, $remark_start_date, $remark_end_date);
      // echo "<pre>"; print_r($data); die();
        $this->db->select('student.vle_id as ref_id, student.name as member_name, student.type as type,student.remark2 as remark2, student.purpose as purpose,student.status as status,admin.username as username,student.employee_remark_date as remark_date,student.entry_dae as created_date,student.id as id, user.username as retailer, student.employee_name as employee_name');
        $this->db->from('student');
        $this->db->join('admin', 'student.admin = admin.id');
        $this->db->join('user', 'student.retailer_id = user.user_id');
        if($type)
        {
            $this->db->where('student.type', $type);
        }
        if($status)
        {
            if($status == "Pending")
            {
                 $this->db->where('student.status', "");
            }
            else
            {
                $this->db->where('student.status', $status);
            }
        }
        if($admin)
        {
            $this->db->where('student.admin', $admin);
        }
        if($retailer)
        {
            $this->db->where('student.retailer_id', $retailer);
        }
        if($employee)
        {
            $this->db->where('student.employee_name', $employee);
        }
        if($start_date!="" && $end_date !="")
        {
            $from = date_format(date_create($start_date),"Y-m-d h:i:sa");
            $to = date_format(date_create($end_date),"Y-m-d h:i:sa");
        //   echo "<pre>";
        //     print_r(array($from, $to)); die();
            $this->db->where('student.entry_dae >=', $from);
            $this->db->where('student.entry_dae <=', $to);
        }
        if($remark_start_date!="" && $remark_end_date !="")
        {
            $from = date_format(date_create($remark_start_date),"Y-m-d h:i:sa");
            $to = date_format(date_create($remark_end_date),"Y-m-d h:i:sa");
        //   echo "<pre>";
        //     print_r(array($from, $to)); die();
            $this->db->where('student.employee_remark_date >=', $from);
            $this->db->where('student.employee_remark_date <=', $to);
        }
        $this->db->order_by("student.id", "asc");
        $query = $this->db->get();
        
        return $query->result_array();
    }

    public function visible_to_retailer($type, $status, $admin, $retailer, $employee, $start_date, $end_date, $remark_start_date, $remark_end_date)
    {
        $this->db->select('student.vle_id as ref_id, student.name as member_name, student.type as type, student.purpose as purpose,student.status as status,admin.username as username,student.employee_remark_date as remark_date,student.entry_dae as created_date,student.id as id, user.username as retailer, student.employee_name as employee_name');
        $this->db->from('student');
        $this->db->join('admin', 'student.admin = admin.id');
        $this->db->join('user', 'student.retailer_id = user.user_id');
        if($type)
        {
            $this->db->where('student.type', $type);
        }
        if($status)
        {
            if($status == "Pending")
            {
                 $this->db->where('student.status', "");
            }
            else
            {
                $this->db->where('student.status', $status);
            }
        }
        if($admin)
        {
            $this->db->where('student.admin', $admin);
        }
        if($retailer)
        {
            $this->db->where('student.retailer_id', $retailer);
        }
        if($employee)
        {
            $this->db->where('student.employee_name', $employee);
        }
        if($start_date!="" && $end_date !="")
        {
            $from = date_format(date_create($start_date),"Y-m-d h:i:sa");
            $to = date_format(date_create($end_date),"Y-m-d h:i:sa");
            $this->db->where('student.entry_dae >=', $from);
            $this->db->where('student.entry_dae <=', $to);
        }
        if($remark_start_date!="" && $remark_end_date !="")
        {
            $from = date_format(date_create($remark_start_date),"Y-m-d h:i:sa");
            $to = date_format(date_create($remark_end_date),"Y-m-d h:i:sa");
            $this->db->where('student.employee_remark_date >=', $from);
            $this->db->where('student.employee_remark_date <=', $to);
        }
        $this->db->order_by("student.id", "desc");
        $this->db->where('student.visible_to_retailer', '1');
        $query = $this->db->get();
        return $query->result_array();
    }

    public function visible_to_employee()
    {
        $this->db->select('student.vle_id as ref_id, student.name as member_name, student.type as type, student.purpose as purpose,student.status as status,admin.username as username,student.created_at as created_date,student.id as id, user.username as retailer');
        $this->db->from('student');
        $this->db->join('admin', 'student.admin = admin.id');
        $this->db->join('user', 'student.retailer_id = user.user_id');
        $this->db->where('student.employee_show', '');
        $this->db->order_by("student.id", "desc");
        $query = $this->db->get();
        return $query->result_array();
    }
    
    
    public function employees()
    {
        $this->db->select('employee.profile as profile,  employee.name as name, employee.username as username, employee.status as status,  employee.id as user_id');
        $this->db->from('employee');
        $this->db->order_by("employee.id", "asc");
        $query = $this->db->get();
        return $query->result_array();
    }
    
    public function messages()
    {
        $this->db->select('*');
        $this->db->from('message')
         ->join('user', 'message.retailer = user.user_id');
        $this->db->order_by("message.id", "desc");
        
        $query = $this->db->get();
        return $query->result_array();
    }

    public function updateprofile($user_id, $admin_id, $name, $email, $phone, $upload_file)
    {
        $query_status = FALSE;
        $updated_data = array(
            'name' => $name,
            'email' => $email,
            'contact' => $phone,
            'profile' => $upload_file,
            'modified_at' =>date("d-m-Y h:i:sa")
            );
        $this->db->where('user_id', $admin_id);
        $task_status_updated = $this->db->update('administrator',$updated_data); 

        if($task_status_updated == TRUE)
        {
            $administrator_data = array(
                'message'=>"Profile updated",
                'user_id'=>$user_id,
                'ip_address'=>$this->input->ip_address(),
                'platform'=>$this->agent->platform(),
                'browser'=> $this->agent->browser(),
                'browser_version'=>$this->agent->version(),
                'time'=>date("h:i:sa"),
                'created_date'=>date("d-m-Y h:i:sa")
            );
            $administrator_log_data_inserted =  $this->db->insert('administrator_log',$administrator_data);
            $query_status = TRUE;
        }
        return $query_status;
    }

    public function otpupdated($email, $otp)
    {
        $query_status = FALSE;
        $updated_data = array(
            'otp' => $otp
        );
        $this->db->where('email', $email);
        $query_status = $this->db->update('administrator',$updated_data); 

        
        return $query_status;
    }
    public function otpexistance($email, $otp)
    {
        $query = $this->db->get_where('administrator', array('email'=>$email, 'otp'=>$otp));
        return $query->row_array();   
    }

    public function updatenewpassword($email, $password)
    {
        $updated_data = array(
            'password' => md5($password),
            'modified_at'=>date("d-m-Y h:i:sa")
         );
        $this->db->where('email', $email);
        $updated = $this->db->update('administrator',$updated_data);
        return $updated;        
    }
    
    public function checkoldpassword($username, $old_password)
    {
        $query = $this->db->get_where('administrator', array('username'=>$username, 'password'=>md5($old_password)));
        return $query->row_array();
    }

    public function changepasswordAth($user_id, $new_password)
    {
        $updated_data = array(
            'password' => md5($new_password),
            'modified_at'=>date("d-m-Y h:i:sa")
         );
        $this->db->where('user_id', $user_id);
        $updated = $this->db->update('administrator',$updated_data);

        $administrator_data = array(
            'message'=>"Password updated",
            'user_id'=>$user_id,
            'ip_address'=>$this->input->ip_address(),
            'platform'=>$this->agent->platform(),
            'browser'=> $this->agent->browser(),
            'browser_version'=>$this->agent->version(),
            'time'=>date("h:i:sa"),
            'created_date'=>date("d-m-Y h:i:sa")
        );
        $inserted =  $this->db->insert('administrator_log',$administrator_data);

        return $updated;
    }

    public function createRole($user_id, $role)
    {
        $role_data = array(
            'role'=>$role,
            'created_at'=>date("d-m-Y h:i:sa")
        );
        $inserted =  $this->db->insert('role',$role_data);

        $administrator_data = array(
            'message'=>"New Role created by Administrator",
            'user_id'=>$user_id,
            'ip_address'=>$this->input->ip_address(),
            'platform'=>$this->agent->platform(),
            'browser'=> $this->agent->browser(),
            'browser_version'=>$this->agent->version(),
            'time'=>date("h:i:sa"),
            'created_date'=>date("d-m-Y h:i:sa")
        );
        $inserted =  $this->db->insert('administrator_log',$administrator_data);

        return $inserted;
    }

    public function createAdministrator($name, $contact, $email, $role, $status, $username, $password, $profile, $user_id)
    {
        $administrator_data = array(
            'name'=>$name,
            'contact'=>$contact,
            'email'=>$email,
            'profile'=>$profile,
            'status'=> $status,
            'role'=>$role,
            'username'=>$username,
            'password'=>md5($password),
            'created_at'=>date("d-m-Y h:i:sa")
        );
        $inserted =  $this->db->insert('administrator',$administrator_data);

        $administrator_data = array(
            'message'=>"New Administrator created",
            'user_id'=>$user_id,
            'ip_address'=>$this->input->ip_address(),
            'platform'=>$this->agent->platform(),
            'browser'=> $this->agent->browser(),
            'browser_version'=>$this->agent->version(),
            'time'=>date("h:i:sa"),
            'created_date'=>date("d-m-Y h:i:sa")
        );
        $inserted =  $this->db->insert('administrator_log',$administrator_data);
        return $inserted;
    }

    public function checkUserExist($username)
    {
        $query = $this->db->get_where('administrator', array('username'=>$username));
        return $query->row_array();
    }

    public function getUserByUserId($user_id)
    {
        $query = $this->db->get_where('administrator', array('user_id'=>$user_id));
        return $query->row_array();
    }
    
    // public function getEmployeeByUserId($user_id)
    // {
    //     $query = $this->db->get_where('employee', array('id'=>$user_id));
    //     return $query->row_array();
    // }

    public function deleteUser($admin_id, $user_id, $username)
    {
        $this->db->where('user_id', $admin_id);
        $this->db->delete('administrator');

        $administrator_data = array(
            'message'=>$username." user has been deleted by Administrator",
            'user_id'=>$user_id,
            'ip_address'=>$this->input->ip_address(),
            'platform'=>$this->agent->platform(),
            'browser'=> $this->agent->browser(),
            'browser_version'=>$this->agent->version(),
            'time'=>date("h:i:sa"),
            'created_date'=>date("d-m-Y h:i:sa")
        );
        $inserted =  $this->db->insert('administrator_log',$administrator_data);
        return $inserted;
    }

    public function checkRetailerExist($username)
    {
        $query = $this->db->get_where('user', array('username'=>$username));
        return $query->row_array();
    }

    public function createretailer($name, $contact, $email, $status, $username, $password, $profile, $user_id, $admin)
    {
        $user_data = array(
            'name'=>$name,
            'contact'=>$contact,
            'email'=>$email,
            'profile'=>$profile,
            'status'=> $status,
            'username'=>$username,
            'admin'=>$admin,
            'password'=>md5($password),
            'created_at'=>date("d-m-Y h:i:sa")
        );
        $inserted =  $this->db->insert('user',$user_data);

        $administrator_data = array(
            'message'=>"New Retailer created",
            'user_id'=>$user_id,
            'ip_address'=>$this->input->ip_address(),
            'platform'=>$this->agent->platform(),
            'browser'=> $this->agent->browser(),
            'browser_version'=>$this->agent->version(),
            'time'=>date("h:i:sa"),
            'created_date'=>date("d-m-Y h:i:sa")
        );
        $inserted =  $this->db->insert('administrator_log',$administrator_data);
        return $inserted;
    }

    public function checkEmployeeExist($username)
    {
        $query = $this->db->get_where('employee', array('username'=>$username));
        return $query->row_array();
    }
    public function createemployee($name, $contact, $email, $status, $username, $password, $profile, $user_id)
    {
        $employee_data = array(
            'name'=>$name,
            'contact'=>$contact,
            'email'=>$email,
            'profile'=>$profile,
            'status'=> $status,
            'username'=>$username,
            'password'=>md5($password),
            'created_at'=>date("d-m-Y h:i:sa")
        );
        $inserted =  $this->db->insert('employee',$employee_data);

        $administrator_data = array(
            'message'=>"New Employee created",
            'user_id'=>$user_id,
            'ip_address'=>$this->input->ip_address(),
            'platform'=>$this->agent->platform(),
            'browser'=> $this->agent->browser(),
            'browser_version'=>$this->agent->version(),
            'time'=>date("h:i:sa"),
            'created_date'=>date("d-m-Y h:i:sa")
        );
        $inserted =  $this->db->insert('administrator_log',$administrator_data);
        return $inserted;
    }
    public function getRetailerByUserId($retailer_id)
    {
        $query = $this->db->get_where('user', array('user_id'=>$retailer_id));
        return $query->row_array();
    }
    public function getEmployeeByUserId($employee_id)
    {
        $query = $this->db->get_where('employee', array('id'=>$employee_id));
        return $query->row_array();
    }

    public function deleteRetailer($admin_id, $user_id, $username)
    {
        $this->db->where('user_id', $admin_id);
        $this->db->delete('user');

        $administrator_data = array(
            'message'=>$username." user has been deleted by Administrator",
            'user_id'=>$user_id,
            'ip_address'=>$this->input->ip_address(),
            'platform'=>$this->agent->platform(),
            'browser'=> $this->agent->browser(),
            'browser_version'=>$this->agent->version(),
            'time'=>date("h:i:sa"),
            'created_date'=>date("d-m-Y h:i:sa")
        );
        $inserted =  $this->db->insert('administrator_log',$administrator_data);
        return $inserted;
    }
    
    public function deleteStudent($student_id, $user_id)
    {
        $this->db->where('id', $student_id);
        $this->db->delete('student');

        $administrator_data = array(
            'message'=>" Student has been deleted by Administrator",
            'user_id'=>$user_id,
            'ip_address'=>$this->input->ip_address(),
            'platform'=>$this->agent->platform(),
            'browser'=> $this->agent->browser(),
            'browser_version'=>$this->agent->version(),
            'time'=>date("h:i:sa"),
            'created_date'=>date("d-m-Y h:i:sa")
        );
        $inserted =  $this->db->insert('administrator_log',$administrator_data);
        return $inserted;
    }
    

    public function changeUserStatus($status, $username )
    {
        if($status == 1)
        {
            $user_status = "Activated";
        }
        else
        {
            $user_status = "Deactivated";
        }
        $updated_data = array(
                'status' => $status,
                'modified_at' =>date("d-m-Y h:i:sa")
             );
        
        $this->db->where('username', $username);
        $this->db->update('user',$updated_data); 
        // $this->db->error()

        $administrator_data = array(
            'message'=>"#".$user_id." Retailer has been ".$user_status." by Administrator",
            'user_id'=>$admin_id,
            'ip_address'=>$this->input->ip_address(),
            'platform'=>$this->agent->platform(),
            'browser'=> $this->agent->browser(),
            'browser_version'=>$this->agent->version(),
            'time'=>date("h:i:sa"),
            'created_date'=>date("d-m-Y h:i:sa")
        );
        $inserted =  $this->db->insert('administrator_log',$administrator_data);
        return $inserted;
    }
    
    public function changeEmployeeStatus($status, $user_id, $admin_id)
    {
        if($status == 1)
        {
            $user_status = "Activated";
        }
        else
        {
            $user_status = "Deactivated";
        }
        $updated_data = array(
                'status' => $status,
                'modified_at' =>date("d-m-Y h:i:sa")
             );
        
        $this->db->where('id', $user_id);
        $this->db->update('employee',$updated_data); 

        $administrator_data = array(
            'message'=>"#".$user_id." Employee has been ".$user_status." by Administrator",
            'user_id'=>$admin_id,
            'ip_address'=>$this->input->ip_address(),
            'platform'=>$this->agent->platform(),
            'browser'=> $this->agent->browser(),
            'browser_version'=>$this->agent->version(),
            'time'=>date("h:i:sa"),
            'created_date'=>date("d-m-Y h:i:sa")
        );
        $inserted =  $this->db->insert('administrator_log',$administrator_data);
        return $inserted;
    }

    public function changeAdminStatus($status, $user_id, $admin_id)
    {
        if($status == 1)
        {
            $user_status = "Activated";
        }
        else
        {
            $user_status = "Deactivated";
        }
        $updated_data = array(
                'status' => $status,
                'modification_date' =>date("d-m-Y h:i:sa")
             );
        
        $this->db->where('id', $user_id);
        $this->db->update('admin',$updated_data); 

        $administrator_data = array(
            'message'=>$user_id." Admin has been ".$user_status." by Administrator",
            'user_id'=>$admin_id,
            'ip_address'=>$this->input->ip_address(),
            'platform'=>$this->agent->platform(),
            'browser'=> $this->agent->browser(),
            'browser_version'=>$this->agent->version(),
            'time'=>date("h:i:sa"),
            'created_date'=>date("d-m-Y h:i:sa")
        );
        $inserted =  $this->db->insert('administrator_log',$administrator_data);
        return $inserted;
    }
    
    public function changeViewStatus($status, $user_id, $admin_id)
    {
        if($status == 1)
        {
            $user_status = "Activated";
        }
        else
        {
            $user_status = "Deactivated";
        }
        $updated_data = array(
                'print_status' => $status,
                'modified_at' =>date("d-m-Y h:i:sa")
             );
        
        $this->db->where('user_id', $user_id);
        $this->db->update('user',$updated_data); 

        $administrator_data = array(
            'message'=>$user_id." Retailer View has been ".$user_status." by Administrator",
            'user_id'=>$admin_id,
            'ip_address'=>$this->input->ip_address(),
            'platform'=>$this->agent->platform(),
            'browser'=> $this->agent->browser(),
            'browser_version'=>$this->agent->version(),
            'time'=>date("h:i:sa"),
            'created_date'=>date("d-m-Y h:i:sa")
        );
        $inserted =  $this->db->insert('administrator_log',$administrator_data);
        return $inserted;
    }
    
    public function userscount()
    {
        $query=$this->db->query("select count(user_id) as users from user");
        return $query->result();
    }

    public function administratorcount()
    {
        $query=$this->db->query("select count(user_id) as users from administrator");
        return $query->result();
    }
    
    public function admincount()
    {
        $query=$this->db->query("select count(id) as users from admin");
        return $query->result();
    }
    
    public function studentcount()
    {
        $query=$this->db->query("select count(id) as users from student");
        return $query->result();
    }
    
    public function deleteRole($role_id, $user_id)
    {
        $this->db->where('id', $role_id);
        $this->db->delete('role');

        $administrator_data = array(
            'message'=>"Role has been deleted by Administrator",
            'user_id'=>$user_id,
            'ip_address'=>$this->input->ip_address(),
            'platform'=>$this->agent->platform(),
            'browser'=> $this->agent->browser(),
            'browser_version'=>$this->agent->version(),
            'time'=>date("h:i:sa"),
            'created_date'=>date("d-m-Y h:i:sa")
        );
        $inserted =  $this->db->insert('administrator_log',$administrator_data);
        return $inserted;
    }

    public function assignrolenew($create_retailer, $retailers_list, $retailer_status, $students_list, $view_status, $view_student, $delete_student, $student_finger, $role_id, $roleandpermission, $administrator, $delete_retailer)
    {
         $user_data = array(
            'create_retailer'=>$create_retailer,
            'role_id'=>$role_id,
            'retailers_list'=>$retailers_list,
            'retailer_status'=>$retailer_status,
            'view_status'=>$view_status,
            'students_list'=>$students_list,
            'view_student'=>$view_student,
            'delete_student'=> $delete_student,
            'student_finger'=>$student_finger,
            'administrator' => $administrator,
            'delete_retailer'=>$delete_retailer,
            'roleandpermission' => $roleandpermission,
            'created_at'=>date("d-m-Y h:i:sa")
        );
        $inserted =  $this->db->insert('permissions',$user_data);
    }
    
    public function checkroleexist($role_id)
    {
        $query = $this->db->get_where('permissions', array('role_id'=>$role_id));
        return $query->row_array();
    }
    
    public function updateroleassign($create_retailer, $retailers_list, $retailer_status, $students_list, $view_status, $view_student, $delete_student, $student_finger, $role_id,$roleandpermission, $administrator, $delete_retailer)
    {
        $updated_data = array(
            'create_retailer' => $create_retailer,
            'retailers_list'=> $retailers_list,
            'retailer_status' => $retailer_status,
            'view_status' => $view_status,
            'students_list' => $students_list,
            'view_student' => $view_student,
            'delete_student' => $delete_student,
            'student_finger' => $student_finger,
            'administrator' => $administrator,
            'delete_retailer'=>$delete_retailer,
            'roleandpermission' => $roleandpermission
            );
        $this->db->where('role_id', $role_id);
        $task_status_updated = $this->db->update('permissions',$updated_data); 
        return $task_status_updated;
    }

    public function admins()
    {
        $this->db->select('*');
        $this->db->from('admin');
        $this->db->order_by("admin.id", "desc");
        $query = $this->db->get();
        return $query->result_array();
    }

    public function getAdminByAdminId($admin_id)
    {
        $query = $this->db->get_where('admin', array('id'=>$admin_id));
        return $query->row_array();
    }

    public function deleteAdmin($admin_id, $user_id, $username)
    {
        $this->db->where('id', $admin_id);
        $this->db->delete('admin');

        $administrator_data = array(
            'message'=>$username." user has been deleted by Admin",
            'user_id'=>$user_id,
            'ip_address'=>$this->input->ip_address(),
            'platform'=>$this->agent->platform(),
            'browser'=> $this->agent->browser(),
            'browser_version'=>$this->agent->version(),
            'time'=>date("h:i:sa"),
            'created_date'=>date("d-m-Y h:i:sa")
        );
        $inserted =  $this->db->insert('administrator_log',$administrator_data);
        return $inserted;
    }

    public function checkAdminExist($username)
    {
        $query = $this->db->get_where('admin', array('username'=>$username));
        return $query->row_array();
    }

    public function createAdmin($name, $contact, $email, $status, $username, $password, $profile, $user_id, $no_of_retailer, $no_of_employee)
    {
        $administrator_data = array(
            'name'=>$name,
            'contact'=>$contact,
            'email'=>$email,
            'profile'=>$profile,
            'status'=> $status,
            'username'=>$username,
            'password'=>md5($password),
            'no_of_retailer'=>$no_of_retailer,
            'no_of_employee'=>$no_of_employee,
            'created_date'=>date("d-m-Y h:i:sa")
        );
        $inserted =  $this->db->insert('admin',$administrator_data);

        $administrator_data = array(
            'message'=>"New Admin ".$name." created",
            'user_id'=>$user_id,
            'ip_address'=>$this->input->ip_address(),
            'platform'=>$this->agent->platform(),
            'browser'=> $this->agent->browser(),
            'browser_version'=>$this->agent->version(),
            'time'=>date("h:i:sa"),
            'created_date'=>date("d-m-Y h:i:sa")
        );
        $inserted =  $this->db->insert('administrator_log',$administrator_data);
        return $inserted;
    }
    
    public function getnotification()
    {
        $query = $this->db->get_where('notification', array('name'=>'notification'));
        return $query->row_array();
    }
    
    public function savenotification($notification, $user_id)
    {
        $updated_data = array(
                'data' => $notification
             );
        $this->db->where('name', 'notification');
        $this->db->update('notification',$updated_data); 
        $administrator_data = array(
            'message'=>"Notification updated",
            'user_id'=>$user_id,
            'ip_address'=>$this->input->ip_address(),
            'platform'=>$this->agent->platform(),
            'browser'=> $this->agent->browser(),
            'browser_version'=>$this->agent->version(),
            'time'=>date("h:i:sa"),
            'created_date'=>date("d-m-Y h:i:sa")
        );
        $inserted =  $this->db->insert('administrator_log',$administrator_data);
        return $inserted;
    }
    
    public function updateuser($name, $contact, $email, $edit_key, $user_id, $admin_id)
    {
        $updated_data = array(
                'name' => $name,
                'contact' =>$contact,
                'email' =>$email,
                'activation_key' =>$edit_key,
                'is_activated' =>0,
             );
        $this->db->where('user_id', $user_id);
        $this->db->update('user',$updated_data); 
        $administrator_data = array(
            'message'=>"User #".$user_id." updated",
            'user_id'=>$admin_id,
            'ip_address'=>$this->input->ip_address(),
            'platform'=>$this->agent->platform(),
            'browser'=> $this->agent->browser(),
            'browser_version'=>$this->agent->version(),
            'time'=>date("h:i:sa"),
            'created_date'=>date("d-m-Y h:i:sa")
        );
        $inserted =  $this->db->insert('administrator_log',$administrator_data);
        return $inserted;
    }
    
    public function updateemployee($name, $contact, $email, $user_id, $vle_id, $edit_key, $admin_id)
    {
        $updated_data = array(
                'name' => $name,
                'contact' =>$contact,
                'email' =>$email,
                'vle_id' =>$vle_id,
                'activation_key' =>$edit_key,
                'is_activated' => 0
             );
        $this->db->where('id', $user_id);
        $this->db->update('employee',$updated_data); 
        $administrator_data = array(
            'message'=>"Employee #".$user_id." updated",
            'user_id'=>$admin_id,
            'ip_address'=>$this->input->ip_address(),
            'platform'=>$this->agent->platform(),
            'browser'=> $this->agent->browser(),
            'browser_version'=>$this->agent->version(),
            'time'=>date("h:i:sa"),
            'created_date'=>date("d-m-Y h:i:sa")
        );
        $inserted =  $this->db->insert('administrator_log',$administrator_data);
        return $inserted;
    }
    
    public function retailerchangepassword($new_password, $user_id, $admin_id)
    {
        $updated_data = array(
                'password' => md5($new_password)
             );
        $this->db->where('user_id', $user_id);
        $this->db->update('user',$updated_data); 
        $administrator_data = array(
                'message'=>"User #".$user_id." password changed",
                'user_id'=>$admin_id,
                'ip_address'=>$this->input->ip_address(),
                'platform'=>$this->agent->platform(),
                'browser'=> $this->agent->browser(),
                'browser_version'=>$this->agent->version(),
                'time'=>date("h:i:sa"),
                'created_date'=>date("d-m-Y h:i:sa")
            );
            $inserted =  $this->db->insert('administrator_log',$administrator_data);
            return $inserted;
    }

    public function adminchangepassword($new_password, $user_id)
    {
        $updated_data = array(
                'password' => md5($new_password)
             );
        $this->db->where('id', $user_id);
       return  $this->db->update('admin',$updated_data); 
    }
    
    public function employeechangepassword($new_password, $user_id)
    {
        $updated_data = array(
                'password' => md5($new_password)
             );
        $this->db->where('id', $user_id);
       return  $this->db->update('employee',$updated_data); 
    }
    
    public function administratorchangepassword($new_password, $user_id)
    {
        $updated_data = array(
                'password' => md5($new_password)
             );
        $this->db->where('user_id', $user_id);
       return  $this->db->update('administrator',$updated_data); 
    }

    public function retailerlog()
    {
        $this->db->select('retailer_log.id as id, user.username as username, retailer_log.message as message, retailer_log.created_date as created_date');
        $this->db->from('retailer_log');
        $this->db->join('user', 'retailer_log.user = user.user_id','left');
        $this->db->order_by("retailer_log.id", "desc");
        $query = $this->db->get();
        return $query->result_array();
    }

    public function memberstatusupdate($member_id, $remark1, $remark2, $remark3, $status, $user_id, $retailer_visible_access, $employee_visible_access)
    {
        $updated_data = array(
            'remark1' => $remark1,
            'remark2' => $remark2,
            'remark3' => $remark3,
            'status' => $status,
            'visible_to_retailer' => $retailer_visible_access,
            'visible_to_employee' => $employee_visible_access
         );
        $this->db->where('id', $member_id);
        $this->db->update('student',$updated_data); 
        
        $administrator_data = array(
            'message'=>"Member #".$member_id." details updated",
            'user_id'=>$user_id,
            'ip_address'=>$this->input->ip_address(),
            'platform'=>$this->agent->platform(),
            'browser'=> $this->agent->browser(),
            'browser_version'=>$this->agent->version(),
            'time'=>date("h:i:sa"),
            'created_date'=>date("d-m-Y h:i:sa")
        );
        $inserted =  $this->db->insert('administrator_log',$administrator_data);
        return $inserted;
    }
    
    public function retailerlist()
    {
        $this->db->select('*');
        $this->db->from('user');
        $query = $this->db->get();
        return $result = $query->result_array();
    }
    
    public function adminlist()
    {
        $this->db->select('*');
        $this->db->from('admin');
        $query = $this->db->get();
        return $result = $query->result_array();
    }

    public function removefromemployeeath($member_id, $user_id)
    {
        $updated_data = array(
            'employee_show' => "1",
         );
        $this->db->where('id', $member_id);
        $this->db->update('student',$updated_data); 
        
        $administrator_data = array(
            'message'=>"Member #".$member_id." removed from Employee dashboard",
            'user_id'=>$user_id,
            'ip_address'=>$this->input->ip_address(),
            'platform'=>$this->agent->platform(),
            'browser'=> $this->agent->browser(),
            'browser_version'=>$this->agent->version(),
            'time'=>date("h:i:sa"),
            'created_date'=>date("d-m-Y h:i:sa")
        );
        $inserted =  $this->db->insert('administrator_log',$administrator_data);
        return $inserted;
    }

    public function removefromretailerath($member_id, $user_id)
    {
        $updated_data = array(
            'visible_to_retailer' => 0,
         );
        $this->db->where('id', $member_id);
        $this->db->update('student',$updated_data); 
        
        $administrator_data = array(
            'message'=>"Member #".$member_id." removed from Retailer dashboard",
            'user_id'=>$user_id,
            'ip_address'=>$this->input->ip_address(),
            'platform'=>$this->agent->platform(),
            'browser'=> $this->agent->browser(),
            'browser_version'=>$this->agent->version(),
            'time'=>date("h:i:sa"),
            'created_date'=>date("d-m-Y h:i:sa")
        );
        $inserted =  $this->db->insert('administrator_log',$administrator_data);
        return $inserted;
    }

    public function rechargedone($user_id, $admin_id, $coins)
    {
        $rechargeadded = array(
            'admin_id'=>$admin_id,
            'coins'=>$coins,
            'created_at'=>date("Y-m-d h:i:sa")
        );
        $inserted =  $this->db->insert('admin_coin',$rechargeadded);

        $administrator_data = array(
            'message'=>"Recharge Done Successfully",
            'user_id'=>$user_id,
            'ip_address'=>$this->input->ip_address(),
            'platform'=>$this->agent->platform(),
            'browser'=> $this->agent->browser(),
            'browser_version'=>$this->agent->version(),
            'time'=>date("h:i:sa"),
            'created_date'=>date("d-m-Y h:i:sa")
        );
        $inserted =  $this->db->insert('administrator_log',$administrator_data);

        return $inserted;
    }

    public function updatecoins($admin_id, $coins)
    {
        $this->db->set('coins', 'coins + ' . (int) $coins, FALSE);
        $this->db->where('id', $admin_id);
        $task_updated = $this->db->update('admin');
        return $task_updated;
    }

    public function searchath($vle_id)
    {
        $this->db->select('*');
        $this->db->from('student');
        $this->db->where('vle_id', $vle_id);
        $query = $this->db->get();
        return $query->result_array();
    }

    public function admin($admin_username)
    {
        $this->db->select('*');
        $this->db->from('admin');
        $this->db->where('username', $admin_username);
        $query = $this->db->get();
        return $query->result_array();
    }
    
    public function changepasswordadminath($admin_id, $new_password, $user_id)
    {
        $updated_data = array(
                'password' => md5($new_password)
             );
        $this->db->where('id', $admin_id);
        $this->db->update('admin',$updated_data); 
        $administrator_data = array(
                'message'=>"Admin #".$user_id." password changed By Administrator",
                'user_id'=>$user_id,
                'ip_address'=>$this->input->ip_address(),
                'platform'=>$this->agent->platform(),
                'browser'=> $this->agent->browser(),
                'browser_version'=>$this->agent->version(),
                'time'=>date("h:i:sa"),
                'created_date'=>date("d-m-Y h:i:sa")
            );
            $inserted =  $this->db->insert('administrator_log',$administrator_data);
            return $inserted;
    }

    public function admincoinshistory()
    {
        $this->db->select('admin.username as username, admin_coin.admin_id as admin_id, admin_coin.coins as coins, admin_coin.created_at as created_at, admin_coin.id as id, admin_coin.status as status');
        $this->db->from('admin_coin');
        $this->db->join('admin', 'admin_coin.admin_id = admin.id','left');
        $this->db->order_by("admin_coin.id", "desc");
        $query = $this->db->get();
        return $query->result_array();
    }

    public function adminbyId($id)
    {
        $query = $this->db->get_where('admin_coin', array('id'=>$id));
        return $query->row_array();
    }

    public function revertadmincoins($id, $coins, $user_id, $admin_id)
    {
        $updated_data = array(
            'status' => "2"
        );
        $this->db->where('id', $id);
        $this->db->update('admin_coin',$updated_data);

        $administrator_data = array(
            'message'=>$id." Coins Reverted Successfully",
            'user_id'=>$user_id,
            'ip_address'=>$this->input->ip_address(),
            'platform'=>$this->agent->platform(),
            'browser'=> $this->agent->browser(),
            'browser_version'=>$this->agent->version(),
            'time'=>date("h:i:sa"),
            'created_date'=>date("d-m-Y h:i:sa")
        );
        $inserted =  $this->db->insert('administrator_log',$administrator_data);
        if($inserted)
        {
            $this->db->set('coins', 'coins -' . (int) $coins, FALSE);
            $this->db->where('id', $admin_id);
            $task_updated = $this->db->update('admin');
        }
        return $task_updated;

    }

    public function retailercoinshistory()
    {
        $this->db->select('user.username as username, retailer_coin.retailer_id as retailer_id, retailer_coin.coins as coins, retailer_coin.created_at as created_at, retailer_coin.id as id, retailer_coin.status as status');
        $this->db->from('retailer_coin');
        $this->db->join('user', 'retailer_coin.retailer_id = user.user_id','left');
        $this->db->order_by("retailer_coin.id", "desc");
        $query = $this->db->get();
        return $query->result_array();
    }

    public function retailerbyId($id)
    {
        $query = $this->db->get_where('retailer_coin', array('id'=>$id));
        return $query->row_array();
    }

    public function revertretailercoins($id, $coins, $user_id, $retailer_id)
    {
        $updated_data = array(
            'status' => "2"
        );
        $this->db->where('id', $id);
        $this->db->update('retailer_coin',$updated_data);

        $administrator_data = array(
            'message'=>$id." Coins Reverted Successfully",
            'user_id'=>$user_id,
            'ip_address'=>$this->input->ip_address(),
            'platform'=>$this->agent->platform(),
            'browser'=> $this->agent->browser(),
            'browser_version'=>$this->agent->version(),
            'time'=>date("h:i:sa"),
            'created_date'=>date("d-m-Y h:i:sa")
        );
        $inserted =  $this->db->insert('administrator_log',$administrator_data);
        if($inserted)
        {
            $this->db->set('coins', 'coins -' . (int) $coins, FALSE);
            $this->db->where('user_id', $retailer_id);
            $task_updated = $this->db->update('user');
        }
        return $task_updated;

    }

    public function chatusers()
    {
        $this->db->select('*');
        $this->db->from('chat');
        $this->db->order_by("created_date", "desc");
        $query = $this->db->get();
        return $result = $query->result_array();
    }

    public function getUserByUserIds($user_id)
    {
        $query = $this->db->get_where('user', array('user_id'=>$user_id));
        return $query->row_array();
    }

    public function getLatestChatByUserId($user_id)
    {
        $this->db->select('*');
        $this->db->from('chat');
        $this->db->or_where("send_id", $user_id);
        $this->db->or_where("receiver_id", $user_id);
        $this->db->order_by("created_date", "desc");
        $query = $this->db->get();
        return $result = $query->result_array();
    }

    public function getChatByUserIds($user_id)
    {
        $this->db->select('*');
        $this->db->from('chat');
        $this->db->or_where("send_id", $user_id);
        $this->db->or_where("receiver_id", $user_id);
        $this->db->order_by("created_date", "desc");
        $query = $this->db->get();
        return $result = $query->result_array();
    }
    
    public function getChatByUserId($user_id)
    {
        $this->db->select('*');
        $this->db->from('chat');
        $this->db->or_where("send_id", $user_id);
        $this->db->or_where("receiver_id", $user_id);
       // $this->db->order_by("created_date", "desc");
        $query = $this->db->get();
        return $result = $query->result_array();
    }

    public function sendmessage($user_id, $text_message)
    {
        $chatdata = array(
            'send_id'=>'admin',
            'receiver_id'=>$user_id,
            'chat_content'=>$text_message,
            'content_type'=>1,
            'created_date'=>date("d-m-y h:i:sa")
        );
        return $this->db->insert('chat',$chatdata);
    }

    public function getUserByUserIdss($user_id)
    {
        $query = $this->db->get_where('user', array('user_id'=>$user_id));
        return $query->row_array();
    }
}
?>