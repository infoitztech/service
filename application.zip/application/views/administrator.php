<!--start page wrapper -->
<div class="page-wrapper">
    <div class="page-content">
        <h5 class="mb-0 text-uppercase">Administrator</h5>
        <hr/>
        <div class="card">
            <div class="card-body">
                <div class="d-lg-flex align-items-center mb-4 gap-3">
                    <div class="position-relative">
                        <h6>Administrators List</h6>
                    </div>
                    <div class="ms-auto"><a href="<?php echo base_url('administrator/createadministrator') ?>" class="btn btn-light radius-30 mt-2 mt-lg-0"><i class="bx bxs-plus-square"></i>Create New Administrator</a></div>
                </div>
                <div class="table-responsive">
                    <table id="administrators" class="table mb-0">
                        <thead>
                            <tr class="bg-light">
                                <th>Sr.No</th>
                                <th>Profile</th>
                                <th>Role</th>
                                <th>Name</th>
                                <th>Username</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $count=1; foreach($administrators_data as $data) {  $profile = $data['profile']; ?>
                            <tr>
                                <td><?php echo $count++; ?></td>
                                <td><img src="<?php echo base_url('upload/administrator/profilephoto'); ?>/<?php echo ($profile !="") ? $profile: "profile.png"; ?>" alt class="user-img"></td>
                                <td><?php echo $data['role'] ?></td>
                                <td><?php echo $data['name'] ?></td>
                                <td><?php echo $data['username'] ?></td>
                                <td><?php echo ($data['status'] == "1")? "<span class='badge bg-success'>Active</span>" : "<span class='badge bg-danger'>Inactive</span>"; ?></td>
                                <td>
                                    <div class="btn-group">
                                        <button class="btn btn-light btn-sm admin-details" title="Admin Details" data-id="<?php echo $data['user_id']; ?>" data-bs-toggle="modal" data-bs-target="#viewaAdminConfirmation"><i class="bx bx-detail"></i></button>
                                        <a href="<?php echo base_url('administrator/editadministratordetails') ?>?id=<?php echo $data['user_id']; ?>" class="btn btn-light btn-sm" title="Edit Administrator"><i class="bx bxs-edit"></i></a>
                                        <button class="btn btn-light btn-sm delete-admin" title="Delete Admin" data-id="<?php echo $data['user_id']; ?>" data-bs-toggle="modal" data-bs-target="#deleteUserConfirmation"><i class="bx bxs-trash"></i></button>
                                    </div>
                                </td>
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<!--end page wrapper -->
<div class="modal fade" id="deleteUserConfirmation" tabindex="-1" aria-labelledby="deleteUserConfirmationLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteUserConfirmationLabel">Confirmation</h5>
            </div>
            <div class="modal-body">
                Are you sure you want to Delete this Administrator ?
                <input type="hidden" id="delete-user-id">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" id="delete-user-btn" data-bs-dismiss="modal">Confirm</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Decline</button>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="viewaAdminConfirmation" tabindex="-1" aria-labelledby="viewaAdminConfirmationLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="viewaAdminConfirmation">Admin Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-lg-12 col-sm-12">
                        <div class="d-flex flex-column align-items-center text-center">
                            <img src="" class="rounded-circle p-1 bg-primary admin-image" style="height: 110px">
                        </div>
                    </div>
                    <div class="col-lg-12 col-sm-12">
                        <div class="text-center">
                            <p class="mb-0 mt-4">Name : <span class="name"></span></p>
                        </div>
                    </div>
                    <div class="col-lg-12 col-sm-12">
                        <div class="text-center">
                            <p class="mb-0">Contact : <span class="contact"></span></p>
                        </div>
                    </div>
                    <div class="col-lg-12 col-sm-12">
                        <div class="text-center">
                            <p class="mb-0">Email : <span class="email"></span></p>
                        </div>
                    </div>
                    <div class="col-lg-12 col-sm-12">
                        <div class="text-center">
                            <p class="mb-0">Role : <span class="role"></span></p>
                        </div>
                    </div>
                    <div class="col-lg-12 col-sm-12">
                        <div class="text-center">
                            <p>Username : <span class="username"></span></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="AdministratorPasswordConfirmation" tabindex="-1" aria-labelledby="AdministratorPasswordConfirmationLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="AdministratorPasswordConfirmationLabel">Change Password</h5>
            </div>
            <div class="modal-body">
               <div class="row">
                   <div class="col-lg-12">
                       <label>New Password</label>
                       <div class="form-group">
                           <input type="text" id="new-password" class="form-control">
                       </div>
                   </div>
                   <div class="col-lg-12">
                       <label>Confirm Password</label>
                       <div class="form-group">
                           <input type="text" id="confirm-password" class="form-control">
                       </div>
                   </div>
               </div>
            </div>
            <input type="text" id="password-user-id">
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" id="change-password-btn" data-bs-dismiss="modal">Save</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Decline</button>
            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function() {
        var table = $('#administrators').DataTable( {
            buttons: [ 'excel']
        } );
        
        table.buttons().container()
            .appendTo( '#administrators_wrapper .col-md-6:eq(0)' );

        $(document).find("title").text("Administrator");

        $(document).find(".delete-admin").click(function(e){
            e.preventDefault();
            var user_id = $(document).find(this).attr("data-id");
            $(document).find("#delete-user-id").val(user_id);
        });

        $(document).find("#delete-user-btn").click(function(e){
            e.preventDefault();
            var user_id = $(document).find("#delete-user-id").val();
            if(user_id=="")
            {
                alert("Something is wrong! Try again later");
            }
            else
            { 
                $.ajax({
                url: '<?php echo base_url('administrator/deleteAdmin') ?>',
                method: 'POST',
                data: {
                    user_id: user_id
                    },
                    success: function (response) 
                    {
                        var res = JSON.parse(response);
                        if(res['statusCode'] == 2)
                        {
                            success_noti(res['Message']);
                            window.location.reload();
                        }
                        else if(res['statusCode'] == 1)
                        {
                            warning_noti(res['Message']);
                        }
                        else if(res['statusCode'] == 0)
                        {
                            error_noti(res['Message']);
                        }
                    }
                });
            }
        });

        $(document).find(".admin-details").click(function(e){
            e.preventDefault();
            var id = $(document).find(this).attr("data-id");
            if(id=="")
            {
                alert("Something is wrong! Try again later");
            }
            else
            { 
            $.ajax({
                url : '<?php echo base_url('administrator/adminDetailes') ?>',
                method: 'POST',
                data: {
                    id: id
                    },
                    success: function (response) 
                    {
                        var res = JSON.parse(response);
                        $(document).find(".admin-image").attr('src',"<?php echo base_url('upload/administrator/profilephoto/'); ?>"+res['profile']);
                        $(document).find(".name").text(res['name']);
                        $(document).find(".contact").text(res['contact']);
                        $(document).find(".email").text(res['email']);
                        $(document).find(".username").text(res['username']);
                        $(document).find(".role").text(res['role']);
                    }
                });
            }
        });
        
        
    });

    function error_noti(message) 
    {
        Lobibox.notify('error', {
            pauseDelayOnHover: true,
            continueDelayOnInactiveTab: false,
            position: 'top right',
            icon: 'bx bx-x-circle',
            msg: message
        });
    }
    function warning_noti(message) 
    {
        Lobibox.notify('warning', {
            pauseDelayOnHover: true,
            continueDelayOnInactiveTab: false,
            position: 'top right',
            icon: 'bx bx-error',
            msg: message
        });
    }
    function success_noti(message) 
    {
        Lobibox.notify('success', {
            pauseDelayOnHover: true,
            continueDelayOnInactiveTab: false,
            position: 'top right',
            icon: 'bx bx-check-circle',
            msg: message
        });
    }
</script>