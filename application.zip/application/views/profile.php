<!--start page wrapper -->
<div class="page-wrapper">
    <div class="page-content">
        <h5 class="mb-0 text-uppercase">My Profile</h5>
        <hr/>
        <div class="container">
            <div class="main-body">
                <div class="row">
                    <div class="col-lg-4">
                        <div class="card">
                            <div class="card-body">
                                <div class="d-flex flex-column align-items-center text-center">
                                    <img src="<?php echo base_url('upload/administrator/profilephoto'); ?>/<?php echo ($administrator_data['profile'] != "")? $administrator_data['profile'] : "profile.png" ; ?>" alt="Administrator" class="rounded-circle p-1 bg-primary" width="110">
                                    <div class="mt-3">
                                        <h4><?php echo $administrator_data['name']; ?></h4>
                                        <p class="mb-1"><?php echo $administrator_data['role']; ?></p>
                                    </div>
                                </div>
                                <hr class="my-4"/>
                                <div class="row mb-3">
                                    <div class="col-sm-5">
                                        <p class="mb-0">Admin ID :</p>
                                    </div>
                                    <div class="col-sm-7">
                                        <?php echo "#".$administrator_data['user_id']; ?>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col-sm-4">
                                        <p class="mb-0">Username :</p>
                                    </div>
                                    <div class="col-sm-8">
                                        <?php echo $administrator_data['username']; ?>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col-sm-5">
                                        <p class="mb-0">Joining Date :</p>
                                    </div>
                                    <div class="col-sm-7">
                                        <?php echo $administrator_data['created_at']; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-8">
                        <div class="card">
                            <form id="profile-form" method="post" enctype="multipart/form-data">
                                <div class="card-body my-2">
                                    <div class="row mb-3 mt-3">
                                        <div class="col-sm-3">
                                            <h6 class="mb-0">Name</h6>
                                        </div>
                                        <div class="col-sm-9">
                                            <input type="text" class="form-control" id="name" name="name" value="<?php echo $administrator_data['name']; ?>" />
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <div class="col-sm-3">
                                            <h6 class="mb-0">Email</h6>
                                        </div>
                                        <div class="col-sm-9">
                                            <input type="text" class="form-control" id="email" name="email" value="<?php echo $administrator_data['email']; ?>" />
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <div class="col-sm-3">
                                            <h6 class="mb-0">Phone</h6>
                                        </div>
                                        <div class="col-sm-9">
                                            <input type="text" class="form-control" id="contact" name="phone" value="<?php echo $administrator_data['contact']; ?>" />
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <div class="col-sm-3">
                                            <h6 class="mb-0">Profile Photo</h6>
                                        </div>
                                        <div class="col-sm-9">
                                            <input type="file" class="form-control" id="profile-phto" name="profile-photo" />
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-3"></div>
                                        <div class="col-sm-9">
                                            <input type="hidden" id="user_id" name="user_id" value="<?php echo $administrator_data['user_id']; ?>">
                                            <input type="submit" class="btn btn-light px-4" value="Save Changes" />
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--end page wrapper -->
<script>
    $(document).ready(function () {
        $('#profile-form').on('submit', function(event){
            event.preventDefault();

            var user_id = $(document).find("#user_id").val();

            if(user_id == "")
            {
            danger_noti("Something is wrong! Try again later");
            }
            else
            {
                var formData = new FormData(this);
                $.ajax({
                    url: '<?php echo base_url('administrator/updateprofile') ?>',
                    method:"POST",
                    data: formData,
                    contentType:false,
                    cache:false,
                    processData:false,
                    success:function(response)
                    {
                        var res = JSON.parse(response);
                        if(res['statusCode'] == 1)
                        {
                            success_noti(res['Message']);
                            $('.profile-form').trigger("reset");
                            window.location.reload();
                        }
                        else if(res['statusCode'] == 2)
                        {
                            warning_noti(res['Message']);
                        }
                        else if(res['statusCode'] == 0)
                        {
                            error_noti(res['Message']);
                        }
                    }
                })
            }
        
        });

        function error_noti(message) 
        {
            Lobibox.notify('error', {
                pauseDelayOnHover: true,
                continueDelayOnInactiveTab: false,
                position: 'top right',
                icon: 'bx bx-x-circle',
                msg: message
            });
        }
        function warning_noti(message) 
        {
            Lobibox.notify('warning', {
                pauseDelayOnHover: true,
                continueDelayOnInactiveTab: false,
                position: 'top right',
                icon: 'bx bx-error',
                msg: message
            });
        }
        function success_noti(message) 
        {
            Lobibox.notify('success', {
                pauseDelayOnHover: true,
                continueDelayOnInactiveTab: false,
                position: 'top right',
                icon: 'bx bx-check-circle',
                msg: message
            });
        }

    $(document).find("title").text("Administrator Profile");
    }); 
</script>