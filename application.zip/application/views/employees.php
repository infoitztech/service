<!--start page wrapper -->
<div class="page-wrapper">
    <div class="page-content">
        <h5 class="mb-0 text-uppercase">Employee</h5>
        <hr/>
        <div class="card">
            <div class="card-body">
                <div class="d-lg-flex align-items-center mb-4 gap-3">
                    <div class="position-relative">
                        <h6>Employee List</h6>
                    </div>
                    <div class="ms-auto"><a href="<?php echo base_url('administrator/createemployee') ?>" class="btn btn-light radius-30 mt-2 mt-lg-0"><i class="bx bxs-plus-square"></i>Create New Employee</a></div>
                </div>
                <div class="table-responsive">
                    <table id="administrators" class="table mb-0">
                        <thead>
                            <tr class="bg-light">
                                <th>Sr.No</th>
                                <th>Profile</th>
                                <th>Name</th>
                                <th>Username</th>
				                <?php if($permission_details['retailer_status'] == "1") { ?>
                                <th>Status</th>
                                <?php } ?>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $count=1; foreach($employee_data as $data) {  $profile = $data['profile']; ?>
                            <tr>
                                <td><?php echo $count++; ?></td>
                                <td><img src="<?php echo base_url('upload/employee/profilephoto'); ?>/<?php echo ($profile !="") ? $profile: "profile.png"; ?>" alt class="user-img"></td>
                                <td><?php echo $data['name'] ?></td>
                                <td><?php echo $data['username'] ?></td>
                                <?php if($permission_details['retailer_status'] == "1") { ?>
                                <td>
                                    <?php if($data['status']==1) { ?>
                                        <button class="btn btn-success btn-sm profile-status" data-id="<?php echo $data['user_id']; ?>" status-id="1"  data-bs-toggle="modal" data-bs-target="#userStatusConfirmation">Active</button>
                                    <?php } else { ?>
                                        <button class="btn btn-warning btn-sm profile-status" data-id="<?php echo $data['user_id']; ?>" status-id="0" data-bs-toggle="modal" data-bs-target="#userStatusConfirmation">Inactive</button>
                                    <?php } ?>
                                </td>
                                <?php } ?>
                                <td>
                                    <div class="btn-group">
                                        <?php if($permission_details['delete_retailer'] == "1") { ?>
                                        <button class="btn btn-light btn-sm change-password" title="Change Password" data-id="<?php echo $data['user_id']; ?>" data-bs-toggle="modal" data-bs-target="#changepasswordConfirmation"><i class="bx bxs-lock"></i></button>
                                        <button class="btn btn-light btn-sm employee-details" title="Employee Details" data-id="<?php echo $data['user_id']; ?>" data-bs-toggle="modal" data-bs-target="#viewaEmployeeConfirmation"><i class="bx bx-detail"></i></button>
                                        <button class="btn btn-light btn-sm edit-employee" title="Edit Employee" data-id="<?php echo $data['user_id']; ?>" data-bs-toggle="modal" data-bs-target="#editEmployeeConfirmation"><i class="bx bxs-edit"></i></button> 
                                         <button class="btn btn-light btn-sm delete-user" title="Delete Employee" data-id="<?php echo $data['user_id']; ?>" data-bs-toggle="modal" data-bs-target="#deleteUserConfirmation"><i class="bx bxs-trash"></i></button> 
                                          <?php } ?>
                                    </div>
                                </td>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="deleteUserConfirmation" tabindex="-1" aria-labelledby="deleteUserConfirmationLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteUserConfirmationLabel">Confirmation</h5>
            </div>
            <div class="modal-body">
                Are you sure you want to Delete this Employee ?
                <input type="hidden" id="delete-user-id">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" id="delete-user-btn" data-bs-dismiss="modal">Confirm</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Decline</button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="viewaEmployeeConfirmation" tabindex="-1" aria-labelledby="viewaEmployeeConfirmationLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="viewaEmployeeConfirmation">Employee Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-lg-12 col-sm-12">
                        <div class="d-flex flex-column align-items-center text-center">
                            <img src="" class="rounded-circle p-1 bg-primary employee-image" style="height: 110px">
                        </div>
                    </div>
                    <div class="col-lg-12 col-sm-12">
                        <div class="text-center">
                            <p class="mb-0 mt-4">Name : <span class="name"></span></p>
                        </div>
                    </div>
                    <div class="col-lg-12 col-sm-12">
                        <div class="text-center">
                            <p class="mb-0">Contact : <span class="contact"></span></p>
                        </div>
                    </div>
                    <div class="col-lg-12 col-sm-12">
                        <div class="text-center">
                            <p class="mb-0">Email : <span class="email"></span></p>
                        </div>
                    </div>
                    <div class="col-lg-12 col-sm-12">
                        <div class="text-center">
                            <p>Username : <span class="username"></span></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="changepasswordConfirmation" tabindex="-1" aria-labelledby="changepasswordConfirmationLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="changepasswordConfirmationLabel">Confirmation</h5>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-lg-12">
                        <label>New Password</label>
                        <div class="form-group">
                            <input type="text" id="new_password" class="form-control">
                        </div>
                    </div>
                    <div class="col-lg-12">
                        <label>Confirm Password</label>
                        <div class="form-group">
                            <input type="text" id="confirm_password" class="form-control">
                        </div>
                    </div>
                </div>
                <input type="hidden" id="change-password-id">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" id="change-password-btn" data-bs-dismiss="modal">Change</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Decline</button>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="userStatusConfirmation" tabindex="-1" aria-labelledby="userStatusConfirmationLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="userStatusConfirmationLabel">Confirmation</h5>
            </div>
            <div class="modal-body">
                Are you sure you want to <span id="status"></span> this Employee ?
                <input type="hidden" id="user-id">
                <input type="hidden" id="status-id">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" id="change-status-btn" data-bs-dismiss="modal">Confirm</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Decline</button>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="editEmployeeConfirmation" tabindex="-1" aria-labelledby="editEmployeeConfirmationLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editEmployeeConfirmation">Edit Employee Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-lg-12 col-sm-12">
                        <label>Name</label>
                        <div class="form-group">
                            <input type="text" id="edit-name" class="form-control">
                        </div>
                    </div>
                    <div class="col-lg-12 col-sm-12">
                        <label>Mobile Number</label>
                        <div class="form-group">
                            <input type="text" id="edit-contact" class="form-control">
                        </div>
                    </div>
                    <div class="col-lg-12 col-sm-12">
                        <label>Email</label>
                        <div class="form-group">
                            <input type="text" id="edit-email" class="form-control">
                        </div>
                    </div>
                    <div class="col-lg-12 col-sm-12">
                        <label>VLE ID</label>
                        <div class="form-group">
                            <input type="text" id="edit-vle-id" class="form-control">
                        </div>
                    </div>
                     <div class="col-lg-12 col-sm-12">
                        <label>Activation Key</label>
                        <div class="form-group">
                            <input type="text" id="edit-key" class="form-control">
                        </div>
                    </div>
                    <input type="hidden" id="edit-user-id">
                    <div class="col-lg-4 col-sm-4 mx-auto mt-3">
                        <button class="btn btn-primary" id="update-employee">Update</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!--end page wrapper -->
<script>
    $(document).ready(function() {
        $(document).find(".profile-status").click(function(e){
            e.preventDefault();
            var user_id = $(document).find(this).attr("data-id");
            var status = $(document).find(this).attr("status-id");
            var new_status ="";
            if(status == "1")
            {
                new_status ="Deactivate";
                status= "0";
            }
            else if(status == "0")
            {
                new_status ="Activate";
                status= "1";
            }
            $(document).find("#user-id").val(user_id);
            $(document).find("#status").text(new_status);
            $(document).find("#status-id").val(status);
        });
        $(document).find(".delete-user").click(function(e){
            e.preventDefault();
            var user_id = $(document).find(this).attr("data-id");
            $(document).find("#delete-user-id").val(user_id);
        });
        $(document).find("#delete-user-btn").click(function(e){
            e.preventDefault();
            var user_id = $(document).find("#delete-user-id").val();
            if(user_id=="")
            {
                alert("Something is wrong! Try again later");
            }
            else
            { 
                $.ajax({
                url: '<?php echo base_url('administrator/deleteemployee') ?>',
                method: 'POST',
                data: {
                    user_id: user_id
                    },
                    success: function (response) 
                    {
                        var res = JSON.parse(response);
                        if(res['statusCode'] == 2)
                        {
                            success_noti(res['Message']);
                            window.location.reload();
                        }
                        else if(res['statusCode'] == 1)
                        {
                            warning_noti(res['Message']);
                        }
                        else if(res['statusCode'] == 0)
                        {
                            error_noti(res['Message']);
                        }
                    }
                });
            }
        });
        $(document).find("#change-status-btn").click(function(e){
            e.preventDefault();
            var user_id = $(document).find("#user-id").val();
            var status_id = $(document).find("#status-id").val();
            if(user_id=="" && status_id == "")
            {
                alert("Something is wrong! Try again later");
            }
            else
            { 
                $.ajax({
                url: '<?php echo base_url('administrator/changeemployeeStatus') ?>',
                method: 'POST',
                data: {
                    user_id: user_id,
                    status_id : status_id
                    },
                    success: function (response) 
                    {
                        var res = JSON.parse(response);
                        if(res['statusCode'] == 2)
                        {
                            success_noti(res['Message']);
                            window.location.reload();
                        }
                        else if(res['statusCode'] == 1)
                        {
                            warning_noti(res['Message']);
                        }
                        else if(res['statusCode'] == 0)
                        {
                            error_noti(res['Message']);
                        }
                    }
                });
            }
        });
        $(document).find(".change-password").click(function(e){
            e.preventDefault();
            var id = $(document).find(this).attr("data-id");
            $(document).find("#change-password-id").val(id);
        });
        $(document).find("#change-password-btn").click(function(e){
            e.preventDefault();
            var employee_id = $(document).find("#change-password-id").val();
            var new_password = $(document).find("#new_password").val();
            var confirm_password = $(document).find("#confirm_password").val();
            
            if(employee_id=="")
            {
                alert("Something is wrong! Try again later");
            } 
            else if(new_password == "")
            {
                warning_noti("New Password is required!");
            }
            else if(confirm_password == "")
            {
                warning_noti("Confirm Password is required!");
            }
            else if(confirm_password != new_password)
            {
                warning_noti("Confirm Password and new Password must be same!");
            }
            else
            {
                $.ajax({
                    url: '<?php echo base_url('administrator/changepasswordemployeeath') ?>',
                    method: 'POST',
                    data: {
                        employee_id: employee_id,
                        new_password: new_password
                        },
                    success: function (response) 
                    {
                        var res = JSON.parse(response);
                        if(res['statusCode'] == 3)
                        {
                            success_noti(res['Message']);
                            window.location.reload();
                        }
                        else if(res['statusCode'] == 2)
                        {
                            warning_noti(res['Message']);
                        }
                        else if(res['statusCode'] == 0)
                        {
                            error_noti(res['Message']);
                        }
                    }
                })
            }
            
        });
        
        $(document).find(".employee-details").click(function(e){
            e.preventDefault();
            var id = $(document).find(this).attr("data-id");
            if(id=="")
            {
                alert("Something is wrong! Try again later");
            }
            else
            { 
            $.ajax({
                url : '<?php echo base_url('administrator/employeedetail') ?>',
                method: 'POST',
                data: {
                    id: id
                    },
                    success: function (response) 
                    {
                        var res = JSON.parse(response);
                        if(res['profile'])
                        {
                            $(document).find(".employee-image").attr('src',"<?php echo base_url('upload/employee/profilephoto/'); ?>"+res['profile']);
                        }
                        else
                        {
                            $(document).find(".employee-image").attr('src',"<?php echo base_url('upload/employee/profilephoto/profile.png'); ?>");
                        }
                        $(document).find(".name").text(res['name']);
                        $(document).find(".contact").text(res['contact']);
                        $(document).find(".email").text(res['email']);
                        $(document).find(".username").text(res['username']);
                    }
                });
            }
        });
        
       $("#administrators").on("click", ".edit-employee", function(e){
        //$(document).find(".edit-retailer").on("click", function(e){
            e.preventDefault();
            var id = $(document).find(this).attr("data-id");
            if(id=="")
            {
                alert("Something is wrong! Try again later");
            }
            else
            { 
            $.ajax({
                url : '<?php echo base_url('administrator/employeedetail') ?>',
                method: 'POST',
                data: {
                    id: id
                    },
                    success: function (response) 
                    {
                        var res = JSON.parse(response);
                        
                        $(document).find("#edit-name").val(res['name']);
                        $(document).find("#edit-contact").val(res['contact']);
                        $(document).find("#edit-email").val(res['email']);
                        $(document).find("#edit-user-id").val(res['id']);
                        $(document).find("#edit-vle-id").val(res['vle_id']);
                         $(document).find("#edit-key").val(res['activation_key']);
                    }
                });
            }
        });
        
        
        $(document).find("#update-employee").on("click", function(e){
            e.preventDefault();
            var name = $(document).find("#edit-name").val();
            var contact = $(document).find("#edit-contact").val();
            var email = $(document).find("#edit-email").val();
            var user_id = $(document).find("#edit-user-id").val();
            var edit_vle_id = $(document).find("#edit-vle-id").val();
            var edit_key = $(document).find("#edit-key").val();
            if(name=="")
            {
                warning_noti("Name is required!");
            }
            else if(user_id == "")
            {
                warning_noti("Something is wrong! Try again later");
            }
            else
            { 
                $.ajax({
                    url : '<?php echo base_url('administrator/updateemployee') ?>',
                    method: 'POST',
                    data: {
                        name: name,
                        contact: contact,
                        email: email,
                        user_id: user_id,
                        vle_id : edit_vle_id,
                        edit_key : edit_key
                    },
                    success: function (response) 
                    {
                       if(response == "1")
                       {
                           success_noti("Retailer Updated!");
                           window.location.reload();
                       }
                       else
                       {
                           warning_noti("Failed to update retailer!");
                       }
                    }
                });
            }
        });
        
        $(document).find("title").text("Employee List");
        });

    function error_noti(message) 
    {
        Lobibox.notify('error', {
            pauseDelayOnHover: true,
            continueDelayOnInactiveTab: false,
            position: 'top right',
            icon: 'bx bx-x-circle',
            msg: message
        });
    }
    function warning_noti(message) 
    {
        Lobibox.notify('warning', {
            pauseDelayOnHover: true,
            continueDelayOnInactiveTab: false,
            position: 'top right',
            icon: 'bx bx-error',
            msg: message
        });
    }
    function success_noti(message) 
    {
        Lobibox.notify('success', {
            pauseDelayOnHover: true,
            continueDelayOnInactiveTab: false,
            position: 'top right',
            icon: 'bx bx-check-circle',
            msg: message
        });
    }

</script>
