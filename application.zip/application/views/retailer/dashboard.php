<!--start page wrapper -->
<div class="page-wrapper">
    <div class="page-content">
        <div class="row row-cols-1 row-cols-lg-2 row-cols-xl-3">
            <div class="col">
                <div class="card radius-10">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div>
                                <p class="mb-0">Total Coins</p>
                                <h4 class="my-1"><?php echo $total_coins ?></h4>
                            </div>
                            <div class="widgets-icons ms-auto"><i class='lni lni-users'></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
    </div>
</div>
<!--end page wrapper -->
<script>
    $(document).ready(function () {

        $(document).find("title").text("Retailer Dashboard");
    }); 
</script>