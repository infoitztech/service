<!DOCTYPE html>
<html lang="en">
<head>
  <title>Chat</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <style>
      .text-left, .text-right
      {
          transform : rotate(180deg); 
      }
  </style>
</head>
<body> 
 
<div class="container">
    <div class="row">
        <div class="col-lg-5 mx-auto">
            <div class="card">
                <div class="card-header"><h4 class="text-center">Customer Support</h4></div>
                <div class="card-body overflow-auto" style='height : 500px; transform : rotate(180deg); direction : rtl'>
                </div>
                <div class="card-footer text-center">
                    <div class="row">
                        <div class="col-sm-10 mb-3">
                            <input type="text" class="form-control text-message">
                        </div>
                        <div class="col-sm-1">
                            <button class="btn btn-primary btn-sm send-btn">Send</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
<script>
    $(document).ready(function () {
        var user_id = <?php echo $_GET['user_id']; ?>;
        getchathistory(user_id);
        $('.send-btn').on('click', function(event){
            event.preventDefault();
            var text_message = $(document).find(".text-message").val();
            if(text_message == "")
            {
                alert("Message is required!");
            }
            else if(user_id == "")
            {
                 alert("Something is wrong! Try again later");
            }
            else
            {
                $.ajax({
                    url: '<?php echo base_url('retailer/sendmessage') ?>',
                    method: 'POST',
                    data: {
                        user_id: user_id,
                        text_message : text_message
                    },
                    success: function (response) 
                    {
                        if(response ==1)
                        {
                            getchathistory(user_id);
                            $(".text-message").val("");
                        }
                        else
                        {
                            alert("Failed");
                        }
                    }
                });
            }
        });
        function getchathistory(user_id)
        {
            if(user_id)
            {
                $.ajax({
                    url: '<?php echo base_url('administrator/getchathistory') ?>',
                    method: 'POST',
                    data: {
                        user_id: user_id
                    },
                    success: function (response) 
                    {
                        var res = JSON.parse(response);
                        var chatdata = "";
                        $(document).find(".person-name").text(res['1']['name']);
                        if(res['1']['profile'] =="")
                        {
                            res['1']['profile'] = "profile.png"
                        }
                        $(".useruser_id").val(res['1']['user_id']);
                        for(var i=0; i<res['0'].length; i++)
                        {
                            if(res['0'][i]['send_id'] != "admin")
                            {
                                chatdata+='<p class="text-right"><span class="badge badge-primary">'+res["0"][i]["chat_content"]+'<br>&nbsp;&nbsp;&nbsp;&nbsp;'+res["0"][i]["created_date"]+'</span></p>';
                            }
                            else
                            {
                                chatdata+='<p class="text-left"><span class="badge badge-secondary">'+res["0"][i]["chat_content"]+'<br>&nbsp;&nbsp;&nbsp;&nbsp;'+res["0"][i]["created_date"]+'</span></p>';
                            }
                        }
                        $(document).find(".overflow-auto").html(chatdata);
                    }
                })
            }
        }
    });

    
</script>