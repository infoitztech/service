<!--start page wrapper -->
<div class="page-wrapper">
    <div class="page-content">
        <h5 class="mb-0 text-uppercase">Member</h5>
        <hr/>
        <div class="card">
            <div class="card-body">
                <div class="d-lg-flex align-items-center mb-4 gap-3">
                    <div class="position-relative">
                        <h6>Members List</h6>
                    </div>
                </div>
                <div class="table-responsive">
                    <table id="studenttable" class="table mb-0">
                        <thead>
                            <tr class="bg-light">
                                <th>Sr.No</th>
                                <th>Ref. ID</th>
                                <th>Type</th>
                                <th>Name</th>
                                <th>Purpose</th>
                                <th>My Remark</th>
                                <th>Employee Remark</th>
                                <th>Status</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $count=1; foreach($studentdata_data as $data) {   ?>
                            <tr>
                                <td><?php echo $count++; ?>.</td>
                                <td><?php echo "#".$data->vle_id; ?></td>
                                <td><?php echo $data->type ?></td>
                                <td><?php echo $data->name; ?></td>
                                <td><?php echo $data->purpose; ?></td>
                                <td><?php echo $data->remark1; ?></td>
                                <td><?php echo $data->remark2; ?></td>
                                <td><?php echo $data->status; ?></td>
                                <td><?php echo $data->created_at; ?></td>
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<!--end page wrapper -->

<script>
    $(document).ready(function() {
        var table = $('#studenttable').DataTable( {
            buttons: [ 'excel']
        } );
        
        table.buttons().container()
            .appendTo( '#studenttable_wrapper .col-md-6:eq(0)' );

        $(document).find("title").text("Student Finger Prints");
    });
</script>