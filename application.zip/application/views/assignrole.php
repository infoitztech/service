<!--start page wrapper -->
<div class="page-wrapper">
    <div class="page-content">
        <div class="row">
            <div class="col-xl-7 mx-auto">
                <h5 class="mb-0 text-uppercase">Assign Role</h5>
                <hr/>
                <div class="card border-top border-0 border-4 border-white">
                    <div class="card-body p-5">
                        <div class="card-title d-flex align-items-center">
                            <h6 class="mb-0 text-white">1. Create New Retailer</h6>
                        </div>
                        <hr>
                        <form class="row g-3"  method="post" enctype="multipart/form-data" id="role-form">
                            <div class="col-3">
                                <p class="text-white">2. Create Retailer</p>
                            </div>
                            <div class="col-9">
                                <input type="checkbox" class="form-check-input" value="1" id="create_retailer"/>
                            </div>
                            <div class="col-4 mb-0">
                                <p class="text-white mb-0">3. Retailers List</p>
                            </div>
                            <div class="col-4 mb-0">
                                <input type="checkbox" class="form-check-input mb-0" value="1" id="retailers_list"/>
                            </div>
                            <div class="col-4 mx-4">
                                <p class="text-white mb-0">i. Retailers Status</p>
                            </div>
                            <div class="col-4 mb-0">
                                <input type="checkbox" class="form-check-input mb-0" value="1" id="retailer_status"/>
                            </div>
                            <div class="col-4 mx-4">
                                <p class="text-white">ii. Delete Retailers</p>
                            </div>
                            <div class="col-4">
                                <input type="checkbox" class="form-check-input" value="1" id="delete_retailer"/>
                            </div>
                            <div class="col-3 mx-4">
                                <p class="text-white mb-0">iii. View Status</p>
                            </div>
                            <div class="col-5 mb-0">
                                <input type="checkbox" class="form-check-input mb-0" value="1" id="view_status"/>
                            </div>
                            <div class="col-3 mx-4 mb-0">
                                <p class="text-white mb-0">iv. View Student</p>
                            </div>
                            <div class="col-5">
                                <input type="checkbox" class="form-check-input mb-0" value="1" id="view_student"/>
                            </div>
                            <div class="col-4 mx-4">
                                <p class="text-white">vi. Delete Student</p>
                            </div>
                            <div class="col-4">
                                <input type="checkbox" class="form-check-input" value="1" id="delete_student"/>
                            </div>
                            <div class="col-4 mb-0">
                                <p class="text-white mb-0">5. Student List</p>
                            </div>
                            <div class="col-4 mb-0">
                                <input type="checkbox" class="form-check-input mb-0" value="1" id="students_list"/>
                            </div>
                            <div class="col-4 mx-4 mb-0">
                                <p class="text-white mb-0">i. Student Fingers</p>
                            </div>
                            <div class="col-4 mb-0">
                                <input type="checkbox" class="form-check-input mb-0" value="1" id="student_finger"/>
                            </div>
                            <div class="col-4 mb-0">
                                <p class="text-white mb-0">6. Administrator</p>
                            </div>
                            <div class="col-6 mb-0">
                                <input type="checkbox" class="form-check-input mb-0" value="1" id="administrator"/>
                            </div>
                            <div class="col-4 mb-0">
                                <p class="text-white mb-0">7. Role & Permissions</p>
                            </div>
                            <div class="col-6 mb-0">
                                <input type="checkbox" class="form-check-input mb-0" value="1" id="roleandpermission"/>
                            </div>
                            <input type="hidden" id="role-id" value="<?php echo $_GET['role_id']; ?>" >
                            <div class="col-6 mx-auto">
                                <button type="button" class="btn btn-light px-5" id="save-changes-btn">Save Changes</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--end page wrapper -->

<script>
    $(document).ready(function () {
        
        $(document).find("#save-changes-btn").click(function(e){
            e.preventDefault();
            var create_retailer = $(document).find("#create_retailer:checked").val();
            if(create_retailer == null)
            {
                create_retailer = "0";
            }
            var retailers_list = $(document).find("#retailers_list:checked").val();
            if(retailers_list == null)
            {
                retailers_list = "0";
            }
            var retailer_status = $(document).find("#retailer_status:checked").val();
            if(retailer_status == null)
            {
                retailer_status = "0";
            }
            var view_status = $(document).find("#view_status:checked").val();
            if(view_status == null)
            {
                view_status = "0";
            }
            var students_list = $(document).find("#students_list:checked").val();
            if(students_list == null)
            {
                students_list = "0";
            }
            var view_student = $(document).find("#view_student:checked").val();
            if(view_student == null)
            {
                view_student = "0";
            }
            var delete_student = $(document).find("#delete_student:checked").val();
            if(delete_student == null)
            {
                delete_student = "0";
            }
            var student_finger = $(document).find("#student_finger:checked").val();
            if(student_finger == null)
            {
                student_finger = "0";
            }
            
            var administrator = $(document).find("#administrator:checked").val();
            if(administrator == null)
            {
                administrator = "0";
            }
            var delete_retailer = $(document).find("#delete_retailer:checked").val();
            if(delete_retailer == null)
            {
                delete_retailer = "0";
            }
            
            var roleandpermission = $(document).find("#roleandpermission:checked").val();
            if(roleandpermission == null)
            {
                roleandpermission = "0";
            }
            
            var role_id = $(document).find("#role-id").val();
            
            $.ajax({
            url: '<?php echo base_url('administrator/assignroleath') ?>',
            method: 'POST',
            data: {
                create_retailer: create_retailer,
                retailers_list : retailers_list,
                retailer_status : retailer_status,
                view_status : view_status,
                students_list : students_list,
                view_student : view_student,
                delete_student : delete_student,
                student_finger : student_finger,
                administrator : administrator,
                roleandpermission : roleandpermission,
                delete_retailer : delete_retailer,
                role_id : role_id
                },
                success: function (response) 
                {
                    var res = JSON.parse(response);
                    if(res['statusCode'] == 1)
                    {
                        success_noti(res['Message']);
                        window.location.reload();
                    }
                    else if(res['statusCode'] == 2)
                    {
                        warning_noti(res['Message']);
                    }
                    else if(res['statusCode'] == 0)
                    {
                        error_noti(res['Message']);
                    }
                }
            });
        });
    

        function error_noti(message) 
        {
            Lobibox.notify('error', {
                pauseDelayOnHover: true,
                continueDelayOnInactiveTab: false,
                position: 'top right',
                icon: 'bx bx-x-circle',
                msg: message
            });
        }
        function warning_noti(message) 
        {
            Lobibox.notify('warning', {
                pauseDelayOnHover: true,
                continueDelayOnInactiveTab: false,
                position: 'top right',
                icon: 'bx bx-error',
                msg: message
            });
        }
        function success_noti(message) 
        {
            Lobibox.notify('success', {
                pauseDelayOnHover: true,
                continueDelayOnInactiveTab: false,
                position: 'top right',
                icon: 'bx bx-check-circle',
                msg: message
            });
        }

        $(document).find("title").text("Create Retailer");
    }); 
</script>