<!--start page wrapper -->
<div class="page-wrapper">
    <div class="page-content">
        <div class="row">
            <div class="col-xl-7 mx-auto">
                <h5 class="mb-0 text-uppercase">Admin</h5>
                <hr/>
                <div class="card border-top border-0 border-4 border-white">
                    <div class="card-body p-5">
                        <div class="card-title d-flex align-items-center">
                            <h6 class="mb-0 text-white">Edit Admin</h6>
                        </div>
                        <hr>
                        <form class="row g-3"  method="post" enctype="multipart/form-data" id="admin-form">
                            <div class="col-md-6">
                                <label for="name" class="form-label">Name </label>
                                <input type="text" class="form-control" id="name" name="name" value="<?php echo $admin_data['name']; ?>">
                            </div>
                            <div class="col-md-6">
                                <label for="emp-code" class="form-label">Mobile No. </label>
                                <input type="text" class="form-control" id="contact" name="contact" value="<?php echo $admin_data['contact']; ?>">
                            </div>
                            <div class="col-md-6">
                                <label for="mobile" class="form-label">Email </label>
                                <input type="email" class="form-control" id="email" name="email" value="<?php echo $admin_data['email']; ?>">
                            </div>
                            <div class="col-md-6">
                                <label for="profile" class="form-label">Profile Photo </label>
                                <input type="text" name="profile-photo" value="<?php echo $admin_data['profile']; ?>" class = "form-control">
                                <input type="file" class="form-control" id="profile-photo" name="profile-photo">
                            </div>
                            <div class="col-md-6">
                                <label for="email" class="form-label">Username </label>
                                <input type="text" class="form-control" id="username" name="username" value="<?php echo $admin_data['username']; ?>">
                            </div>
                            <div class="col-md-6"><input type="hidden" name="id" id="id" value="<?php echo $admin_data['id']; ?>" class="form-control"> </div>
                                              
                            <div class="col-4 mx-auto">
                                <button type="submit" class="btn btn-light px-5">Update</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--end page wrapper -->
<script>
    $(document).ready(function () {
        $('#admin-form').on('submit', function(event){
            event.preventDefault();
            var name = $(document).find("#name").val();
            var contact = $(document).find("#contact").val();
            var email = $(document).find("#email").val();
            var username = $(document).find("#username").val();            
            var id = $(document).find("#id").val();
            
            if(name=="")
            {
                error_noti("Admin Name is required!");
            }
            else if(contact == "")
            {
                error_noti("Admin contact is required!");
            }
            else if(email == "")
            {
                error_noti("Admin Email is required!");
            }
            else if(username == "")
            {
                error_noti("Username is required!");
            }
            else
            {

                var formData = new FormData(this);
                $.ajax({
                    url: '<?php echo base_url('administrator/updateadmin') ?>',
                    method:"POST",
                    data: formData,
                    contentType:false,
                    cache:false,
                    processData:false,
                    success:function(response)
                    {
                        var res = JSON.parse(response);
                        if(res['statusCode'] == 1)
                        {
                            success_noti(res['Message']);
                            window.location.href= "<?php echo base_url('/administrator/admin') ?>"
                        }
                        else if(res['statusCode'] == 2)
                        {
                            warning_noti(res['Message']);
                        }
                        else if(res['statusCode'] == 0)
                        {
                            error_noti(res['Message']);
                        }
                    }
                });
            }
        });
        function error_noti(message) 
        {
            Lobibox.notify('error', {
                pauseDelayOnHover: true,
                continueDelayOnInactiveTab: false,
                position: 'top right',
                icon: 'bx bx-x-circle',
                msg: message
            });
        }
        function warning_noti(message) 
        {
            Lobibox.notify('warning', {
                pauseDelayOnHover: true,
                continueDelayOnInactiveTab: false,
                position: 'top right',
                icon: 'bx bx-error',
                msg: message
            });
        }
        function success_noti(message) 
        {
            Lobibox.notify('success', {
                pauseDelayOnHover: true,
                continueDelayOnInactiveTab: false,
                position: 'top right',
                icon: 'bx bx-check-circle',
                msg: message
            });
        }

        $(document).find("title").text("Edit Admin");
    }); 
</script>
