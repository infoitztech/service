<div class="page-content">
    <div class="container-fluid">
        <!-- start page title -->
        <div class="row"></div>
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h6 class="text-primary">Quick Overview</h6>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-xl-4 col-md-6">
                                <!-- card -->
                                <div class="card card-h-100">
                                    <!-- card body -->
                                    <div class="card-body">
                                        <div class="row align-items-center">
                                            <div class="col-12">
                                                <span class="text-muted mb-3 lh-1 d-block text-truncate">Total Retailer</span>
                                                    <h4 class="mb-3"><?php echo $total_users ?></h4>
                                            </div>
                                        </div>
                                        
                                    </div><!-- end card body -->
                                </div><!-- end card -->
                            </div><!-- end col --> 
                           
                            <div class="col-xl-4 col-md-6">
                                <!-- card -->
                                <div class="card card-h-100">
                                    <!-- card body -->
                                    <div class="card-body">
                                        <div class="row align-items-center">
                                            <div class="col-12">
                                                <span class="text-muted mb-3 lh-1 d-block text-truncate">Balance</span>
                                                    <h4 class="mb-3"><?php echo $total_coins ?></h4>
                                            </div>
                                        </div>
                                        
                                    </div><!-- end card body -->
                                </div><!-- end card -->
                                
                            </div><!-- end col --> 
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-lg-4">
                                <div class="form-group">
                                    <input type="text" name="username" id="username" class="form-control" placeholder="Enter Username">
                                </div>    
                            </div>
                            <div class="col-lg-4">
                                <div class="form-group">
                                    <input type="text" name="coins" id="coins" class="form-control" placeholder="Enter Coins">
                                </div>    
                            </div>
                            <div class="col-lg-4">
                                <div class="form-group text-center">
                                    <button class="btn btn-light" type="button" id="add-coins">Add Coins</button>
                                </div>    
                            </div>
                        </div>
                    </div>
                    <!--start page wrapper -->
<div class="page-wrapper">
    <div class="page-content">
        <div class="row">
            <div class="col-xl-8 mx-auto">
                <div class="card border-top border-0 border-4 border-black">
                    <div class="card-body p-5">
                        <div class="card-title d-flex align-items-center">
                            <h6 class="mb-0 text-red">Status</h6>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-lg-6 mx-auto">
                                <div class="input-group">
									<input type="text" class="form-control" id="vle_id" placeholder="Enter Ref. ID">
									<button class="btn btn-light" type="button" id="search">Submit</button>
								</div>
                            </div>
                        </div>
                        <div class="row mt-3" id="details-container" style="display : none; width: 350px" >   
                            <table>
                                <tr style="width : 20%">
                                    <th><p class="text-black">Ref. ID :</p></th>
                                    <td><p class="text-black" id="vle_ids"></p></td>
                                </tr>
                                <!--<tr style="width : 20%">-->
                                <!--    <th><p class="text-white">user id :</p></th>-->
                                <!--    <td><p class="text-white" id="username"></p></td>-->
                                <!--</tr>-->
                                <tr>
                                    <th><p class="text-black">Name :</p></th>
                                    <td><p class="text-black" id="name"></p></td>
                                </tr>
                                <tr>
                                    <th><p class="text-black">DOB :</p></th>
                                    <td><p class="text-black" id="dob"></p></td>
                                </tr>
                                <tr>
                                    <th><p class="text-black">Contact :</p></th>
                                    <td><p class="text-black" id="contact" ></p></td>
                                    
                                </tr>
                                <tr>
                                    <th><p class="text-black">ID No :</p></th>
                                    <td><p class="text-black" id="adhaar_no"></p></td>
                                </tr>
                                <tr>
                                    <th><p class="text-black">Type :</p></th>
                                    <td><p class="text-black" id="type"></p></td>
                                </tr>
                                <tr>
                                    <th><p class="text-black">Status :</p></th>
                                    <td><p class="text-black" id="status"></p></td>
                                </tr>
                                <tr>
                                    <th><p class="text-black">SP Remark :</p></th>
                                    <td><p class="text-black" id="Remark2"></p></td>
                                </tr>
                                <!--<tr>-->
                                <!--    <th><p class="text-black">Purpose :</p></th>-->
                                <!--    <td><p class="text-black" id="purpose"></p></td>-->
                                    
                                <!--</tr>-->
                                <!--<tr>-->
                                <!--    <th><p class="text-white">employee name :</p></th>-->
                                <!--    <td><p class="text-white" id="employee_name"></p></td>-->
                                <!--</tr>-->
                                <!--<tr><th><p class="text-black">employee remark :</p></th>-->
                                <!--    <td><p class="text-black" id="remark2"></p></td>-->
                                <!--</tr>-->
                                <!-- <tr>-->
                                <!--    <th><p class="text-black">Entry Date :</p></th>-->
                                <!--    <td><p class="text-black" id="entry_dae"></p></td>-->
                                <!--</tr>-->
                                <!-- <tr>-->
                                <!--    <th><p class="text-black">Entry Date :</p></th>-->
                                <!--    <td><p class="text-black" id="entry_dae"></p></td>-->
                                <!--</tr>-->
                                <tr>
                                    <th><p class="text-black">Action Date :</p></th>
                                    <td><p class="text-black" id="employee_remark_date"></p></td>
                                </tr>
                                <!--<tr>-->
                                <!--    <th><p class="text-black">Retailer Remark:</p></th>-->
                                <!--    <td><p class="text-black" id="remark1"></p></td>-->
                                <!--    <td colspan="2" style="text-align:center"><button class="btn btn-light btn-sm mt-2" onclick="copyremark1()">Copy Remark 1</button></td>-->
                                <!--</tr>-->
                                <!-- <tr>-->
                                <!--    <th><p class="text-black">Employee Remark :</p></th>-->
                                <!--    <td><textarea class="form-control" rows="3" id="remark2"></textarea></td>-->
                                <!--    <td colspan="2" style="text-align:center"></td>-->
                                <!--</tr>-->
                                
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--end page wrapper -->
                </div>
            </div>
        </div>
        
        <!-- end page title -->
    </div>
    
    <!-- container-fluid -->
</div>

<!-- End Page-content -->
<script>
    $(document).ready(function () {

        // $(document).find("title").text("Admin Dashboard");

        $(document).find("#add-coins").click(function(e){
            e.preventDefault();
            var retailer_username = $(document).find("#username").val();
            var coins = $(document).find("#coins").val();
            if(username=="")
            {
                Swal.fire({position:"top-end",icon:"warning",title:"Username is required!",showConfirmButton:!1,timer:1500});
            } 
            else if(coins == "")
            {
                Swal.fire({position:"top-end",icon:"warning",title:"Recharge Coin is required!",showConfirmButton:!1,timer:1500});
            }
            else if(coins <= 5)
            {
                Swal.fire({position:"top-end",icon:"warning",title:"Coins must be greater than 5",showConfirmButton:!1,timer:1500});
            }
            else
            {
                $.ajax({
                    url: '<?php echo base_url('admin/rechargecoinswithusername') ?>',
                    method: 'POST',
                    data: 
                    {
                        retailer_username: retailer_username,
                        coins: coins
                    },
                    success: function (response) 
                    {
                        var res = JSON.parse(response);
                        if(res['statusCode'] == 3)
                        {
                            Swal.fire({position:"top-end",icon:"success",title:res['Message'],showConfirmButton:!1,timer:1500});
                            window.location.reload();
                        }
                        else if(res['statusCode'] == 2)
                        {
                            Swal.fire({position:"top-end",icon:"warning",title:res['Message'],showConfirmButton:!1,timer:1500});
                        }
                        else if(res['statusCode'] == 0)
                        {
                            Swal.fire({position:"top-end",icon:"warning",title:res['Message'],showConfirmButton:!1,timer:1500});
                        }
                    }
                })
            }
        });        
    });
    $(document).ready(function () {
        
        function copycontact() {
            var copyText = document.getElementById("contact");
            contact.select();
           contact.setSelectionRange(0, 99999);

           navigator.clipboard.writeText(contact.value);
        }



        $('#search').on('click', function(event){
            event.preventDefault();
            var vle_id = $(document).find("#vle_id").val();
            if(vle_id=="")
            {
                warning_noti("Ref ID is required!");
            }
            else
            {

                $.ajax({
                    url: '<?php echo base_url('administrator/searchath') ?>',
                    method: 'POST',
                    data: {
                        vle_id: vle_id
                        },
                    success: function (response) 
                    {
                        var res = JSON.parse(response);
                        if(res['statusCode'] == 1)
                        {
                            $("#details-container").css("display", "block");
                            $("#name").text(res['data']['name']);
                            $("#vle_ids").text(res['data']['vle_id']);
                            $("#contact").text(res['data']['contact']);
                            $("#dob").text(res['data']['dob']);
                            $("#purpose").text(res['data']['purpose']);
                            $("#adhaar_no").text(res['data']['adhaar_no']);
                            $("#type").text(res['data']['type']);
                            $("#remark1").text(res['data']['remark1']);
                            $("#remark2").val(res['data']['remark2']);
                            $("#member_id").val(res['data']['id']);
                            $("#employee_name").text(res['data']['employee_name']);
                            $("#employee_remark_date").text(res['data']['employee_remark_date']);
                            $("#username").text(res['data']['retailer_id']);
                            $("#finger-print-url").attr("href", "<?php echo base_url('employee/fingerprints') ?>?student="+res['data']['id']);
                        }
                        else if(res['statusCode'] == 2)
                        {
                            warning_noti(res['Message']);
                        }
                        else if(res['statusCode'] == 0)
                        {
                            error_noti(res['Message']);
                        }
                    }
                })
            }
        });
        function error_noti(message) 
        {
            Lobibox.notify('error', {
                pauseDelayOnHover: true,
                continueDelayOnInactiveTab: false,
                position: 'top right',
                icon: 'bx bx-x-circle',
                msg: message
            });
        }
        function warning_noti(message) 
        {
            Lobibox.notify('warning', {
                pauseDelayOnHover: true,
                continueDelayOnInactiveTab: false,
                position: 'top right',
                icon: 'bx bx-error',
                msg: message
            });
        }
        function success_noti(message) 
        {
            Lobibox.notify('success', {
                pauseDelayOnHover: true,
                continueDelayOnInactiveTab: false,
                position: 'top right',
                icon: 'bx bx-check-circle',
                msg: message
            });
        }

        $(document).find("title").text("Service Plus Partner");
    }); 
</script>


<!--<script>-->
<!--    $(document).ready(function () {-->
        
<!--        function copycontact() {-->
<!--            var copyText = document.getElementById("contact");-->
<!--            contact.select();-->
<!--          contact.setSelectionRange(0, 99999);-->

<!--          navigator.clipboard.writeText(contact.value);-->
<!--        }-->



<!--        $('#search').on('click', function(event){-->
<!--            event.preventDefault();-->
<!--            var vle_id = $(document).find("#vle_id").val();-->
<!--            if(vle_id=="")-->
<!--            {-->
<!--                warning_noti("Ref ID is required!");-->
<!--            }-->
<!--            else-->
<!--            {-->

<!--                $.ajax({-->
<!--                    url: '<?php echo base_url('administrator/searchath') ?>',-->
<!--                    method: 'POST',-->
<!--                    data: {-->
<!--                        vle_id: vle_id-->
<!--                        },-->
<!--                    success: function (response) -->
<!--                    {-->
<!--                        var res = JSON.parse(response);-->
<!--                        if(res['statusCode'] == 1)-->
<!--                        {-->
<!--                            $("#details-container").css("display", "block");-->
<!--                            $("#name").text(res['data']['name']);-->
<!--                            $("#vle_ids").text(res['data']['vle_id']);-->
<!--                            $("#contact").text(res['data']['contact']);-->
<!--                            $("#dob").text(res['data']['dob']);-->
<!--                            $("#purpose").text(res['data']['purpose']);-->
<!--                            $("#adhaar_no").text(res['data']['adhaar_no']);-->
<!--                            $("#type").text(res['data']['type']);-->
<!--                            $("#remark1").text(res['data']['remark1']);-->
<!--                            $("#remark2").val(res['data']['remark2']);-->
<!--                            $("#member_id").val(res['data']['id']);-->
<!--                            $("#employee_name").text(res['data']['employee_name']);-->
<!--                            $("#employee_remark_date").text(res['data']['employee_remark_date']);-->
<!--                            $("#username").text(res['data']['retailer_id']);-->
<!--                            $("#finger-print-url").attr("href", "<?php echo base_url('employee/fingerprints') ?>?student="+res['data']['id']);-->
<!--                        }-->
<!--                        else if(res['statusCode'] == 2)-->
<!--                        {-->
<!--                            warning_noti(res['Message']);-->
<!--                        }-->
<!--                        else if(res['statusCode'] == 0)-->
<!--                        {-->
<!--                            error_noti(res['Message']);-->
<!--                        }-->
<!--                    }-->
<!--                })-->
<!--            }-->
<!--        });-->
<!--        function error_noti(message) -->
<!--        {-->
<!--            Lobibox.notify('error', {-->
<!--                pauseDelayOnHover: true,-->
<!--                continueDelayOnInactiveTab: false,-->
<!--                position: 'top right',-->
<!--                icon: 'bx bx-x-circle',-->
<!--                msg: message-->
<!--            });-->
<!--        }-->
<!--        function warning_noti(message) -->
<!--        {-->
<!--            Lobibox.notify('warning', {-->
<!--                pauseDelayOnHover: true,-->
<!--                continueDelayOnInactiveTab: false,-->
<!--                position: 'top right',-->
<!--                icon: 'bx bx-error',-->
<!--                msg: message-->
<!--            });-->
<!--        }-->
<!--        function success_noti(message) -->
<!--        {-->
<!--            Lobibox.notify('success', {-->
<!--                pauseDelayOnHover: true,-->
<!--                continueDelayOnInactiveTab: false,-->
<!--                position: 'top right',-->
<!--                icon: 'bx bx-check-circle',-->
<!--                msg: message-->
<!--            });-->
<!--        }-->

<!--        $(document).find("title").text("Search Member");-->
<!--    }); -->
<!--</script>-->