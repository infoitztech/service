<div class="page-content">
    <div class="container-fluid">

        <!-- start page title -->
        <div class="row">
            <div class="col-12">
                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                    <h5 class="mb-sm-0 font-size-17">Retailer</h5>
                </div>
            </div>
        </div>
        <!-- end page title -->

        <div class="row">
            <div class="col-12">
                <div class="card">
                    <form enctype="multipart/form-data" id="retailer-form">
                        <div class="card-header">
                            <h4 class="card-title">Create New Retailer</h4>
                        </div>
                        
                        <div class="card-body">
    <div class="row">
        <div class="col-lg-3 mb-2">
            <div class="mb-3">
                <label for="name">Name *</label>
                <input type="text" class="form-control" id="name" name="name" required>
            </div>
        </div>
        <div class="col-lg-3 mb-2">
            <div class="mb-3">
                <label for="contact">Mobile Number *</label>
                <input type="tel" class="form-control" id="contact" name="contact" required placeholder="Enter your 10-digit mobile number (e.g. 9876543210)" pattern="[0-9]{10}" required>
            </div>
        </div>
        <div class="mb-3">
  <label for="state">State *</label>
  <select class="form-control" id="state" name="state" required>
    <option value="" selected disabled>Select State</option>
    <option value="Andhra Pradesh">Andhra Pradesh</option>
    <option value="Arunachal Pradesh">Arunachal Pradesh</option>
    <option value="Assam">Assam</option>
    <option value="Bihar">Bihar</option>
    <option value="Chhattisgarh">Chhattisgarh</option>
    <option value="Goa">Goa</option>
    <option value="Gujarat">Gujarat</option>
    <option value="Haryana">Haryana</option>
    <option value="Himachal Pradesh">Himachal Pradesh</option>
    <option value="Jharkhand">Jharkhand</option>
    <option value="Karnataka">Karnataka</option>
    <option value="Kerala">Kerala</option>
    <option value="Madhya Pradesh">Madhya Pradesh</option>
    <option value="Maharashtra">Maharashtra</option>
    <option value="Manipur">Manipur</option>
    <option value="Meghalaya">Meghalaya</option>
    <option value="Mizoram">Mizoram</option>
    <option value="Nagaland">Nagaland</option>
    <option value="Odisha">Odisha</option>
    <option value="Punjab">Punjab</option>
    <option value="Rajasthan">Rajasthan</option>
    <option value="Sikkim">Sikkim</option>
    <option value="Tamil Nadu">Tamil Nadu</option>
    <option value="Telangana">Telangana</option>
    <option value="Tripura">Tripura</option>
    <option value="Uttar Pradesh">Uttar Pradesh</option>
    <option value="Uttarakhand">Uttarakhand</option>
    <option value="West Bengal">West Bengal</option>
  </select>
</div>
<div class="mb-3">
    <label for="pincode">Pin Code *</label>
    <input type="text" class="form-control" id="pin_code" name="pin_code" pattern="[0-9]{6}" required>
</div>

        <div class="col-lg-3 mb-2">
            <div class="mb-3">
                <label for="email">Email *</label>
                <input type="email" class="form-control" id="email" name="email" required>
            </div>
        </div>
        <div class="col-lg-3 mb-2">
            <div class="mb-3">
                <label for="profile-photo">Profile Photo</label>
                <input type="file" class="form-control" id="profile-photo" name="profile-photo">
            </div>
        </div>
        <div class="col-lg-3">
            <div class="mb-3">
                <label for="username">Username *</label>
                <input type="text" class="form-control" id="username" name="username" required pattern="[^\s]+" required>
            </div>
        </div>
        <div class="col-lg-3">
            <div class="mb-3">
                <label for="password">username and Password will be sent through WhatsApp to the registered number</label>
                <input type="text" class="form-control" hidden id="password" name="password" value="hgchc@5465" readonly>
            </div>
        </div>
    </div>
</div>

<!--                        <div class="card-body">-->
<!--                            <div class="row">-->
<!--                                <div class="col-lg-3 mb-2">-->
<!--                                    <div class="mb-3">-->
<!--                                        <label>Name *</label>-->
<!--                                        <input type="text" class="form-control" id="name" name="name">-->
<!--                                    </div>-->
<!--                                </div>-->
<!--                                <div class="col-lg-3 mb-2">-->
<!--                                    <div class="mb-3">-->
<!--                                        <label>Mobile Number *</label>-->
<!--                                        <input type="text" class="form-control" id="contact" name="contact">-->
<!--                                    </div>-->
<!--                                </div>-->
<!--                                <div class="col-lg-3 mb-2">-->
<!--                                    <div class="mb-3">-->
<!--                                        <label>Email *</label>-->
<!--                                         <input type="email" class="form-control" id="email" name="email">-->
<!--                                    </div>-->
<!--                                </div>-->
<!--                                <div class="col-lg-3 mb-2">-->
<!--                                    <div class="mb-3">-->
<!--                                        <label>Profile Photo </label>-->
<!--                                        <input type="file" class="form-control" id="profile-photo" name="profile-photo">-->
<!--                                    </div>-->
<!--                                </div>-->
<!--                                <div class="col-lg-3">-->
<!--                                    <div class="mb-3">-->
<!--                                        <label>Username *</label>-->
<!--                                        <input type="text" class="form-control" id="username" name="username">-->
<!--                                    </div>-->
<!--                                </div>-->
<!--                                <div class="col-lg-3">-->
<!--                                    <div class="mb-3">-->
<!--  <label>User name Password will be sent through WhatsApp to the registered number</label>-->
<!--  <input type="text" class="form-control" hidden id="password" name="password">-->
<!--</div>-->
<!--<script>-->
<!--  function generatePassword() {-->
<!--    var length = 8;-->
<!--    var charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+~`|}{[]\:;?><,./-=";-->
<!--    var password = "";-->
<!--    for (var i = 0; i < length; i++) {-->
<!--      password += charset.charAt(Math.floor(Math.random() * charset.length));-->
<!--    }-->
<!--    return password;-->
<!--  }-->

 <!--Call generatePassword() and insert the generated password into the input field-->
<!--  document.addEventListener('DOMContentLoaded', function() {-->
<!--    var passwordInput = document.getElementById('password');-->
<!--    passwordInput.value = generatePassword();-->
<!--  });-->
<!--</script>-->


// <script>
//   function generatePassword() {
//     var length = 8;
//     var charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
//     var password = "";
//     for (var i = 0; i < length; i++) {
//       password += charset.charAt(Math.floor(Math.random() * charset.length));
//     }
//     return password;
//   }

//   // Call generatePassword() and insert the generated password into the input field
//   document.addEventListener('DOMContentLoaded', function() {
//     var passwordInput = document.getElementById('password');
//     passwordInput.value = generatePassword();
//   });
// </script>

                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-3 mx-auto">
                                <div class="mb-3"></div>
                                    <button class="btn btn-primary mx-5 waves-effect waves-light mb-3">Create Retailer</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <!-- end cardaa -->
            </div> <!-- end col -->
        </div> <!-- end row -->
    </div>
</div>
<script>
    $(document).ready(function () {
        $('#retailer-form').on('submit', function(event){
            event.preventDefault();
            var name = $(document).find("#name").val();
            var username = $(document).find("#username").val();
            var password = $(document).find("#password").val();
            if(name=="")
            {
                Swal.fire({position:"top-end",icon:"warning",title:"Retailer Name is required!",showConfirmButton:!1,timer:1500});
            }
            else if(username == "")
            {
                Swal.fire({position:"top-end",icon:"warning",title:"Username is required!",showConfirmButton:!1,timer:1500});
            }
            else if(password == "")
            {
                Swal.fire({position:"top-end",icon:"warning",title:"Password is required!",showConfirmButton:!1,timer:1500});
            }
            else
            {

                var formData = new FormData(this);
                $.ajax({
                    url: '<?php echo base_url('admins/createretailerath') ?>',
                    method:"POST",
                    data: formData,
                    contentType:false,
                    cache:false,
                    processData:false,
                    success:function(response)
                    {
                        var res = JSON.parse(response);
                        if(res['statusCode'] == 5)
                        {
                            Swal.fire({position:"top-end",icon:"success",title: res['Message'],showConfirmButton:!1,timer:1500});
                            $('#retailer-form').trigger("reset");
                        }
                        else if(res['statusCode'] == 4)
                        {
                            Swal.fire({position:"top-end",icon:"warning",title:res['Message'],showConfirmButton:!1,timer:1500});
                        }
                        else if(res['statusCode'] == 3)
                        {
                            Swal.fire({position:"top-end",icon:"warning",title:res['Message'],showConfirmButton:!1,timer:1500});
                        }
                        else if(res['statusCode'] == 2)
                        {
                            Swal.fire({position:"top-end",icon:"warning",title:res['Message'],showConfirmButton:!1,timer:1500});
                        }
                        else if(res['statusCode'] == 1)
                        {
                            Swal.fire({position:"top-end",icon:"warning",title:res['Message'],showConfirmButton:!1,timer:1500});
                        }
                        else if(res['statusCode'] == 0)
                        {
                            Swal.fire({position:"top-end",icon:"warning",title:res['Message'],showConfirmButton:!1,timer:1500});
                        }
                    }
                });
            }
        });


        $(document).find("title").text("Create Retailer");
    }); 
</script>
