<!--start page wrapper -->
<div class="page-wrapper">
    <div class="page-content">
        <div class="row">
            <div class="col-xl-8 mx-auto">
                <div class="card border-top border-0 border-4 border-white">
                    <div class="card-body p-5">
                        <div class="card-title d-flex align-items-center">
                            <h6 class="mb-0 text-white">Search Member</h6>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-lg-6 mx-auto">
                                <div class="input-group">
									<input type="text" class="form-control" id="vle_id" placeholder="Enter Ref. ID">
									<button class="btn btn-light" type="button" id="search">Button</button>
								</div>
                            </div>
                        </div>
                        <div class="row mt-3" id="details-container" style="display : none; width: 350px" >   
                            <table>
                                <tr style="width : 20%">
                                    <th><p class="text-white">Ref. ID :</p></th>
                                    <td><p class="text-white" id="vle_ids"></p></td>
                                </tr>
                                <tr style="width : 20%">
                                    <th><p class="text-white">user id :</p></th>
                                    <td><p class="text-white" id="username"></p></td>
                                </tr>
                                <tr>
                                    <th><p class="text-white">Name :</p></th>
                                    <td><p class="text-white" id="name"></p></td>
                                </tr>
                                <tr>
                                    <th><p class="text-white">DOB :</p></th>
                                    <td><p class="text-white" id="dob"></p></td>
                                </tr>
                                <tr>
                                    <th><p class="text-white">Contact :</p></th>
                                    <td><p class="text-white" id="contact" ></p></td>
                                    <td colspan="2" style="text-align:center">
                                    <button class="btn btn-light btn-sm mt-2" onclick="copycontact()">Copy Contact</button></td>
                                </tr>
                                <tr>
                                    <th><p class="text-white">Adhaar No :</p></th>
                                    <td><p class="text-white" id="adhaar_no"></p></td>
                                </tr>
                                <tr>
                                    <th><p class="text-white">Type :</p></th>
                                    <td><p class="text-white" id="type"></p></td>
                                </tr>
                                <tr>
                                    <th><p class="text-white">Purpose :</p></th>
                                    <td><p class="text-white" id="purpose"></p></td>
                                    <td colspan="2" style="text-align:center"><button class="btn btn-light btn-sm mt-2" onclick="copypurpose()">Copy Purpose</button></td>
                                </tr>
                                <tr>
                                    <th><p class="text-white">employee name :</p></th>
                                    <td><p class="text-white" id="employee_name"></p></td>
                                </tr>
                                <tr>
                                    <th><p class="text-white">Action Date :</p></th>
                                    <td><p class="text-white" id="employee_remark_date"></p></td>
                                </tr>
                                <tr>
                                    <th><p class="text-white">Retailer Remark:</p></th>
                                    <td><p class="text-white" id="remark1"></p></td>
                                    <td colspan="2" style="text-align:center"><button class="btn btn-light btn-sm mt-2" onclick="copyremark1()">Copy Remark 1</button></td>
                                </tr>
                                <tr>
                                    <th><p class="text-white">Employee Remark :</p></th>
                                    <td><textarea class="form-control" rows="3" id="remark2"></textarea></td>
                                    <td colspan="2" style="text-align:center"><button class="btn btn-light btn-sm mt-2" onclick="myFunction()">Copy Remark 2</button></td>
                                </tr>
                                
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--end page wrapper -->

<script>
    $(document).ready(function () {
        
        function copycontact() {
            var copyText = document.getElementById("contact");
            contact.select();
           contact.setSelectionRange(0, 99999);

           navigator.clipboard.writeText(contact.value);
        }



        $('#search').on('click', function(event){
            event.preventDefault();
            var vle_id = $(document).find("#vle_id").val();
            if(vle_id=="")
            {
                warning_noti("Ref ID is required!");
            }
            else
            {

                $.ajax({
                    url: '<?php echo base_url('administrator/searchath') ?>',
                    method: 'POST',
                    data: {
                        vle_id: vle_id
                        },
                    success: function (response) 
                    {
                        var res = JSON.parse(response);
                        if(res['statusCode'] == 1)
                        {
                            $("#details-container").css("display", "block");
                            $("#name").text(res['data']['name']);
                            $("#vle_ids").text(res['data']['vle_id']);
                            $("#contact").text(res['data']['contact']);
                            $("#dob").text(res['data']['dob']);
                            $("#purpose").text(res['data']['purpose']);
                            $("#adhaar_no").text(res['data']['adhaar_no']);
                            $("#type").text(res['data']['type']);
                            $("#remark1").text(res['data']['remark1']);
                            $("#remark2").val(res['data']['remark2']);
                            $("#member_id").val(res['data']['id']);
                            $("#employee_name").text(res['data']['employee_name']);
                            $("#employee_remark_date").text(res['data']['employee_remark_date']);
                            $("#username").text(res['data']['retailer_id']);
                            $("#finger-print-url").attr("href", "<?php echo base_url('employee/fingerprints') ?>?student="+res['data']['id']);
                        }
                        else if(res['statusCode'] == 2)
                        {
                            warning_noti(res['Message']);
                        }
                        else if(res['statusCode'] == 0)
                        {
                            error_noti(res['Message']);
                        }
                    }
                })
            }
        });
        function error_noti(message) 
        {
            Lobibox.notify('error', {
                pauseDelayOnHover: true,
                continueDelayOnInactiveTab: false,
                position: 'top right',
                icon: 'bx bx-x-circle',
                msg: message
            });
        }
        function warning_noti(message) 
        {
            Lobibox.notify('warning', {
                pauseDelayOnHover: true,
                continueDelayOnInactiveTab: false,
                position: 'top right',
                icon: 'bx bx-error',
                msg: message
            });
        }
        function success_noti(message) 
        {
            Lobibox.notify('success', {
                pauseDelayOnHover: true,
                continueDelayOnInactiveTab: false,
                position: 'top right',
                icon: 'bx bx-check-circle',
                msg: message
            });
        }

        $(document).find("title").text("Search Member");
    }); 
</script>