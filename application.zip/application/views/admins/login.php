<!doctype html>
<html lang="en">

    
    <head>

        <meta charset="utf-8" />
        <title>Admin Login </title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="VLE" name="description" />
        <meta content="Admin" name="author" />
        <!-- App favicon -->
        <link rel="shortcut icon" href="<?php echo base_url('myassets/images/favicon.ico') ?>">

        <!-- preloader css -->
        <link rel="stylesheet" href="<?php echo base_url('myassets/css/preloader.min.css') ?>" type="text/css') ?>" />

        <!-- Bootstrap Css -->
        <link href="<?php echo base_url('myassets/css/bootstrap.min.css') ?>" id="bootstrap-style" rel="stylesheet" type="text/css" />
        <!-- Icons Css -->
        <link href="<?php echo base_url('myassets/css/icons.min.css') ?>" rel="stylesheet" type="text/css" />
        <!-- App Css-->
        <link href="<?php echo base_url('myassets/css/app.min.css') ?>" id="app-style" rel="stylesheet" type="text/css" />

        <!-- alertifyjs default themes  Css -->
        <link href="<?php echo base_url('myassets/libs/sweetalert2/sweetalert2.min.css') ?>" rel="stylesheet" type="text/css" />

    </head>

    <body>

    <!-- <body data-layout="horizontal"> -->
        <div class="auth-page">
            <div class="container-fluid p-0">
                <div class="row g-0">
                    <div class="col-xxl-3 col-lg-4 col-md-5">
                        <div class="auth-full-page-content d-flex p-sm-5 p-4">
                            <div class="w-100">
                                <div class="d-flex flex-column h-100">
                                    <div class="auth-content my-auto">
                                        <div class="text-center">
                                            <h5 class="mb-0"><?php echo $school_data['school_name'] ?></h5>
                                            <p class="text-muted mt-2">Sign in as Admin.</p>
                                        </div>
                                        <form class="mt-4 pt-2" action="#">
                                            <div class="mb-3">
                                                <label class="form-label">Username</label>
                                                <input type="text" class="form-control" id="username" placeholder="Enter username">
                                            </div>
                                            <div class="mb-3">
                                                <div class="d-flex align-items-start">
                                                    <div class="flex-grow-1">
                                                        <label class="form-label">Password</label>
                                                    </div>
                                                    <div class="flex-shrink-0">
                                                        <div class="">
                                                            <!--<a href="<?php echo base_url('admin/forgetpassword')."?school=".$this->input->get('school'); ?>" class="text-muted">Forgot password?</a>-->
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="input-group auth-pass-inputgroup">
                                                    <input type="password" class="form-control" placeholder="Enter password" aria-label="Password" aria-describedby="password-addon" id="password">
                                                    <button class="btn btn-light shadow-none ms-0" type="button" id="password-addon"><i class="mdi mdi-eye-outline"></i></button>
                                                </div>
                                            </div>
                                            <div class="mb-3 mb-4">
                                                <button class="btn btn-primary w-100 waves-effect waves-light login-btn">Log In</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- end auth full page content -->
                    </div>
                    <!-- end col -->
                    <div class="col-xxl-9 col-lg-8 col-md-7">
                        <div class="auth-bg pt-md-5 p-4 d-flex">
                            <div class="bg-overlay bg-primary"></div>
                            <ul class="bg-bubbles">
                                <li></li>
                                <li></li>
                                <li></li>
                                <li></li>
                                <li></li>
                                <li></li>
                                <li></li>
                                <li></li>
                                <li></li>
                                <li></li>
                            </ul>
                            <!-- end bubble effect -->
                            <div class="row justify-content-center align-items-center">
                                <div class="col-xl-7">
                                    <div class="p-0 p-sm-4 px-xl-0">
                                        <div id="reviewcarouselIndicators" class="carousel slide" data-bs-ride="carousel">
                                            <div class="carousel-indicators carousel-indicators-rounded justify-content-start ms-0 mb-0">
                                                <button type="button" data-bs-target="#reviewcarouselIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                                                <button type="button" data-bs-target="#reviewcarouselIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
                                                <button type="button" data-bs-target="#reviewcarouselIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
                                            </div>
                                            <!-- end carouselIndicators -->
                                            <div class="carousel-inner">
                                                <div class="carousel-item active">
                                                    <div class="testi-contain text-white">
                                                        <i class="bx bxs-quote-alt-left text-success display-6"></i>

                                                        <h4 class="mt-4 fw-medium lh-base text-white">“Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.”
                                                        </h4>
                                                        
                                                    </div>
                                                </div>

                                                <div class="carousel-item">
                                                    <div class="testi-contain text-white">
                                                        <i class="bx bxs-quote-alt-left text-success display-6"></i>

                                                        <h4 class="mt-4 fw-medium lh-base text-white">“Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. ”</h4>
                                                        
                                                    </div>
                                                </div>

                                                <div class="carousel-item">
                                                    <div class="testi-contain text-white">
                                                        <i class="bx bxs-quote-alt-left text-success display-6"></i>

                                                        <h4 class="mt-4 fw-medium lh-base text-white">“Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. ”</h4>
                                                        
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- end carousel-inner -->
                                        </div>
                                        <!-- end review carousel -->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- end col -->
                </div>
                <!-- end row -->
            </div>
            <!-- end container fluid -->
        </div>


        <!-- JAVASCRIPT -->
        <script src="<?php echo base_url('myassets/libs/jquery/jquery.min.js') ?>"></script>
        <script src="<?php echo base_url('myassets/libs/bootstrap/js/bootstrap.bundle.min.js') ?>"></script>
        <script src="<?php echo base_url('myassets/libs/metismenu/metisMenu.min.js') ?>"></script>
        <script src="<?php echo base_url('myassets/libs/simplebar/simplebar.min.js') ?>"></script>
        <script src="<?php echo base_url('myassets/libs/node-waves/waves.min.js') ?>"></script>
        <script src="<?php echo base_url('myassets/libs/feather-icons/feather.min.js') ?>"></script>
        <!-- pace js -->
        <script src="<?php echo base_url('myassets/libs/pace-js/pace.min.js') ?>"></script>
        <!-- password addon init -->
        <script src="<?php echo base_url('myassets/js/pages/pass-addon.init.js') ?>"></script>

        <script src="<?php echo base_url('myassets/libs/sweetalert2/sweetalert2.min.js') ?>"></script>

    </body>

</html>
<script>
    $(document).ready(function () {
        $(document).on('click','.login-btn',function(e){
            e.preventDefault();
            var username = $(document).find("#username").val();
            var password = $(document).find("#password").val();
            var school_id = $(document).find(".school_id").val();
            if(username == "")
            {
                Swal.fire({position:"top-end",icon:"warning",title:"Username is required!",showConfirmButton:!1,timer:1500});
            }
            else if(password == "")
            {
                Swal.fire({position:"top-end",icon:"warning",title:"Password is required!",showConfirmButton:!1,timer:1500});
            }
            else if(school_id == "")
            {
                Swal.fire({position:"top-end",icon:"warning",title:"Something is wrong! Try again later",showConfirmButton:!1,timer:1500});
            }
            else
            {
                $.ajax({
                url: '<?php echo base_url('admins/loginAuthentication') ?>',
                type:"post",
                data: {
                        username: username,
                        password: password
                        },                
                    cache:false,
                    success: function(response)
                    {
                        var res = JSON.parse(response);
                        if(res['statusCode'] == "0")
                        {
                            Swal.fire({position:"top-end",icon:"danger",title:"Something is wrong! Try again later",showConfirmButton:!1,timer:1500}); 
                        }
                        else if(res['statusCode'] == "3")
                        {
                            Swal.fire({position:"top-end",icon:"warning",title:"Incorrect Username & Password!",showConfirmButton:!1,timer:1500}); 
                        }
                        else if(res['statusCode'] == "2")
                        {
                            Swal.fire({position:"top-end",icon:"warning",title:"Your account has been blocked",showConfirmButton:!1,timer:1500});
                        }
                        else if(res['statusCode'] == "1")
                        {
                            window.location.href= "<?php echo base_url('admins/dashboard') ?>";
                        }
                        else
                        {
                            Swal.fire({position:"top-end",icon:"danger",title:"Something is wrong! Try again later",showConfirmButton:!1,timer:1500}); 
                        }
                    }
                });
            }
        });
    });

</script>