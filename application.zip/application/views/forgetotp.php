<!doctype html>
<html lang="en">
<head>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!--favicon-->
	<link rel="icon" href="<?php echo base_url('assets/images/favicon-32x32.png'); ?>" type="image/png" />
	<!--plugins-->
	<link rel="stylesheet" href="<?php echo base_url('assets/plugins/notifications/css/lobibox.min.css'); ?>" />
	<link href="<?php echo base_url('assets/plugins/simplebar/css/simplebar.css'); ?>" rel="stylesheet" />
	<link href="<?php echo base_url('assets/plugins/perfect-scrollbar/css/perfect-scrollbar.css'); ?>" rel="stylesheet" />
	<link href="<?php echo base_url('assets/plugins/metismenu/css/metisMenu.min.css'); ?>" rel="stylesheet" />
	<!-- loader-->
	<link href="<?php echo base_url('assets/css/pace.min.css'); ?>" rel="stylesheet" />
	<script src="<?php echo base_url('assets/js/pace.min.js'); ?>"></script>
	<!-- Bootstrap CSS -->
	<link href="<?php echo base_url('assets/css/bootstrap.min.css'); ?>" rel="stylesheet">
	<link href="<?php echo base_url('assets/css/app.css'); ?>" rel="stylesheet">
	<link href="<?php echo base_url('assets/css/icons.css'); ?>" rel="stylesheet">
	<title>VLE Adda-Retailer Login</title>
</head>

<body class="bg-theme bg-theme12">
	<!--wrapper-->
	<div class="wrapper">
		<div class="section-authentication-signin d-flex align-items-center justify-content-center my-5 my-lg-0">
			<div class="container-fluid">
				<div class="row row-cols-1 row-cols-lg-2 row-cols-xl-3">
					<div class="col mx-auto">
						<div class="card">
							<div class="card-body">
								<div class="border p-4 rounded">
									<div class="row">
										<div class="col-12">
											<div class="d-flex flex-column align-items-center text-center">
												<img src="<?php echo base_url('assets/images/superadmin.png') ?>" class="rounded-circle p- bg-light mb-3" width="110">
											</div>
										</div>
										<div class="col-12">
											<div class="d-flex flex-column align-items-center text-center">
												<h4 class="text-white text-center">VLE Adda</h4>
											</div>
										</div>
										<div class="col-12">
											<div class="d-flex flex-column align-items-center text-center">
												<h5 class="text-white text-center">OTP has been sent on your registered email</h5>
											</div>
										</div>
									</div>
									<div class="form-body">
										<form class="row g-3" id="forgetotp_form" name="forgetotp_form">
											<div class="col-12">
												<label for="otp" class="form-label">OTP</label>
												<input type="otp" class="form-control" id="otp" name="otp" placeholder="Enter OTP">
											</div>
											<div class="col-12">
												<label for="cotp" class="form-label">Confirm OTP</label>
												<input type="cotp" class="form-control" id="cotp" name="cotp" placeholder="Confirm OTP">
											</div>
											<input type="hidden" id="email" name="email" value="{{session('administrator_email')}}">

											<div class="d-md-flex justify-content-between my-4">
                                				<p>
                                    				Back to Login 
                                    				<a href="<?php echo base_url('administrator'); ?>" class="text-white">Click Here</a>
                                				</p>
												
											</div>
											<div class="col-12">
												<div class="d-grid">
													<button class="btn btn-light" id="forgetotp-btn"><i class="bx bxs-lock-open"></i>Veiry Now</button>
												</div>
											</div>
										</form>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!--end row-->
			</div>
		</div>
	</div>
	<!--end wrapper-->
<!-- Bootstrap JS -->
<script src="<?php echo base_url('assets/js/bootstrap.bundle.min.js'); ?>"></script>
<!--plugins-->
<script src="<?php echo base_url('assets/js/jquery.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/plugins/simplebar/js/simplebar.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/plugins/metismenu/js/metisMenu.min.js'); ?>"></script>
<!--Password show & hide js -->
<!--notification js -->
<script src="<?php echo base_url('assets/plugins/notifications/js/lobibox.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/plugins/notifications/js/notifications.min.js'); ?>"></script>
<script >
	$(document).ready(function(){
		$(document).on('click','#forgetotp-btn',function(e){
			e.preventDefault();
			var otp = $(document).find("#otp").val();
        	var cotp = $(document).find("#cotp").val();
        	if(otp == "")
			{
				warning_noti("OTP is required!");
			}
			else if(cotp == "")
			{
				warning_noti("Confirm OTP is required!");
			}
			else if(otp != cotp)
			{
				warning_noti("OTP  and confirm OTP does not match");
			}
			else
			{
                var data = $(document).find("#forgetotp_form").serialize();
                $.ajax({
					url: '<?php echo base_url('administrator/forgetotpath') ?>',
					type:"post",
					data: {
						otp: otp,
						},
					cache:false,
					success: function(response)
					{
						var res = JSON.parse(response);
						if(res['statusCode'] == "2")
						{
							warning_noti(res['Message']);
						}
						else if(res['statusCode'] == "1")
						{
							success_noti(res['Message']);
							window.location.href= "<?php echo base_url('administrator/newpassword') ?>";
						}
						else if(res['statusCode'] == "3")
						{
							error_noti(res['Message']);
						}
						else
						{
							error_noti(res['Message']);
						}
					}
				});
			}
		});
		$(document).find("title").text("Forget OTP Form");
	});
	function error_noti(message) 
		{
			Lobibox.notify('error', {
				pauseDelayOnHover: true,
				continueDelayOnInactiveTab: false,
				position: 'top right',
				icon: 'bx bx-x-circle',
				msg: message
			});
		}
		function warning_noti(message) 
		{
			Lobibox.notify('warning', {
				pauseDelayOnHover: true,
				continueDelayOnInactiveTab: false,
				position: 'top right',
				icon: 'bx bx-error',
				msg: message
			});
		}
		function success_noti(message) 
		{
			Lobibox.notify('success', {
				pauseDelayOnHover: true,
				continueDelayOnInactiveTab: false,
				position: 'top right',
				icon: 'bx bx-check-circle',
				msg: message
			});
		}
</script>
