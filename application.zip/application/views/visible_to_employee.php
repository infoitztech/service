<!--start page wrapper -->
<div class="page-wrapper">
    <div class="page-content">
        <h5 class="mb-0 text-uppercase">Remove from Employee Dashboard</h5>
        <hr/>
        <div class="card">
            <div class="card-body">
                <div class="d-lg-flex align-items-center mb-4 gap-3">
                    <div class="position-relative">
                        <h6>Member List</h6>
                        <button class="btn btn-light btn-sm save-changes">Save Changes</button>
                    </div>
                </div>
                <div class="table-responsive">
                    <table id="studenttable" class="table mb-0">
                        <thead>
                            <tr class="bg-light">
                                <td><input type="checkbox" class="form-check-input select-member"></td>
                                <th>Ref. No.</th>
                                <th>Name</th>
                                <th>Type</th>
                                <th>Purpose</th>
                                <th>Status</th>
                                <th>Retailer</th>
                                <th>Created Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($user_data as $data) {   ?>
                            <tr>
                                <td><input type="checkbox" class="form-check-input select-member" value="<?php echo $data['id'] ?>"></td>
                                <td>#<?php echo $data['ref_id']; ?></td>
                                <td><?php echo $data['member_name']; ?></td>
                                <td><?php echo $data['type']; ?></td>
                                <td><?php echo $data['purpose']; ?></td>
                                <td>
                                    <?php if($data['status']=="Success") { ?>
                                    <button class="btn btn-success btn-sm">Success</button>
                                    <?php }else if($data['status']=="Cancelled") { ?>
                                    <button class="btn btn-danger btn-sm">Cancelled</button>
                                    <?php } else { ?>
                                    <button class="btn btn-warning btn-sm">Pending</button>
                                    <?php } ?>
                                </td>
                                <td><?php echo $data['retailer']; ?></td>
                                <td><?php echo $data['created_date']; ?></td>
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<!--end page wrapper -->
<script>
    $(document).ready(function() {
        var table = $('#studenttable').DataTable( {
            buttons: [ 'excel'],
            "ordering": false
        } );
        
        table.buttons().container()
            .appendTo( '#studenttable_wrapper .col-md-6:eq(0)' );


        $(document).on('click','.save-changes',function(e){
            e.preventDefault();
            var member_id = $(".select-member:checkbox:checked").map(function(){
                return $(this).val();
            }).get(); 
            if(member_id =="")
            {
                alert("Student must be selected!");
            }
            else
            {
                $.ajax({
                url: '<?php echo base_url('administrator/removefromemployeeath') ?>',
                method: 'POST',
                data: {
                    member_id: member_id,
                },
                success: function (response) 
                {
                    var res = JSON.parse(response);
                    if(res['statusCode'] == 2)
                    {
                        success_noti("Members removed from employee dashboard");
                        window.location.reload();
                    }
                    else
                    {
                        warning_noti("Failed!");
                    }
                }
            })
            }
            
        });

    
        $(document).find("title").text("Remove from Employee Dashboard");
        
    });
    
        function error_noti(message) 
		{
			Lobibox.notify('error', {
				pauseDelayOnHover: true,
				continueDelayOnInactiveTab: false,
				position: 'top right',
				icon: 'bx bx-x-circle',
				msg: message
			});
		}
		function warning_noti(message) 
		{
			Lobibox.notify('warning', {
				pauseDelayOnHover: true,
				continueDelayOnInactiveTab: false,
				position: 'top right',
				icon: 'bx bx-error',
				msg: message
			});
		}
		function success_noti(message) 
		{
			Lobibox.notify('success', {
				pauseDelayOnHover: true,
				continueDelayOnInactiveTab: false,
				position: 'top right',
				icon: 'bx bx-check-circle',
				msg: message
			});
		}
</script>