<!--start page wrapper -->
<div class="page-wrapper">
    <div class="page-content">
        <div class="row">
            <div class="col-xl-8 mx-auto">
                <div class="card border-top border-0 border-4 border-white">
                    <div class="card-body p-5">
                        <div class="card-title d-flex align-items-center">
                            <h6 class="mb-0 text-white">Search Member</h6>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-lg-6 mx-auto">
                                <div class="input-group">
									<input type="text" class="form-control" id="vle_id" placeholder="Enter Ref. ID">
									<button class="btn btn-light" type="button" id="search">Button</button>
								</div>
                            </div>
                        </div>
                        <div class="row mt-3" id="details-container" style="display : none; width: 350px" >   
                            <table>
                                <tr style="width : 20%">
                                    <th><p class="text-white">Ref. ID :</p></th>
                                    <td><p class="text-white" id="vle_ids"></p></td>
                                </tr>
                                <tr>
                                    <th><p class="text-white">Name :</p></th>
                                    <td><p class="text-white" id="name"></p></td>
                                </tr>
                                <tr>
                                    <th><p class="text-white">DOB :</p></th>
                                    <td><p class="text-white" id="dob"></p></td>
                                </tr>
                                <tr>
                                    <th><p class="text-white">Contact :</p></th>
                                    <td><p class="text-white" id="contact"></p></td>
                                </tr>
                                <tr>
                                    <th><p class="text-white">Adhaar No :</p></th>
                                    <td><p class="text-white" id="adhaar_no"></p></td>
                                </tr>
                                <tr>
                                    <th><p class="text-white">Type :</p></th>
                                    <td><p class="text-white" id="type"></p></td>
                                </tr>
                                <tr>
                                    <th><p class="text-white">Purpose :</p></th>
                                    <td><p class="text-white" id="purpose"></p></td>
                                </tr>
                                <tr>
                                    <th><p class="text-white">Retailer Remark:</p></th>
                                    <td><p class="text-white" id="remark1"></p></td>
                                </tr>
                                <tr>
                                    <th><p class="text-white">Employee Remark :</p></th>
                                    <td><textarea class="form-control" rows="3" id="remark2"></textarea></td>
                                </tr>
                                <tr>
                                    <th colspan="2" style="text-align:center"><input type="checkbox" value="cancelled" id="status" class="form-check-input mt-2"><span class="mt-3 text-white"> : Mark as Cancelled if error 101/102</span></th>
                                </tr>
                                <tr>
                                    <th colspan="2" style="text-align:center"><a href="#" id="finger-print-url" class="btn btn-light btn-sm mt-2" target="_blank">View Finger Prints</a></td>
                                </tr>
                                <tr>
                                    <td colspan="2" style="text-align:center"><button id="save-remark" class="btn btn-light mt-4">Save Remarks</button></td>
                                </tr>
                                <tr>
                                    <td colspan="2" style="text-align:center"><button id="rejected" class="btn btn-light mt-4">Rejected</button></td>
                                </tr>
                                <input type="hidden" id="member_id">
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--end page wrapper -->

<script>
    $(document).ready(function () {
        $('#save-remark').on('click', function(event){
            event.preventDefault();
            var member_id = $(document).find("#member_id").val();
            var remark2 = $(document).find("#remark2").val();
            var status = $(document).find("#status:checked").val();
            var new_status = "";
            if(status == "cancelled")
            {
                new_status = "Cancelled";
            }
            else
            {
                new_status = "Success";
            }
            if(member_id=="")
            {
                warning_noti("Something is wrong! Try again later");
            }
            else
            {
                $.ajax({
                    url: '<?php echo base_url('employee/updateremark') ?>',
                    method: 'POST',
                    data: {
                        member_id: member_id,
                        remark2: remark2,
                        status : new_status
                        },
                    success: function (response) 
                    {
                        var res = JSON.parse(response);
                        if(res['statusCode'] == 1)
                        {
                            success_noti(res['Message']);
                            window.location.reload();
                        }
                        else if(res['statusCode'] == 2)
                        {
                            warning_noti(res['Message']);
                        }
                        else if(res['statusCode'] == 0)
                        {
                            error_noti(res['Message']);
                        }
                    }
                })

            }
        });

        $('#rejected').on('click', function(event){
            event.preventDefault();
            var member_id = $(document).find("#member_id").val();
            var remark2 = $(document).find("#remark2").val();
            var status = $(document).find("#status:checked").val();
            var new_status = "";
            if(status == "cancelled")
            {
                new_status = "Cancelled";
            }
            else
            {
                new_status = "rejected";
            }
            if(member_id=="")
            {
                warning_noti("Something is wrong! Try again later");
            }
            else
            {
                $.ajax({
                    url: '<?php echo base_url('employee/updateremark') ?>',
                    method: 'POST',
                    data: {
                        member_id: member_id,
                        remark2: remark2,
                        status : new_status
                        },
                    success: function (response) 
                    {
                        var res = JSON.parse(response);
                        if(res['statusCode'] == 1)
                        {
                            success_noti(res['Message']);
                            window.location.reload();
                        }
                        else if(res['statusCode'] == 2)
                        {
                            warning_noti(res['Message']);
                        }
                        else if(res['statusCode'] == 0)
                        {
                            error_noti(res['Message']);
                        }
                    }
                })

            }
        });
        
        $('#search').on('click', function(event){
            event.preventDefault();
            var vle_id = $(document).find("#vle_id").val();
            if(vle_id=="")
            {
                warning_noti("Ref ID is required!");
            }
            else
            {

                $.ajax({
                    url: '<?php echo base_url('employee/searchath') ?>',
                    method: 'POST',
                    data: {
                        vle_id: vle_id
                        },
                    success: function (response) 
                    {
                        var res = JSON.parse(response);
                        if(res['statusCode'] == 1)
                        {
                            $("#details-container").css("display", "block");
                            $("#name").text(res['data']['name']);
                            $("#vle_ids").text(res['data']['vle_id']);
                            $("#contact").text(res['data']['contact']);
                            $("#dob").text(res['data']['dob']);
                            $("#purpose").text(res['data']['purpose']);
                            $("#adhaar_no").text(res['data']['adhaar_no']);
                            $("#type").text(res['data']['type']);
                            $("#remark1").text(res['data']['remark1']);
                            $("#remark2").val(res['data']['remark2']);
                            $("#member_id").val(res['data']['id']);
                            $("#finger-print-url").attr("href", "<?php echo base_url('employee/fingerprints') ?>?student="+res['data']['id']);
                        }
                        else if(res['statusCode'] == 2)
                        {
                            warning_noti(res['Message']);
                        }
                        else if(res['statusCode'] == 0)
                        {
                            error_noti(res['Message']);
                        }
                    }
                })
            }
        });
        function error_noti(message) 
        {
            Lobibox.notify('error', {
                pauseDelayOnHover: true,
                continueDelayOnInactiveTab: false,
                position: 'top right',
                icon: 'bx bx-x-circle',
                msg: message
            });
        }
        function warning_noti(message) 
        {
            Lobibox.notify('warning', {
                pauseDelayOnHover: true,
                continueDelayOnInactiveTab: false,
                position: 'top right',
                icon: 'bx bx-error',
                msg: message
            });
        }
        function success_noti(message) 
        {
            Lobibox.notify('success', {
                pauseDelayOnHover: true,
                continueDelayOnInactiveTab: false,
                position: 'top right',
                icon: 'bx bx-check-circle',
                msg: message
            });
        }

        $(document).find("title").text("Search Member");
    }); 
</script>