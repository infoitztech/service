<!--start page wrapper -->
<div class="page-wrapper">
    <div class="page-content">
        <h5 class="mb-0 text-uppercase">Student</h5>
        <hr/>
        <div class="card">
            <div class="card-body">
                <div class="d-lg-flex align-items-center mb-4 gap-3">
                    <div class="position-relative">
                        <h6>Students List</h6>
                    </div>
                </div>
                <div class="table-responsive">
                    <table id="studenttable" class="table mb-0">
                        <thead>
                            <tr class="bg-light">
                                <th>Sr.No</th>
                                <th>Student Name</th>
                                <th>Address</th>
                                <th>Date</th>
                                <?php if($retailer_data['print_status'] == "1") { ?>
                                <th>Action</th>
                                <?php } ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $count=1; foreach($studentdata_data as $data) {   ?>
                            <tr>
                                <td><?php echo $count++; ?></td>
                                <td><?php echo $data->name; ?></td>
                                <td><?php echo $data->address ?></td>
                                <td><?php echo $data->created_at; ?></td>
                                <?php if($retailer_data['print_status'] == "1") { ?>
                                <td>
                                    <div class="btn-group">
                                        <a href="<?php echo base_url('retailer/fingerprints') ?>?student=<?php echo $data->id; ?>" target="_blank" class="btn btn-light btn-sm " title="Student Finger Prints"><i class="bx bx-detail"></i></a>
                                    </div>
                                </td>
                                <?php } ?>
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<!--end page wrapper -->

<script>
    $(document).ready(function() {
        var table = $('#studenttable').DataTable( {
            buttons: [ 'excel']
        } );
        
        table.buttons().container()
            .appendTo( '#studenttable_wrapper .col-md-6:eq(0)' );

        $(document).find("title").text("Student Finger Prints");
    });
</script>