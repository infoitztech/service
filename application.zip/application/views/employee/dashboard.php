<!--start page wrapper -->
<div class="page-wrapper">
    <div class="page-content">
        <div class="row row-cols-1 row-cols-lg-2 row-cols-xl-3">
            <!-- <div class="col">
                <div class="card radius-10">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div>
                                <p class="mb-0">Total Administrators</p>
                                <h4 class="my-1">4</h4>
                            </div>
                            <div class="widgets-icons ms-auto"><i class='bx bx-user-circle'></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card radius-10">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div>
                                <p class="mb-0">Total Retailer</p>
                                <h4 class="my-1">52</h4>
                            </div>
                            <div class="widgets-icons ms-auto"><i class='bx bx-users'></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="card radius-10">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div>
                                <p class="mb-0">Total Photo</p>
                                <h4 class="my-1">450</h4>
                            </div>
                            <div class="widgets-icons ms-auto"><i class='bx bx-images'></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div> -->
        </div>
    </div>
</div>
<!--end page wrapper -->
<script>
    $(document).ready(function () {

        $(document).find("title").text("Employee Dashboard");
    }); 
</script>