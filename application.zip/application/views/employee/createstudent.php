<!--start page wrapper -->
<div class="page-wrapper">
    <div class="page-content">
        <h5 class="mb-0 text-uppercase">Create New Student</h5>
        <hr/>
        <div class="container">
            <div class="main-body">
                <div class="row">
                    <div class="col">
						<div class="card">
							<div class="card-body">
                                <form id="regform" method="POST" enctype="multipart/form-data">
                                    <ul class="nav nav-tabs" role="tablist">
                                        <li class="nav-item" role="presentation">
                                            <a class="nav-link active" data-bs-toggle="tab" href="#primaryhome" role="tab" aria-selected="true">
                                                <div class="d-flex align-items-center">
                                                    <div class="tab-icon"><i class="bx bx-detail font-18 me-1"></i>
                                                    </div>
                                                    <div class="tab-title">Student Detailes</div>
                                                </div>
                                            </a>
                                        </li>
                                        <li class="nav-item" role="presentation">
                                            <a class="nav-link" data-bs-toggle="tab" href="#primaryprofile" role="tab" aria-selected="false">
                                                <div class="d-flex align-items-center">
                                                    <div class="tab-icon"><i class="bx bx-scan font-18 me-1"></i>
                                                    </div>
                                                    <div class="tab-title">Finger Prints</div>
                                                </div>
                                            </a>
                                        </li>
                                    </ul>
                                    <div class="tab-content py-3">
                                        <div class="tab-pane fade show active" id="primaryhome" role="tabpanel">
                                            <div class="col-8">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="payout" class="form-label">VLE ID *</label>
                                                            <input type="text" class="form-control" id="vle_id" name="vle_id" value="<?php echo rand(100000,999999) ?>">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="payout" class="form-label">Student Name *</label>
                                                            <input type="text" class="form-control" id="name" name="name">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="payout" class="form-label">Contact *</label>
                                                            <input type="text" class="form-control" id="contact" name="contact">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="payout" class="form-label">DOB *</label>
                                                            <input type="text" class="form-control" id="dob" name="dob">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="payout" class="form-label">Purpose *</label>
                                                            <input type="text" class="form-control" id="purpose" name="purpose">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="payout" class="form-label">Adhaar No *</label>
                                                            <input type="text" class="form-control" id="adhaar_no" name="adhaar_no">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="payout" class="form-label">Type *</label>
                                                            <select name="type" id="type" class="form-control">
                                                                <option value="Adhaar">Adhaar</option>
                                                                <option value="Bank">Bank</option>
                                                            <select>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="payout" class="form-label">Remarks *</label>
                                                            <input type="text" class="form-control" id="remark1" name="remark1">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="tab-pane fade" id="primaryprofile" role="tabpanel">
                                        <div class="row mx-5">
                                                <div class="col-8">
                                                <div class="row">
                                                    <div class="col-3">
                                                        <div class="card">
                                                        <div class="card-body">
                                                            <p class="text-center text-white"><strong>Finger-1</strong></p>
                                                            <img src="https://vasoft.co.in/assets/images/sd.jpg" id="im1" class="img-fluid rounded-end border p-1">
                                                            <button type="button" class="btn btn-light px-4 mx-3 mt-1 capture" data-id="1"><i class="bx bx-scan"></i></button>
                                                            <input class="form-control" type="hidden" id="pic1" name="photo1">
                                                            <div style="width:100px; height : auto" class="text-center mt-2">
                                                            <img src="https://vasoft.co.in/assets/images/check.png" style="display:none; width:105px;" id="cim1" alt="">
                                                            </div>
                                                            <h5 id="q1" class="text-white text-center mt-3"></h5>
                                                        </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-3">
                                                        <div class="card">
                                                        <div class="card-body">
                                                            <p class="text-center text-white"><strong>Finger-2</strong></p>
                                                            <img src="https://vasoft.co.in/assets/images/sd.jpg" id="im2" class="img-fluid rounded-end border p-1">
                                                            <button type="button" class="btn btn-light px-4 mx-3 mt-1 capture" data-id="2"><i class="bx bx-scan"></i></button>
                                                            <input class="form-control" type="hidden" id="pic2" name="photo2">
                                                            <div style="width:100px; height : auto" class="text-center mt-2">
                                                            <img src="https://vasoft.co.in/assets/images/check.png" style="display:none; width:105px;" id="cim2" alt="">
                                                            </div>
                                                            <h5 id="q2" class="text-white text-center mt-3"></h5>
                                                        </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-3">
                                                        <div class="card">
                                                        <div class="card-body">
                                                            <p class="text-center text-white"><strong>Finger-3</strong></p>
                                                            <img src="https://vasoft.co.in/assets/images/sd.jpg" id="im3" class="img-fluid rounded-end border p-1">
                                                            <button type="button" class="btn btn-light px-4 mx-3 mt-1 capture" data-id="3"><i class="bx bx-scan"></i></button>
                                                            <input class="form-control" type="hidden" id="pic3" name="photo3">
                                                            <div style="width:100px; height : auto" class="text-center mt-2">
                                                            <img src="https://vasoft.co.in/assets/images/check.png" style="display:none; width:105px;" id="cim3" alt="">
                                                            </div>
                                                            <h5 id="q3" class="text-white text-center mt-3"></h5>
                                                        </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-3">
                                                        <div class="card">
                                                        <div class="card-body">
                                                            <p class="text-center text-white"><strong>Finger-4</strong></p>
                                                            <img src="https://vasoft.co.in/assets/images/sd.jpg" id="im4" class="img-fluid rounded-end border p-1">
                                                            <button type="button" class="btn btn-light px-4 mx-3 mt-1 capture" data-id="4"><i class="bx bx-scan"></i></button>
                                                            <input class="form-control" type="hidden" id="pic4" name="photo4">
                                                            <div style="width:100px; height : auto" class="text-center mt-2">
                                                            <img src="https://vasoft.co.in/assets/images/check.png" style="display:none; width:105px;" id="cim4" alt="">
                                                            </div>
                                                            <h5 id="q4" class="text-white text-center mt-3"></h5>
                                                        </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-4 mx-auto">
                                                    <button type="submit" class="btn btn-light">Add Student</button>
                                                </div>
                                                </div>
                                                <div class="col-2">
                                                <div class="row">
                                                    <div class="col-12">
                                                    <div class="card">
                                                        <div class="card-body">
                                                            <p class="text-center text-white"><strong>Finger-5</strong></p>
                                                            <img src="https://vasoft.co.in/assets/images/sd.jpg" id="im5" class="img-fluid rounded-end border p-1">
                                                            <button type="button" class="btn btn-light px-4 mx-3 mt-1 capture" data-id="5"><i class="bx bx-scan"></i></button>
                                                            <input class="form-control" type="hidden" id="pic5" name="photo5">
                                                            <div style="width:100px; height : auto" class="text-center mt-2">
                                                            <img src="https://vasoft.co.in/assets/images/check.png" style="display:none; width:105px" id="cim5" alt="">
                                                            </div>
                                                            <h5 id="q5" class="text-white text-center mt-3"></h5>
                                                        </div>
                                                    </div>
                                                    </div>
                                                </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
						</div>
					</div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--end page wrapper -->
<script>
    $(document).ready(function () {
        $('#regform').on('submit', function(event){
            event.preventDefault();
            var name = $(document).find("#name").val();
            if(name=="")
            {
                warning_noti("Student Name is required!");
            }
            else
            {

                var formData = new FormData(this);
                $.ajax({
                    url: '<?php echo base_url('Retailer/createstudentath') ?>',
                    method:"POST",
                    data: formData,
                    contentType:false,
                    cache:false,
                    processData:false,
                    success:function(response)
                    {
                        var res = JSON.parse(response);
                        if(res['statusCode'] == 1)
                        {
                            success_noti("Student Details Added Successfully");
                            $('#regform').trigger("reset");
                        }
                        else if(res['statusCode'] == 3)
                        {
                            warning_noti("Student Record already exists!");
                        }
                        else if(res['statusCode'] == 2)
                        {
                            warning_noti("Unable to create student record! Try again later");
                        }
                        else if(res['statusCode'] == 0)
                        {
                            error_noti("Something is wrong! Try again later");
                        }
                    }
                });
            }
        });
        function error_noti(message) 
        {
            Lobibox.notify('error', {
                pauseDelayOnHover: true,
                continueDelayOnInactiveTab: false,
                position: 'top right',
                icon: 'bx bx-x-circle',
                msg: message
            });
        }
        function warning_noti(message) 
        {
            Lobibox.notify('warning', {
                pauseDelayOnHover: true,
                continueDelayOnInactiveTab: false,
                position: 'top right',
                icon: 'bx bx-error',
                msg: message
            });
        }
        function success_noti(message) 
        {
            Lobibox.notify('success', {
                pauseDelayOnHover: true,
                continueDelayOnInactiveTab: false,
                position: 'top right',
                icon: 'bx bx-check-circle',
                msg: message
            });
        }

        $(document).find("title").text("Create Student");
    }); 
</script>