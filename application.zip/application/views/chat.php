<!--start page wrapper -->
<div class="page-wrapper">
    <div class="page-content">
        <div class="chat-wrapper">
            <div class="chat-sidebar">
                <div class="chat-sidebar-content">
                    <div class="tab-content" id="pills-tabContent">
                        <div class="tab-pane fade show active" id="pills-Chats">
                            <div class="chat-list mt-2">
                                <div class="list-group list-group-flush">
                                    <?php foreach($chat_data as $data){ ?>
                                    <a href="javascript:;" class="list-group-item switch-profile" data-id="<?php echo $data['user_id']; ?>">
                                        <div class="d-flex">
                                            <div class="chat-user-online">
                                                <img src="<?php echo base_url('upload/user/profilephoto'); ?>/<?php echo $data['profile']; ?>" width="42" height="42" class="rounded-circle" alt="" />
                                            </div>
                                            <div class="flex-grow-1 ms-2">
                                                <h6 class="mb-0 chat-title"><?php echo $data['name']; ?></h6>
                                                <p class="mb-0 chat-msg"><?php echo $data['message']; ?></p>
                                            </div>
                                            <div class="chat-time"><?php echo date_format(date_create($data['message_date']), "M"); ?> <?php echo date_format(date_create($data['message_date']), "h:i a"); ?></div>
                                        </div>
                                    </a>
                                    <?php } ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="chat-header d-flex align-items-center">
                <div class="chat-toggle-btn"><i class='bx bx-menu-alt-left'></i>
                </div>
                <div>
                    <h4 class="mb-1 font-weight-bold person-name"><?php echo $chat_data['0']['name'] ?></h4>
                </div>
            </div>
            <div class="chat-content ps ps--active-y">
                <?php foreach($chat_conent as $data) { 
                    if($data['send_id'] != "admin") { ?>
                <div class="chat-content-leftside">
                    <div class="d-flex">
                        <img src="<?php echo base_url('upload/user/profilephoto'); ?>/<?php echo $chat_data['0']['profile']; ?>" width="48" height="48" class="rounded-circle" alt="" />
                        <div class="flex-grow-1 ms-2">
                            <p class="mb-0 chat-time"><?php echo $chat_data['0']['name'] ?>, <?php echo date_format(date_create($data['created_date']), "M"); ?>, <?php echo date_format(date_create($data['created_date']), "h:i a"); ?></p>
                            <p class="chat-left-msg"><?php echo $data['chat_content']; ?></p>
                        </div>
                    </div>
                </div>
                <?php } 
                else { ?>
                <div class="chat-content-rightside">
                    <div class="d-flex ms-auto">
                        <div class="flex-grow-1 me-2">
                            <p class="mb-0 chat-time text-end">You, <?php echo date_format(date_create($data['created_date']), "M"); ?>, <?php echo date_format(date_create($data['created_date']), "h:i a"); ?></p>
                            <p class="chat-right-msg"><?php echo $data['chat_content']; ?></p>
                        </div>
                    </div>
                </div>
                <?php } }?>
            </div>
            <input type="hidden" class="useruser_id" value="<?php echo $chat_data['0']['user_id'] ?>">
            <div class="chat-footer d-flex align-items-center">
                <div class="flex-grow-1 pe-2">
                    <div class="input-group">	<span class="input-group-text"></span>
                        <input type="text" class="form-control text-message" placeholder="Type a message">
                    </div>
                </div>
                <div class="chat-footer-menu">
                    <a href="javascript:;" class="send-message"><i class='bx bx-send'></i></a>
                </div>
            </div>
            <div class="overlay chat-toggle-btn-mobile"></div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function () {
        $(document).find(".ps").css('overflow', 'auto');
        $('.switch-profile').on('click', function(event){
            event.preventDefault();
            var user_id = $(this).attr("data-id");
            getchathistory(user_id);
        });
        
        $('.send-message').on('click', function(event){
            event.preventDefault();
            var text_message = $(document).find(".text-message").val();
            var user_id = $(document).find(".useruser_id").val();
            if(text_message == "")
            {
                alert("Message is required!");
            }
            else if(user_id == "")
            {
                 alert("Something is wrong! Try again later");
            }
            else
            {
                $.ajax({
                    url: '<?php echo base_url('administrator/sendmessage') ?>',
                    method: 'POST',
                    data: {
                        user_id: user_id,
                        text_message : text_message
                    },
                    success: function (response) 
                    {
                        if(response ==1)
                        {
                            getchathistory(user_id);
                            $(".text-message").val("");
                        }
                        else
                        {
                            alert("Failed");
                        }
                    }
                });
            }
        });
    });

    function getchathistory(user_id)
    {
        if(user_id)
        {
            $.ajax({
                url: '<?php echo base_url('administrator/getchathistory') ?>',
                method: 'POST',
                data: {
                    user_id: user_id
                },
                success: function (response) 
                {
                    var res = JSON.parse(response);
                    var chatdata = "";
                    $(document).find(".person-name").text(res['1']['name']);
                    if(res['1']['profile'] =="")
                    {
                        res['1']['profile'] = "profile.png"
                    }
                    $(".useruser_id").val(res['1']['user_id']);
                    for(var i=0; i<res['0'].length; i++)
                    {
                        if(res['0'][i]['send_id'] != "admin")
                        {
                            chatdata+='<div class="chat-content-leftside"><div class="d-flex"><img src="http://laxmansriramkrishnashivavenkatarajasekara.tech/1/upload/user/profilephoto/'+res["1"]["profile"]+'" width="48" height="48" class="rounded-circle" alt=""/><div class="flex-grow-1 ms-2"><p class="mb-0 chat-time">'+res["0"][i]["created_date"]+'</p><p class="chat-left-msg">'+res["0"][i]["chat_content"]+'</p></div></div></div>';
                        }
                        else
                        {
                            chatdata+='<div class="chat-content-rightside"><div class="d-flex ms-auto"><div class="flex-grow-1 me-2"><p class="mb-0 chat-time text-end">You, '+res["0"][i]["created_date"]+'</p><p class="chat-right-msg">'+res["0"][i]["chat_content"]+'</p></div></div></div>';
                        }
                    }
                    $(document).find(".ps--active-y").html(chatdata);
                }
            })
        }
    }
</script>
<script>
    // new PerfectScrollbar('.chat-list');
    // new PerfectScrollbar('.chat-content');
</script>