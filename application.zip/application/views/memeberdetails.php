<!--start page wrapper -->
<div class="page-wrapper">
    <div class="page-content">
        <div class="row">
            <div class="col-xl-8 mx-auto">
                <div class="card border-top border-0 border-4 border-white">
                    <div class="card-body p-5">
                        <div class="card-title d-flex align-items-center">
                            <h6 class="mb-0 text-white">Member Details</h6>
                        </div>
                        <hr>
                        <div class="row mt-3" id="details-container" style="width: 350px" >   
                            <table>
                                <tr style="width : 20%">
                                    <th><p class="text-white">Ref. ID :</p></th>
                                    <td><p class="text-white"><?php echo $member_data['vle_id']; ?></p></td>
                                </tr>
                                <tr>
                                    <th><p class="text-white">Name :</p></th>
                                    <td><p class="text-white"><?php echo $member_data['name']; ?></p></td>
                                </tr>
                                <tr>
                                    <th><p class="text-white">Contact :</p></th>
                                    <td><p class="text-white"><?php echo $member_data['contact']; ?></p></td>
                                </tr>
                                <tr>
                                    <th><p class="text-white">DOB :</p></th>
                                    <td><p class="text-white"><?php echo $member_data['dob']; ?></p></td>
                                </tr>
                                <tr>
                                    <th><p class="text-white">Purpose :</p></th>
                                    <td><p class="text-white"><?php echo $member_data['purpose']; ?></p></td>
                                </tr>
                                <tr>
                                    <th><p class="text-white">Adhaar No :</p></th>
                                    <td><p class="text-white"><?php echo $member_data['adhaar_no']; ?></p></td>
                                </tr>
                                <tr>
                                    <th><p class="text-white">Type :</p></th>
                                    <td><p class="text-white"><?php echo $member_data['type']; ?></p></td>
                                </tr>
                                <tr>
                                    <th><p class="text-white">Retailer :</p></th>
                                    <td><p class="text-white"><?php echo $retailer['username']; ?></p></td>
                                </tr>
                                <tr>
                                    <th><p class="text-white">Retailer Remark:</p></th>
                                    <td><textarea class="form-control" rows="3" id="remark1"><?php echo $member_data['remark1']; ?></textarea></td>
                                </tr>
                                <tr>
                                    <th><p class="text-white">Retailer Visible Access:</p></th>
                                    <td>
                                        <select class="form-select"  id="retailer_visible_access">
                                            <option value="1" <?php echo ($member_data['visible_to_retailer'] == "1") ? "selected": "" ; ?>>Visible</option>
                                            <option value="2" <?php echo ($member_data['visible_to_retailer'] == "2") ? "selected": "" ; ?>>Removed</option>
                                        </select>  
                                    </td>
                                </tr>
                                <tr>
                                    <th><p class="text-white">Employee :</p></th>
                                    <td><?php echo $member_data['employee_name']; ?></td>
                                </tr>
                                <tr>
                                    <th><p class="text-white">Employee Remark :</p></th>
                                    <td><textarea class="form-control" rows="3" id="remark2"><?php echo $member_data['remark2']; ?></textarea></td>
                                </tr>
                                <tr>
                                    <th><p class="text-white">Employee Visible Access:</p></th>
                                    <td>
                                        <select class="form-select"  id="employee_visible_access">
                                            <option value="1" <?php echo ($member_data['visible_to_employee'] == "1") ? "selected": "" ; ?>>Visible</option>
                                            <option value="2" <?php echo ($member_data['visible_to_employee'] == "2") ? "selected": "" ; ?>>Removed</option>
                                        </select>  
                                    </td>
                                </tr>
                                <tr>
                                    <th><p class="text-white">Admin Remark :</p></th>
                                    <td><textarea class="form-control" rows="3" id="remark3"><?php echo $member_data['remark3']; ?></textarea></td>
                                </tr>
                                <tr>
                                    <th colspan="2" style="text-align:center"><input type="checkbox" value="cancelled" id="status" class="form-check-input mt-2" <?php if($member_data['status'] == "Cancelled") { echo "checked"; }  ?>><span class="mt-3 text-white"> : Mark as Cancelled</span></th>
                                </tr>
                                <tr>
                                    <th colspan="2" style="text-align:center"><a href="<?php echo base_url('administrator/fingerprints') ?>?member=<?php echo $member_data['id']; ?>" id="finger-print-url" class="btn btn-light btn-sm mt-2" target="_blank">View Finger Prints</a></td>
                                </tr>
                                <tr>
                                    <td colspan="2" style="text-align:center"><button id="save-remark" class="btn btn-light mt-4">Save Remarks</button></td>
                                </tr>
                                <input type="hidden" id="member_id" value="<?php echo $member_data['id']; ?>">
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--end page wrapper -->

<script>
    $(document).ready(function () {
        $('#save-remark').on('click', function(event){
            event.preventDefault();
            var member_id = $(document).find("#member_id").val();
            var remark1 = $(document).find("#remark1").val();
            var remark2 = $(document).find("#remark2").val();
            var remark3 = $(document).find("#remark3").val();
            var status = $(document).find("#status :checked").val();
            var retailer_visible_access = $(document).find("#retailer_visible_access :checked").val();
            var employee_visible_access = $(document).find("#employee_visible_access :checked").val();
            var new_status = "";
            if(status == "cancelled")
            {
                new_status = "Cancelled";
            }
            else
            {
                new_status = "Success";
            }
            if(member_id=="")
            {
                warning_noti("Something is wrong! Try again later");
            }
            else
            {
                $.ajax({
                    url: '<?php echo base_url('administrator/updateremark') ?>',
                    method: 'POST',
                    data: {
                        member_id: member_id,
                        remark1: remark1,
                        remark2: remark2,
                        remark3: remark3,
                        status : new_status,
                        retailer_visible_access : retailer_visible_access,
                        employee_visible_access : employee_visible_access
                        },
                    success: function (response) 
                    {
                        if(response == "1")
                        {
                            alert("Member details updated!");
                        }
                        else
                        {
                            alert("Unable to update details!");
                        }
                    }
                })

            }
        });
      
        function error_noti(message) 
        {
            Lobibox.notify('error', {
                pauseDelayOnHover: true,
                continueDelayOnInactiveTab: false,
                position: 'top right',
                icon: 'bx bx-x-circle',
                msg: message
            });
        }
        function warning_noti(message) 
        {
            Lobibox.notify('warning', {
                pauseDelayOnHover: true,
                continueDelayOnInactiveTab: false,
                position: 'top right',
                icon: 'bx bx-error',
                msg: message
            });
        }
        function success_noti(message) 
        {
            Lobibox.notify('success', {
                pauseDelayOnHover: true,
                continueDelayOnInactiveTab: false,
                position: 'top right',
                icon: 'bx bx-check-circle',
                msg: message
            });
        }

        $(document).find("title").text("Member Details");
    }); 
</script>