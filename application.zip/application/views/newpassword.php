<!doctype html>
<html lang="en">
<head>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!--favicon-->
	<link rel="icon" href="<?php echo base_url('assets/images/favicon-32x32.png'); ?>" type="image/png" />
	<!--plugins-->
	<link rel="stylesheet" href="<?php echo base_url('assets/plugins/notifications/css/lobibox.min.css'); ?>" />
	<link href="<?php echo base_url('assets/plugins/simplebar/css/simplebar.css'); ?>" rel="stylesheet" />
	<link href="<?php echo base_url('assets/plugins/perfect-scrollbar/css/perfect-scrollbar.css'); ?>" rel="stylesheet" />
	<link href="<?php echo base_url('assets/plugins/metismenu/css/metisMenu.min.css'); ?>" rel="stylesheet" />
	<!-- loader-->
	<link href="<?php echo base_url('assets/css/pace.min.css'); ?>" rel="stylesheet" />
	<script src="<?php echo base_url('assets/js/pace.min.js'); ?>"></script>
	<!-- Bootstrap CSS -->
	<link href="<?php echo base_url('assets/css/bootstrap.min.css'); ?>" rel="stylesheet">
	<link href="<?php echo base_url('assets/css/app.css'); ?>" rel="stylesheet">
	<link href="<?php echo base_url('assets/css/icons.css'); ?>" rel="stylesheet">
	<title>VLE Adda-Retailer Login</title>
</head>

<body class="bg-theme bg-theme12">
	<!--wrapper-->
	<div class="wrapper">
		<div class="section-authentication-signin d-flex align-items-center justify-content-center my-5 my-lg-0">
			<div class="container-fluid">
				<div class="row row-cols-1 row-cols-lg-2 row-cols-xl-3">
					<div class="col mx-auto">
						<div class="card">
							<div class="card-body">
								<div class="border p-4 rounded">
									<div class="row">
										<div class="col-12">
											<div class="d-flex flex-column align-items-center text-center">
												<img src="<?php echo base_url('assets/images/superadmin.png') ?>" class="rounded-circle p- bg-light mb-3" width="110">
											</div>
										</div>
										<div class="col-12">
											<div class="d-flex flex-column align-items-center text-center">
												<h4 class="text-white text-center">VLE Adda</h4>
											</div>
										</div>
										<div class="col-12">
											<div class="d-flex flex-column align-items-center text-center">
												<h5 class="text-white text-center">Set New Password</h5>
											</div>
										</div>
									</div>
									<div class="form-body">
										<form class="row g-3">
											<div class="col-12">
												<label for="password" class="form-label">Password</label>
												<input type="text" name="password" class="form-control" id="password" placeholder="Enter Password....">
											</div>
											<div class="col-12">
												<label for="cpassword" class="form-label">Confirm Password</label>
												<input type="text" name="cpassword" class="form-control" id="cpassword" placeholder="Enter Confirm Password....">
											</div>
											<div class="col-12">
												<div class="d-grid mt-4">
													<button class="btn btn-light" id="new-btn"><i class="bx bxs-lock-open"></i>Reset Now</button>
												</div>
											</div>
										</form>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!--end row-->
			</div>
		</div>
	</div>
	<!--end wrapper-->


	<!-- Bootstrap JS -->
<script src="<?php echo base_url('assets/js/bootstrap.bundle.min.js'); ?>"></script>
<!--plugins-->
<script src="<?php echo base_url('assets/js/jquery.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/plugins/simplebar/js/simplebar.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/plugins/metismenu/js/metisMenu.min.js'); ?>"></script>
<!--Password show & hide js -->
<!--notification js -->
<script src="<?php echo base_url('assets/plugins/notifications/js/lobibox.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/plugins/notifications/js/notifications.min.js'); ?>"></script>

<script type="text/javascript">
$(document).ready(function (){
    $(document).on('click','#new-btn',function(e){
        e.preventDefault();
        var password = $(document).find("#password").val();
        var cpassword = $(document).find("#cpassword").val();
        if(password== "")
        {
            warning_noti("New Password is required!");
        }
        else if(cpassword== "")
        {
            warning_noti("Confirm Password is required!");
        }
        else if(cpassword != password)
        {
            warning_noti("New Password And Confirm Password is required!");
        }
        else
        {
            $.ajax({
			url: '<?php echo base_url('administrator/newpasswordath') ?>',
			type:"post",
			data: {
				password: password,
				},                
			cache:false,
			success: function(response)
			{
				var res = JSON.parse(response);
				if(res['statusCode'] == "2")
				{
					error_noti(res['Message']);
				}
				else if(res['statusCode'] == "1")
				{
					success_noti(res['Message']);
					window.location.href= "<?php echo base_url('/administrator') ?>";
				}
				else if(res['statusCode'] == "3")
				{
					error_noti(res['Message']);
				}
				else
				{
					error_noti("Something is wrong!, Try again later");
				}
			}
			});
        }
    });
    $(document).find("title").text("Set New Password")
	});
	function error_noti(message) 
		{
			Lobibox.notify('error', {
				pauseDelayOnHover: true,
				continueDelayOnInactiveTab: false,
				position: 'top right',
				icon: 'bx bx-x-circle',
				msg: message
			});
		}
		function warning_noti(message) 
		{
			Lobibox.notify('warning', {
				pauseDelayOnHover: true,
				continueDelayOnInactiveTab: false,
				position: 'top right',
				icon: 'bx bx-error',
				msg: message
			});
		}
		function success_noti(message) 
		{
			Lobibox.notify('success', {
				pauseDelayOnHover: true,
				continueDelayOnInactiveTab: false,
				position: 'top right',
				icon: 'bx bx-check-circle',
				msg: message
			});
		}
</script>
</body></html>
