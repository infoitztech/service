<!--start page wrapper -->
<div class="page-wrapper">
    <div class="page-content">
        <div class="row">
            <div class="col-xl-6 mx-auto">
                <h5 class="mb-0 text-uppercase">Password</h5>
                <hr/>
                <div class="card border-top border-0 border-4 border-white">
                    <div class="card-body p-5">
                        <div class="card-title d-flex align-items-center">
                            <h6 class="mb-0 text-white">Change Password</h6>
                        </div>
                        <hr>
                        <form class="row g-3 password-form">
                            <div class="col-md-12">
                                <label for="oldpassword" class="form-label">Old Password </label>
                                <input type="text" class="form-control" id="old-password">
                            </div>
                            <div class="col-md-12">
                                <label for="newpassword" class="form-label">New Password </label>
                                <input type="text" class="form-control" id="new-password">
                            </div>
                            <div class="col-md-12">
                                <label for="confirmpassword" class="form-label">Confirm Password </label>
                                <input type="text" class="form-control" id="confirm-password">
                            </div>
                            <div class="col-12">
                                <button type="submit" class="btn btn-light px-5" id="save-changes">Save Changes</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--end page wrapper -->

<script>
    $(document).ready(function () {
        $('#save-changes').on('click', function(event){
            event.preventDefault();
            var old_password = $(document).find("#old-password").val();
            var new_password = $(document).find("#new-password").val();
            var confirm_password = $(document).find("#confirm-password").val();
            if(old_password=="")
            {
                warning_noti("Old Password is required!");
            }
            else if(new_password == "")
            {
                warning_noti("New Password is required!");
            }
            else if(confirm_password == "")
            {
                warning_noti("Confirm Password is required!");
            }
            else if(confirm_password != new_password)
            {
                warning_noti("Confirm Password and new Password must be same!");
            }
            else
            {

                $.ajax({
                    url: '<?php echo base_url('admin/changepasswordAth') ?>',
                    method: 'POST',
                    data: {
                        old_password: old_password,
                        new_password: new_password
                        },
                    success: function (response) 
                    {
                        var res = JSON.parse(response);
                        if(res['statusCode'] == 3)
                        {
                            success_noti(res['Message']);
                            $('.password-form').trigger("reset");
                        }
                        else if(res['statusCode'] == 2)
                        {
                            warning_noti(res['Message']);
                        }
                        else if(res['statusCode'] == 1)
                        {
                            warning_noti(res['Message']);
                        }
                        else if(res['statusCode'] == 0)
                        {
                            error_noti(res['Message']);
                        }
                    }
                })
            }
        });
        function error_noti(message) 
        {
            Lobibox.notify('error', {
                pauseDelayOnHover: true,
                continueDelayOnInactiveTab: false,
                position: 'top right',
                icon: 'bx bx-x-circle',
                msg: message
            });
        }
        function warning_noti(message) 
        {
            Lobibox.notify('warning', {
                pauseDelayOnHover: true,
                continueDelayOnInactiveTab: false,
                position: 'top right',
                icon: 'bx bx-error',
                msg: message
            });
        }
        function success_noti(message) 
        {
            Lobibox.notify('success', {
                pauseDelayOnHover: true,
                continueDelayOnInactiveTab: false,
                position: 'top right',
                icon: 'bx bx-check-circle',
                msg: message
            });
        }

        $(document).find("title").text("Change Password");
    }); 
</script>