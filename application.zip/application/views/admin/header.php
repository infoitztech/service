<!doctype html>
<html lang="en">
<head>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!--favicon-->
	<link rel="icon" href="<?php echo base_url('assets/images/favicon-32x32.png'); ?>" type="image/png" />

	<!-- loader-->
	<link href="<?php echo base_url('assets/css/pace.min.css'); ?>" rel="stylesheet" />
	<script src="<?php echo base_url('assets/js/pace.min.js'); ?>"></script>
	<link rel="stylesheet" href="<?php echo base_url('assets/plugins/notifications/css/lobibox.min.css'); ?>" />
    <link href="<?php echo base_url('assets/plugins/simplebar/css/simplebar.css'); ?>" rel="stylesheet" />
	<link href="<?php echo base_url('assets/plugins/perfect-scrollbar/css/perfect-scrollbar.css'); ?>" rel="stylesheet" />
	<link href="<?php echo base_url('assets/plugins/metismenu/css/metisMenu.min.css'); ?>" rel="stylesheet" />

	<!-- Bootstrap CSS -->
	<link href="<?php echo base_url('assets/css/bootstrap.min.css'); ?>" rel="stylesheet">
	<link href="<?php echo base_url('assets/css/app.css'); ?>" rel="stylesheet">
	<link href="<?php echo base_url('assets/css/icons.css'); ?>" rel="stylesheet">
	<link href="<?php echo base_url('assets/plugins/datatable/css/dataTables.bootstrap5.min.css'); ?>" rel="stylesheet" />
	<script src="<?php echo base_url('assets/js/jquery.min.js'); ?>"></script>
	<title>Admin Dashboard</title>
</head>

<body class="bg-theme bg-theme12">
	<!--wrapper-->
	<div class="wrapper">
		<!--sidebar wrapper -->
		<div class="sidebar-wrapper" data-simplebar="true">
			<div class="sidebar-header">
				<div>
					<h4 class="logo-text">Service Plus</h4>
				</div>
				<div class="toggle-icon ms-auto"><i class='bx bx-arrow-to-left'></i>
				</div>
			</div>
			<!--navigation-->
			<ul class="metismenu" id="menu">
				<li>
					<a href="<?php echo base_url('admin/dashboard') ?>">
						<div class="parent-icon"><i class='bx bx-home-circle'></i>
						</div>
						<div class="menu-title">Dashboard</div>
					</a>
				</li>
				<li>
					<a href="<?php echo base_url('admin/createuser') ?>">
						<div class="parent-icon"><i class='bx bx-plus-circle'></i>
						</div>
						<div class="menu-title">Create Retailer</div>
					</a>
				</li>
				<li>
					<a href="<?php echo base_url('admin/users') ?>">
						<div class="parent-icon"><i class='bx bx-list-ul'></i>
						</div>
						<div class="menu-title">Retailer List</div>
					</a>
				</li>
				<!--<li>-->
				<!--	<a href="<?php echo base_url('admin/createemployee') ?>">-->
				<!--		<div class="parent-icon"><i class='bx bx-plus-circle'></i>-->
				<!--		</div>-->
				<!--		<div class="menu-title">Create Employee</div>-->
				<!--	</a>-->
				<!--</li>-->
				<!--<li>-->
				<!--	<a href="<?php echo base_url('admin/employees') ?>">-->
				<!--		<div class="parent-icon"><i class='bx bx-list-ul'></i>-->
				<!--		</div>-->
				<!--		<div class="menu-title">Employees List</div>-->
				<!--	</a>-->
				<!--</li>-->
				<li>
					<a href="<?php echo base_url('admin/changepassword') ?>">
						<div class="parent-icon"><i class='bx bx-lock'></i>
						</div>
						<div class="menu-title">Change Password</div>
					</a>
				</li>
				<li>
					<a href="<?php echo base_url('admin/profile') ?>">
						<div class="parent-icon"><i class='bx bx-user-circle'></i>
						</div>
						<div class="menu-title">Profile</div>
					</a>
				</li>
			</ul>
			<!--end navigation-->
		</div>
		<!--end sidebar wrapper -->
		<!--start header -->
		<header>
			<div class="topbar d-flex align-items-center">
				<nav class="navbar navbar-expand">
					<div class="mobile-toggle-menu"><i class='bx bx-menu'></i>
					</div>
					<div class="search-bar flex-grow-1">
                        <div class="btn-group" role="group" aria-label="Basic example">
                            <h5>Admin Dashboard</h5>
					    </div>
                    </div>
					<div class="top-menu ms-auto">
						<ul class="navbar-nav align-items-center">
                            <li class="nav-item mobile-search-icon">
                                <h6 class="mt-2">Dashboard</h6>
							</li>
							<li class="nav-item dropdown dropdown-large">
								<a class="nav-link dropdown-toggle dropdown-toggle-nocaret position-relative" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
									
								</a>
								<div class="dropdown-menu dropdown-menu-end">
									<a href="javascript:;">
										<div class="msg-header">
											<p class="msg-header-title">Messages</p>
											<p class="msg-header-clear ms-auto">Marks all as read</p>
										</div>
									</a>
									<div class="header-message-list">										
									</div>
									<a href="javascript:;">
										<div class="text-center msg-footer">View All Messages</div>
									</a>
								</div>
							</li>
							<li class="nav-item dropdown dropdown-large">
								<a class="nav-link dropdown-toggle dropdown-toggle-nocaret position-relative" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"> 
									<!-- <span class="alert-count">7</span>
									<i class='bx bx-bell'></i> -->
								</a>
								<div class="dropdown-menu dropdown-menu-end">
									<a href="javascript:;">
										<div class="msg-header">
											<p class="msg-header-title">Notifications</p>
											<p class="msg-header-clear ms-auto">Marks all as read</p>
										</div>
									</a>
									<div class="header-notifications-list">
										<a class="dropdown-item" href="javascript:;">
											<div class="d-flex align-items-center">
												<div class="notify"><i class="bx bx-group"></i>
												</div>
												<div class="flex-grow-1">
													<h6 class="msg-name">New Customers<span class="msg-time float-end">14 Sec
												ago</span></h6>
													<p class="msg-info">5 new user registered</p>
												</div>
											</div>
										</a>
										<a class="dropdown-item" href="javascript:;">
											<div class="d-flex align-items-center">
												<div class="notify"><i class="bx bx-cart-alt"></i>
												</div>
												<div class="flex-grow-1">
													<h6 class="msg-name">New Orders <span class="msg-time float-end">2 min
												ago</span></h6>
													<p class="msg-info">You have recived new orders</p>
												</div>
											</div>
										</a>
									</div>
									<a href="javascript:;">
										<div class="text-center msg-footer">View All Notifications</div>
									</a>
								</div>
							</li>
						</ul>
					</div>
					<div class="user-box dropdown">
						<a class="d-flex align-items-center nav-link dropdown-toggle dropdown-toggle-nocaret" href="" role="button" data-bs-toggle="dropdown" aria-expanded="false">
							<?php $profile = $admin_data['profile']; ?>
							<img src="<?php echo base_url('upload/admin/profilephoto'); ?>/<?php echo ($profile !="") ? $profile: "profile.png"; ?>" class="user-img" alt="Administrator">
							<div class="user-info ps-3">
								<p class="user-name mb-0"><?php echo $admin_data['name']; ?></p>
								<p class="designattion mb-0">Admin</p>
							</div>
						</a>
						<ul class="dropdown-menu dropdown-menu-end">
							<li><a class="dropdown-item" href="<?php echo base_url('admin/logout'); ?>"><i class='bx bx-log-out-circle'></i><span>Logout</span></a>
							</li>
						</ul>
					</div>
				</nav>
			</div>
		</header>
		<!--end header -->
		