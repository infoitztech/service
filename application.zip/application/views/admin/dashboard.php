<!--start page wrapper -->
<div class="page-wrapper">
    <div class="page-content">
        <div class="row row-cols-1 row-cols-lg-2 row-cols-xl-3">
            <div class="col">
                <div class="card radius-10">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div>
                                <p class="mb-0">Total Retailer</p>
                                <h4 class="my-1"><?php echo $total_users ?></h4>
                            </div>
                            <div class="widgets-icons ms-auto"><i class='lni lni-users'></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="card radius-10">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div>
                                <p class="mb-0">Total Members</p>
                                <h4 class="my-1"><?php echo $total_students ?></h4>
                            </div>
                            <div class="widgets-icons ms-auto"><i class='bx bx-images'></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="card radius-10">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div>
                                <p class="mb-0">Total Coins</p>
                                <h4 class="my-1"><?php echo $total_students ?></h4>
                            </div>
                            <div class="widgets-icons ms-auto"><i class='bx bx-images'></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <hr>
        <div class="container">
            <div class="row">
                <div class="col-lg-4">
                    <div class="form-group">
                        <input type="text" name="username" id="username" class="form-control" placeholder="Enter Username">
                    </div>    
                </div>
                <div class="col-lg-4">
                    <div class="form-group">
                        <input type="text" name="coins" id="coins" class="form-control" placeholder="Enter Coins">
                    </div>    
                </div>
                <div class="col-lg-4">
                    <div class="form-group text-center">
                        <button class="btn btn-light" type="button" id="add-coins">Add Coins</button>
                    </div>    
                </div>
            </div>
        </div>
    </div>
</div>
<!--end page wrapper -->
<script>
    $(document).ready(function () {

        $(document).find("title").text("Admin Dashboard");

        $(document).find("#add-coins").click(function(e){
            e.preventDefault();
            var retailer_username = $(document).find("#username").val();
            var coins = $(document).find("#coins").val();
            if(username=="")
            {
                alert("Username is required!");
            } 
            else if(coins == "")
            {
                warning_noti("Recharge Coin is required!");
            }
            else if(coins <= 5)
            {
                warning_noti("Coins must be greater than 5");
            }
            else
            {
                $.ajax({
                    url: '<?php echo base_url('admin/rechargecoinswithusername') ?>',
                    method: 'POST',
                    data: 
                    {
                        retailer_username: retailer_username,
                        coins: coins
                    },
                    success: function (response) 
                    {
                        var res = JSON.parse(response);
                        if(res['statusCode'] == 3)
                        {
                            success_noti(res['Message']);
                            window.location.reload();
                        }
                        else if(res['statusCode'] == 2)
                        {
                            warning_noti(res['Message']);
                        }
                        else if(res['statusCode'] == 0)
                        {
                            error_noti(res['Message']);
                        }
                    }
                })
            }
        });        
    });

    function error_noti(message) 
    {
        Lobibox.notify('error', {
            pauseDelayOnHover: true,
            continueDelayOnInactiveTab: false,
            position: 'top right',
            icon: 'bx bx-x-circle',
            msg: message
        });
    }
    function warning_noti(message) 
    {
        Lobibox.notify('warning', {
            pauseDelayOnHover: true,
            continueDelayOnInactiveTab: false,
            position: 'top right',
            icon: 'bx bx-error',
            msg: message
        });
    }
    function success_noti(message) 
    {
        Lobibox.notify('success', {
            pauseDelayOnHover: true,
            continueDelayOnInactiveTab: false,
            position: 'top right',
            icon: 'bx bx-check-circle',
            msg: message
        });
    } 
</script>