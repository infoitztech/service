<!--start page wrapper -->
<div class="page-wrapper">
    <div class="page-content">
        <h5 class="mb-0 text-uppercase">Retailer</h5>
        <hr/>
        <div class="card">
            <div class="card-body">
                <div class="d-lg-flex align-items-center mb-4 gap-3">
                    <div class="position-relative">
                        <h6>Retailers List</h6>
                    </div>
                    <div class="ms-auto"><a href="<?php echo base_url('admin/createuser') ?>" class="btn btn-light radius-30 mt-2 mt-lg-0"><i class="bx bxs-plus-square"></i>Create New Retailer</a></div>
                </div>
                <div class="table-responsive">
                    <table id="administrators" class="table mb-0">
                        <thead>
                            <tr class="bg-light">
                                <th>Sr.No</th>
                                <th>Profile</th>
                                <th>Name</th>
                                <th>Username</th>
                                <th>Coins</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $count=1; foreach($user_data as $data) {  $profile = $data['profile']; ?>
                            <tr>
                                <td><?php echo $count++; ?></td>
                                <td><img src="<?php echo base_url('upload/user/profilephoto'); ?>/<?php echo ($profile !="") ? $profile: "profile.png"; ?>" alt class="user-img"></td>
                                <td><?php echo $data['name'] ?></td>
                                <td><?php echo $data['username'] ?></td>
                                <td><?php echo $data['coins'] ?></td>
                                <td>
                                    <div class="btn-group">
                                        <button class="btn btn-light btn-sm recharge" title="Recharge" data-id="<?php echo $data['user_id']; ?>" data-bs-toggle="modal" data-bs-target="#rechargecoinConfirmation"><i class="bx bxs-coin"></i></button>
                                        <button class="btn btn-light btn-sm delete-user" title="Delete Retailer" data-id="<?php echo $data['user_id']; ?>" data-bs-toggle="modal" data-bs-target="#deleteUserConfirmation"><i class="bx bxs-trash"></i></button> 
                                    </div>
                                </td>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<!--end page wrapper -->
<div class="modal fade" id="deleteUserConfirmation" tabindex="-1" aria-labelledby="deleteUserConfirmationLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteUserConfirmationLabel">Confirmation</h5>
            </div>
            <div class="modal-body">
                Are you sure you want to Delete this Retailer ?
                <input type="hidden" id="delete-user-id">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" id="delete-user-btn" data-bs-dismiss="modal">Confirm</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Decline</button>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="viewaRetailerConfirmation" tabindex="-1" aria-labelledby="viewaRetailerConfirmationLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="viewaRetailerConfirmation">Retailer Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-lg-12 col-sm-12">
                        <div class="d-flex flex-column align-items-center text-center">
                            <img src="" class="rounded-circle p-1 bg-primary retailer-image" style="height: 110px">
                        </div>
                    </div>
                    <div class="col-lg-12 col-sm-12">
                        <div class="text-center">
                            <p class="mb-0 mt-4">Name : <span class="name"></span></p>
                        </div>
                    </div>
                    <div class="col-lg-12 col-sm-12">
                        <div class="text-center">
                            <p class="mb-0">Contact : <span class="contact"></span></p>
                        </div>
                    </div>
                    <div class="col-lg-12 col-sm-12">
                        <div class="text-center">
                            <p class="mb-0">Email : <span class="email"></span></p>
                        </div>
                    </div>
                    <div class="col-lg-12 col-sm-12">
                        <div class="text-center">
                            <p>Username : <span class="username"></span></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="viewStatusConfirmation" tabindex="-1" aria-labelledby="viewStatusConfirmationLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="viewStatusConfirmationLabel">Confirmation</h5>
            </div>
            <div class="modal-body">
                Are you sure you want to <span id="v-status"></span> this User ?
                <input type="hidden" id="v-user-id">
                <input type="hidden" id="v-status-id">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" id="change-v-status-btn" data-bs-dismiss="modal">Confirm</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Decline</button>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="rechargecoinConfirmation" tabindex="-1" aria-labelledby="rechargecoinConfirmationLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="rechargecoinConfirmationLabel">Recharge Coin Confirmation</h5>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-lg-12">
                        <label>Number of coins</label>
                        <div class="form-group">
                            <input type="number" id="coins" class="form-control">
                        </div>
                    </div>
                </div>
                <input type="hidden" id="retailer-id">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" id="recharge-btn" data-bs-dismiss="modal">Recharge</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Decline</button>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        var table = $('#administrators').DataTable( {
            buttons: [ 'excel']
        } );
        
        table.buttons().container()
            .appendTo( '#administrators_wrapper .col-md-6:eq(0)' );

        $(document).find("title").text("Retailers");

        $(document).find(".delete-user").click(function(e){
            e.preventDefault();
            var id = $(document).find(this).attr("data-id");
            $(document).find("#delete-user-id").val(id);
        });

        $(document).find("#delete-user-btn").click(function(e){
            e.preventDefault();
            var id = $(document).find("#delete-user-id").val();
            if(id=="")
            {
                alert("Something is wrong! Try again later");
            }
            else
            { 
                $.ajax({
                url: '<?php echo base_url('admin/deleteUser') ?>',
                method: 'POST',
                data: {
                    id: id
                    },
                    success: function (response) 
                    {
                        var res = JSON.parse(response);
                        if(res['statusCode'] == 2)
                        {
                            success_noti(res['Message']);
                            window.location.reload();
                        }
                        else if(res['statusCode'] == 1)
                        {
                            warning_noti(res['Message']);
                        }
                        else if(res['statusCode'] == 0)
                        {
                            error_noti(res['Message']);
                        }
                    }
                });
            }
        });

        
        $(document).find(".retailer-details").click(function(e){
            e.preventDefault();
            var id = $(document).find(this).attr("data-id");
            if(id=="")
            {
                alert("Something is wrong! Try again later");
            }
            else
            { 
            $.ajax({
                url : '<?php echo base_url('admin/userDetailes') ?>',
                method: 'POST',
                data: {
                    id: id
                    },
                    success: function (response) 
                    {
                        var res = JSON.parse(response);
                        $(document).find(".retailer-image").attr('src',"<?php echo base_url('upload/user/profilephoto/'); ?>"+res['profile']);
                        $(document).find(".name").text(res['name']);
                        $(document).find(".contact").text(res['contact']);
                        $(document).find(".email").text(res['email']);
                        $(document).find(".username").text(res['username']);
                    }
                });
            }
        });

        $(document).find(".recharge").click(function(e){
            e.preventDefault();
            var id = $(document).find(this).attr("data-id");
            $(document).find("#retailer-id").val(id);
        });

        $(document).find("#recharge-btn").click(function(e){
            e.preventDefault();
            var retailer_id = $(document).find("#retailer-id").val();
            var coins = $(document).find("#coins").val();
            if(retailer_id == "")
            {
                alert("Something is wrong! Try again later");
            } 
            else if(coins == "")
            {
                warning_noti("Recharge Coin is required!");
            }
            else
            {
                $.ajax({
                    url: '<?php echo base_url('admin/rechargecoins') ?>',
                    method: 'POST',
                    data: {
                        retailer_id: retailer_id,
                        coins: coins
                        },
                    success: function (response) 
                    {
                        var res = JSON.parse(response);
                        if(res['statusCode'] == 3)
                        {
                            success_noti(res['Message']);
                            window.location.reload();
                        }
                        else if(res['statusCode'] == 2)
                        {
                            warning_noti(res['Message']);
                        }
                        else if(res['statusCode'] == 1)
                        {
                            warning_noti(res['Message']);
                        }
                        else if(res['statusCode'] == 4)
                        {
                            warning_noti(res['Message']);
                        }
                        else if(res['statusCode'] == 0)
                        {
                            error_noti(res['Message']);
                        }
                    }
                })
            }
            
        });
        
        
        $(document).find(".view-status").click(function(e){
            e.preventDefault();
            var id = $(document).find(this).attr("data-id");
            var status = $(document).find(this).attr("status-id");
            var new_status ="";
            if(status == "1")
            {
                new_status ="Deactivate";
                status= "0";
            }
            else if(status == "0")
            {
                new_status ="Activate";
                status= "1";
            }
            $(document).find("#v-user-id").val(id);
            $(document).find("#v-status").text(new_status);
            $(document).find("#v-status-id").val(status);
        });
        
        $(document).find("#change-v-status-btn").click(function(e){
            e.preventDefault();
            var id = $(document).find("#v-user-id").val();
            var status_id = $(document).find("#v-status-id").val();
            if(id=="" && status_id == "")
            {
                alert("Something is wrong! Try again later");
            }
            else
            { 
                $.ajax({
                url: '<?php echo base_url('admin/changeViewStatus') ?>',
                method: 'POST',
                data: {
                    id: id,
                    status_id : status_id
                    },
                    success: function (response) 
                    {
                        var res = JSON.parse(response);
                        if(res['statusCode'] == 2)
                        {
                            success_noti(res['Message']);
                            window.location.reload();
                        }
                        else if(res['statusCode'] == 1)
                        {
                            warning_noti(res['Message']);
                        }
                        else if(res['statusCode'] == 0)
                        {
                            error_noti(res['Message']);
                        }
                    }
                });
            }
        });

    });

    function error_noti(message) 
    {
        Lobibox.notify('error', {
            pauseDelayOnHover: true,
            continueDelayOnInactiveTab: false,
            position: 'top right',
            icon: 'bx bx-x-circle',
            msg: message
        });
    }
    function warning_noti(message) 
    {
        Lobibox.notify('warning', {
            pauseDelayOnHover: true,
            continueDelayOnInactiveTab: false,
            position: 'top right',
            icon: 'bx bx-error',
            msg: message
        });
    }
    function success_noti(message) 
    {
        Lobibox.notify('success', {
            pauseDelayOnHover: true,
            continueDelayOnInactiveTab: false,
            position: 'top right',
            icon: 'bx bx-check-circle',
            msg: message
        });
    }
</script>