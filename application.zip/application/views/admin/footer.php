<footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-sm-6">
                                <script>document.write(new Date().getFullYear())</script> © Admin
                            </div>
                            <div class="col-sm-6">
                                <div class="text-sm-end d-none d-sm-block">
                                    Coded with ABC
                                </div>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
            <!-- end main content-->

        </div>
        <!-- END layout-wrapper -->

        <!-- Right bar overlay-->
        <div class="rightbar-overlay"></div>

        <!-- JAVASCRIPT -->
        <script src="<?php echo base_url('myassets/libs/bootstrap/js/bootstrap.bundle.min.js') ?>"></script>
        <script src="<?php echo base_url('myassets/libs/metismenu/metisMenu.min.js') ?>"></script>
        <script src="<?php echo base_url('myassets/libs/simplebar/simplebar.min.js') ?>"></script>
        <script src="<?php echo base_url('myassets/libs/node-waves/waves.min.js') ?>"></script>
        <script src="<?php echo base_url('myassets/libs/feather-icons/feather.min.js') ?>"></script>
        <!-- pace js -->
        <script src="<?php echo base_url('myassets/libs/pace-js/pace.min.js') ?>"></script>

        <!-- apexcharts -->
        <script src="<?php echo base_url('myassets/libs/apexcharts/apexcharts.min.js') ?>"></script>

        <!-- Plugins js-->
        <script src="<?php echo base_url('myassets/libs/admin-resources/jquery.vectormap/jquery-jvectormap-1.2.2.min.js') ?>"></script>
        <script src="<?php echo base_url('myassets/libs/admin-resources/jquery.vectormap/maps/jquery-jvectormap-world-mill-en.js') ?>"></script>
        <!-- dashboard init -->
        <script src="<?php echo base_url('myassets/js/pages/dashboard.init.js') ?>"></script>

        <script src="<?php echo base_url('myassets/js/app.js') ?>"></script>
        <script src="<?php echo base_url('myassets/libs/sweetalert2/sweetalert2.min.js') ?>"></script>

         <!-- Required datatable js -->
        <script src="<?php echo base_url('myassets/libs/datatables.net/js/jquery.dataTables.min.js') ?>"></script>
        <script src="<?php echo base_url('myassets/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js') ?>"></script>
        <!-- Buttons examples -->
        <script src="<?php echo base_url('myassets/libs/datatables.net-buttons/js/dataTables.buttons.min.js') ?>"></script>
        <script src="<?php echo base_url('myassets/libs/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js') ?>"></script>
        <script src="<?php echo base_url('myassets/libs/jszip/jszip.min.js') ?>"></script>
        <script src="<?php echo base_url('myassets/libs/pdfmake/build/pdfmake.min.js') ?>"></script>
        <script src="<?php echo base_url('myassets/libs/pdfmake/build/vfs_fonts.js') ?>"></script>
        <script src="<?php echo base_url('myassets/libs/datatables.net-buttons/js/buttons.html5.min.js') ?>"></script>
        <script src="<?php echo base_url('myassets/libs/datatables.net-buttons/js/buttons.print.min.js') ?>"></script>
        <script src="<?php echo base_url('myassets/libs/datatables.net-buttons/js/buttons.colVis.min.js') ?>"></script>

        <!-- Responsive examples -->
        <script src="<?php echo base_url('myassets/libs/datatables.net-responsive/js/dataTables.responsive.min.js') ?>"></script>
        <script src="<?php echo base_url('myassets/libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js') ?>"></script>

        <!-- Datatable init js -->
        <script src="<?php echo base_url('myassets/js/pages/datatables.init.js') ?>"></script>    
    </body>

    <script>
        $(document).ready(function() {
            document.body.setAttribute('data-sidebar-size', 'lg')
        });
    </script>
</html>