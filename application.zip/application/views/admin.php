<!--start page wrapper -->
<div class="page-wrapper">
    <div class="page-content">
        <h5 class="mb-0 text-uppercase">Admin</h5>
        <hr/>
        <div class="card">
            <div class="card-body">
                <div class="d-lg-flex align-items-center mb-4 gap-3">
                    <div class="position-relative">
                        <h6>Admin List</h6>
                    </div>
                    <div class="ms-auto"><a href="<?php echo base_url('administrator/createadmin') ?>" class="btn btn-light radius-30 mt-2 mt-lg-0"><i class="bx bxs-plus-square"></i>Create New Admin</a></div>
                </div>
                <div class="table-responsive">
                    <table id="administrators" class="table mb-0">
                        <thead>
                            <tr class="bg-light">
                                <th>Sr.No</th>
                                <th>Profile</th>
                                <th>Name</th>
                                <th>Username</th>
                                <th>Status</th>
                                <th>Total Employee</th>
                                <th>Total Retailer</th>
                                <th>Total Coins</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $count=1; foreach($admin_data as $data) {  $profile = $data['profile']; ?>
                            <tr>
                                <td><?php echo $count++; ?>.</td>
                                <td><img src="<?php echo base_url('upload/admin/profilephoto'); ?>/<?php echo ($profile !="") ? $profile: "profile.png"; ?>" alt class="user-img"></td>
                                <td><?php echo $data['name'] ?></td>
                                <td><?php echo $data['username'] ?></td>
                                <td>
                                    <?php if($data['status']==1) { ?>
                                        <button class="btn btn-success btn-sm profile-status" data-id="<?php echo $data['id']; ?>" status-id="1"  data-bs-toggle="modal" data-bs-target="#userStatusConfirmation">Active</button>
                                    <?php } else { ?>
                                        <button class="btn btn-warning btn-sm profile-status" data-id="<?php echo $data['id']; ?>" status-id="0" data-bs-toggle="modal" data-bs-target="#userStatusConfirmation">Inactive</button>
                                    <?php } ?>
                                </td>
                                <td><?php echo $data['no_of_employee'] ?></td>
                                <td><?php echo $data['no_of_retailer'] ?></td>
                                <td><?php echo $data['coins'] ?></td>
                                <td>
                                    <div class="btn-group">
                                        <button class="btn btn-light btn-sm admin-details" title="Admin Details" data-id="<?php echo $data['id']; ?>" data-bs-toggle="modal" data-bs-target="#viewaAdminConfirmation"><i class="bx bx-detail"></i></button>
                                        <a href="<?php echo base_url('administrator/editadmindetails') ?>?admin=<?php echo $data['id'   ]; ?>" class="btn btn-light btn-sm" title="Edit Admin"><i class="bx bxs-edit"></i></a>
                                        <button class="btn btn-light btn-sm change-password" title="Change Password" data-id="<?php echo $data['id']; ?>" data-bs-toggle="modal" data-bs-target="#changepasswordConfirmation"><i class="bx bxs-lock"></i></button>
                                        <button class="btn btn-light btn-sm recharge" title="Recharge" data-id="<?php echo $data['id']; ?>" data-bs-toggle="modal" data-bs-target="#rechargecoinConfirmation"><i class="bx bxs-coin"></i></button>
                                        <button class="btn btn-light btn-sm delete-admin" title="Delete Admin" data-id="<?php echo $data['id']; ?>" data-bs-toggle="modal" data-bs-target="#deleteUserConfirmation"><i class="bx bxs-trash"></i></button>
                                    </div>
                                </td>
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<!--end page wrapper -->
<div class="modal fade" id="userStatusConfirmation" tabindex="-1" aria-labelledby="userStatusConfirmationLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="userStatusConfirmationLabel">Confirmation</h5>
            </div>
            <div class="modal-body">
                Are you sure you want to <span id="status"></span> this admin ?
                <input type="hidden" id="user-id">
                <input type="hidden" id="status-id">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" id="change-status-btn" data-bs-dismiss="modal">Confirm</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Decline</button>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="changepasswordConfirmation" tabindex="-1" aria-labelledby="changepasswordConfirmationLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="changepasswordConfirmationLabel">Change Password Confirmation</h5>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-lg-12">
                        <label>New Password</label>
                        <div class="form-group">
                            <input type="text" id="new_password" class="form-control">
                        </div>
                    </div>
                    <div class="col-lg-12">
                        <label>Confirm Password</label>
                        <div class="form-group">
                            <input type="text" id="confirm_password" class="form-control">
                        </div>
                    </div>
                </div>
                <input type="hidden" id="change-password-id">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" id="change-password-btn" data-bs-dismiss="modal">Change</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Decline</button>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="rechargecoinConfirmation" tabindex="-1" aria-labelledby="rechargecoinConfirmationLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="rechargecoinConfirmationLabel">Recharge Coin Confirmation</h5>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-lg-12">
                        <label>Number of coins</label>
                        <div class="form-group">
                            <input type="number" id="coins" class="form-control">
                        </div>
                    </div>
                </div>
                <input type="hidden" id="recharge-id">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" id="recharge-btn" data-bs-dismiss="modal">Recharge</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Decline</button>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="deleteUserConfirmation" tabindex="-1" aria-labelledby="deleteUserConfirmationLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteUserConfirmationLabel">Confirmation</h5>
            </div>
            <div class="modal-body">
                Are you sure you want to Delete this Administrator ?
                <input type="hidden" id="delete-user-id">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" id="delete-user-btn" data-bs-dismiss="modal">Confirm</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Decline</button>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="viewaAdminConfirmation" tabindex="-1" aria-labelledby="viewaAdminConfirmationLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="viewaAdminConfirmation">Admin Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-lg-12 col-sm-12">
                        <div class="d-flex flex-column align-items-center text-center">
                            <img src="" class="rounded-circle p-1 bg-primary admin-image" style="height: 110px">
                        </div>
                    </div>
                    <div class="col-lg-12 col-sm-12">
                        <div class="text-center">
                            <p class="mb-0 mt-4">Name : <span class="name"></span></p>
                        </div>
                    </div>
                    <div class="col-lg-12 col-sm-12">
                        <div class="text-center">
                            <p class="mb-0">Contact : <span class="contact"></span></p>
                        </div>
                    </div>
                    <div class="col-lg-12 col-sm-12">
                        <div class="text-center">
                            <p class="mb-0">Email : <span class="email"></span></p>
                        </div>
                    </div>
                    <div class="col-lg-12 col-sm-12">
                        <div class="text-center">
                            <p>Username : <span class="username"></span></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function() {
        var table = $('#administrators').DataTable( {
            buttons: [ 'excel']
        } );
        
        table.buttons().container()
            .appendTo( '#administrators_wrapper .col-md-6:eq(0)' );

        $(document).find("title").text("Admin");

        $(document).find(".profile-status").on("click", function(e){
            e.preventDefault();
            var user_id = $(document).find(this).attr("data-id");
            var status = $(document).find(this).attr("status-id");
            var new_status ="";
            if(status == "1")
            {
                new_status ="Deactivate";
                status= "0";
            }
            else if(status == "0")
            {
                new_status ="Activate";
                status= "1";
            }
            $(document).find("#user-id").val(user_id);
            $(document).find("#status").text(new_status);
            $(document).find("#status-id").val(status);
        });

        $(document).find("#change-status-btn").on("click", function(e){
            e.preventDefault();
            var user_id = $(document).find("#user-id").val();
            var status_id = $(document).find("#status-id").val();
            if(user_id=="" && status_id == "")
            {
                alert("Something is wrong! Try again later");
            }
            else
            { 
                $.ajax({
                url: '<?php echo base_url('administrator/changeAdminStatus') ?>',
                method: 'POST',
                data: {
                    user_id: user_id,
                    status_id : status_id
                    },
                    success: function (response) 
                    {
                        var res = JSON.parse(response);
                        if(res['statusCode'] == 2)
                        {
                            success_noti(res['Message']);
                            window.location.reload();
                        }
                        else if(res['statusCode'] == 1)
                        {
                            warning_noti(res['Message']);
                        }
                        else if(res['statusCode'] == 0)
                        {
                            error_noti(res['Message']);
                        }
                    }
                });
            }
        });

        $(document).find(".change-password").click(function(e){
            e.preventDefault();
            var id = $(document).find(this).attr("data-id");
            $(document).find("#change-password-id").val(id);
        });

        $(document).find("#change-password-btn").click(function(e){
            e.preventDefault();
            var admin_id = $(document).find("#change-password-id").val();
            var new_password = $(document).find("#new_password").val();
            var confirm_password = $(document).find("#confirm_password").val();
            
            if(admin_id=="")
            {
                alert("Something is wrong! Try again later");
            } 
            else if(new_password == "")
            {
                warning_noti("New Password is required!");
            }
            else if(confirm_password == "")
            {
                warning_noti("Confirm Password is required!");
            }
            else if(confirm_password != new_password)
            {
                warning_noti("Confirm Password and new Password must be same!");
            }
            else
            {
                $.ajax({
                    url: '<?php echo base_url('administrator/changepasswordadminath') ?>',
                    method: 'POST',
                    data: {
                        admin_id: admin_id,
                        new_password: new_password
                        },
                    success: function (response) 
                    {
                        var res = JSON.parse(response);
                        if(res['statusCode'] == 3)
                        {
                            success_noti(res['Message']);
                            window.location.reload();
                        }
                        else if(res['statusCode'] == 2)
                        {
                            warning_noti(res['Message']);
                        }
                        else if(res['statusCode'] == 0)
                        {
                            error_noti(res['Message']);
                        }
                    }
                })
            }
            
        });

        $(document).find(".recharge").click(function(e){
            e.preventDefault();
            var id = $(document).find(this).attr("data-id");
            $(document).find("#recharge-id").val(id);
        });

        $(document).find("#recharge-btn").click(function(e){
            e.preventDefault();
            var admin_id = $(document).find("#recharge-id").val();
            var coins = $(document).find("#coins").val();
            if(admin_id=="")
            {
                alert("Something is wrong! Try again later");
            } 
            else if(coins == "")
            {
                warning_noti("Recharge Coin is required!");
            }
            else
            {
                $.ajax({
                    url: '<?php echo base_url('administrator/rechargecoins') ?>',
                    method: 'POST',
                    data: {
                        admin_id: admin_id,
                        coins: coins
                        },
                    success: function (response) 
                    {
                        var res = JSON.parse(response);
                        if(res['statusCode'] == 3)
                        {
                            success_noti(res['Message']);
                            window.location.reload();
                        }
                        else if(res['statusCode'] == 2)
                        {
                            warning_noti(res['Message']);
                        }
                        else if(res['statusCode'] == 1)
                        {
                            warning_noti(res['Message']);
                        }
                        else if(res['statusCode'] == 0)
                        {
                            error_noti(res['Message']);
                        }
                    }
                })
            }
            
        });

        $(document).find(".delete-admin").click(function(e){
            e.preventDefault();
            var user_id = $(document).find(this).attr("data-id");
            $(document).find("#delete-user-id").val(user_id);
        });

        $(document).find("#delete-user-btn").click(function(e){
            e.preventDefault();
            var user_id = $(document).find("#delete-user-id").val();
            if(user_id=="")
            {
                alert("Something is wrong! Try again later");
            }
            else
            { 
                $.ajax({
                url: '<?php echo base_url('administrator/deleteadmins') ?>',
                method: 'POST',
                data: {
                    user_id: user_id
                    },
                    success: function (response) 
                    {
                        var res = JSON.parse(response);
                        if(res['statusCode'] == 2)
                        {
                            success_noti(res['Message']);
                            window.location.reload();
                        }
                        else if(res['statusCode'] == 1)
                        {
                            warning_noti(res['Message']);
                        }
                        else if(res['statusCode'] == 0)
                        {
                            error_noti(res['Message']);
                        }
                    }
                });
            }
        });

        $(document).find(".admin-details").click(function(e){
            e.preventDefault();
            var id = $(document).find(this).attr("data-id");
            if(id=="")
            {
                alert("Something is wrong! Try again later");
            }
            else
            { 
            $.ajax({
                url : '<?php echo base_url('administrator/admindetail') ?>',
                method: 'POST',
                data: {
                    id: id
                    },
                    success: function (response) 
                    {
                        var res = JSON.parse(response);
                        $(document).find(".admin-image").attr('src',"<?php echo base_url('upload/admin/profilephoto/'); ?>"+res['profile']);
                        $(document).find(".name").text(res['name']);
                        $(document).find(".contact").text(res['contact']);
                        $(document).find(".email").text(res['email']);
                        $(document).find(".username").text(res['username']);
                    }
                });
            }
        });
        $(document).find("title").text("Admin List");
    });

    function error_noti(message) 
    {
        Lobibox.notify('error', {
            pauseDelayOnHover: true,
            continueDelayOnInactiveTab: false,
            position: 'top right',
            icon: 'bx bx-x-circle',
            msg: message
        });
    }
    function warning_noti(message) 
    {
        Lobibox.notify('warning', {
            pauseDelayOnHover: true,
            continueDelayOnInactiveTab: false,
            position: 'top right',
            icon: 'bx bx-error',
            msg: message
        });
    }
    function success_noti(message) 
    {
        Lobibox.notify('success', {
            pauseDelayOnHover: true,
            continueDelayOnInactiveTab: false,
            position: 'top right',
            icon: 'bx bx-check-circle',
            msg: message
        });
    }

</script>