<!--start page wrapper -->
<div class="page-wrapper">
    <div class="page-content">
        <h5 class="mb-0 text-uppercase">Admin Coins</h5>
        <hr/>
        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table id="admincoins" class="table mb-0">
                        <thead>
                            <tr class="bg-light">
                                <th>Sr.No</th>
                                <th>Username</th>
                                <th>Admin Id</th>
                                <th>Number of Coins</th>
                                <th>Created Date</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $count=1; foreach($admin_coins as $data) { ?>
                            <tr>
                                <td><?php echo $count++; ?>.</td>
                                <td><?php echo $data['username'] ?></td>
                                <td><?php echo $data['admin_id'] ?></td>
                                <td><?php echo $data['coins'] ?></td>
                                <td><?php echo $data['created_at'] ?></td>
                                <td>
                                    <?php if($data['status'] ==1 )
                                    {
                                        ?>
                                        <span class='badge bg-success'>Success</span>
                                        <?php
                                    } 
                                    else if($data['status']==0)
                                    {
                                    ?>
                                        <span class='badge bg-warning'>Pending</span>
                                    <?php 
                                    }
                                    else
                                    {
                                        ?>
                                        <span class='badge bg-danger'>Cancelled</span>
                                        <?php
                                    }

                                    ?>
                                </td>
                                <td>
                                    <?php if($data['status'] == 1)
                                    {
                                        ?>
                                            <button class="btn btn-light btn-sm revert-admin-coins" title="Revert Coin" data="<?php echo $data['coins'] ?>" data-id="<?php echo $data['id']; ?>" data-bs-toggle="modal" data-bs-target="#deleteUserConfirmation"><i class="bx bx-revision"></i></button>
                                        <?php
                                    }
                                    ?>
                                </td>                                  
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="deleteUserConfirmation" tabindex="-1" aria-labelledby="deleteUserConfirmationLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteUserConfirmationLabel">Revert Recharge Confirmation</h5>
            </div>
            <div class="modal-body">
                Are you sure you want to Reverter Recharge of this admin ?
                <input type="hidden" id="admin-coin-id">
                <input type="hidden" id="no-of-coins">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" id="revert-btn" data-bs-dismiss="modal">Confirm</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Decline</button>
            </div>
        </div>
    </div>
</div>
<!--end page wrapper -->
<script>
    $(document).ready(function() {
        var table = $('#admincoins').DataTable( {
            buttons: [ 'excel']
        } );
        
        table.buttons().container()
            .appendTo( '#admincoins_wrapper .col-md-6:eq(0)' );

        $(document).find("title").text("Admin Coins History");

        $(document).find(".revert-admin-coins").on("click", function(e){
            e.preventDefault();
            var admin_coins_id = $(document).find(this).attr("data-id");
            var coins = $(document).find(this).attr("data");
            $(document).find("#admin-coin-id").val(admin_coins_id);
            $(document).find("#no-of-coins").val(coins);
        });

        $(document).find("#revert-btn").on("click", function(e){
            e.preventDefault();
            var id = $(document).find("#admin-coin-id").val();
            var coins = $(document).find("#no-of-coins").val();
            if(id=="" && coins == "")
            {
                alert("Something is wrong! Try again later");
            }
            else
            { 
                $.ajax({
                url: '<?php echo base_url('administrator/revertadmincoins') ?>',
                method: 'POST',
                data: {
                    id: id,
                    coins : coins
                    },
                    success: function (response) 
                    {
                        var res = JSON.parse(response);
                        if(res['statusCode'] == 2)
                        {
                            success_noti(res['Message']);
                            window.location.reload();
                        }
                        else if(res['statusCode'] == 1)
                        {
                            warning_noti(res['Message']);
                        }
                        else if(res['statusCode'] == 0)
                        {
                            error_noti(res['Message']);
                        }
                    }
                });
            }
        });
    } );

    function error_noti(message) 
    {
        Lobibox.notify('error', {
            pauseDelayOnHover: true,
            continueDelayOnInactiveTab: false,
            position: 'top right',
            icon: 'bx bx-x-circle',
            msg: message
        });
    }
    function warning_noti(message) 
    {
        Lobibox.notify('warning', {
            pauseDelayOnHover: true,
            continueDelayOnInactiveTab: false,
            position: 'top right',
            icon: 'bx bx-error',
            msg: message
        });
    }
    function success_noti(message) 
    {
        Lobibox.notify('success', {
            pauseDelayOnHover: true,
            continueDelayOnInactiveTab: false,
            position: 'top right',
            icon: 'bx bx-check-circle',
            msg: message
        });
    }
    
</script>