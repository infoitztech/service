<!--start page wrapper -->
<div class="page-wrapper">
    <div class="page-content">
        <h5 class="mb-0 text-uppercase">Member</h5>
        <hr/>
        <div class="card">
            <div class="card-body">
                <div class="d-lg-flex align-items-center mb-4 gap-3">
                    <div class="position-relative">
                        <h6>Member List</h6>
                    </div>
                </div>
                <form method="post" action="<?php echo base_url('administrator/members'); ?>">
                    <div class="row">
                        <div class="col-lg-3">
                            <label>Select Type</label>
                            <div class="form-group">
                                <select name="type" class="form-control">
                                    <option value="">Select</option>
                                    <option value="Update">Update</option>
                                    <option value="Bank">Bank</option>
                                    <option value="Other">Other</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <label>Status</label>
                            <div class="form-group">
                                <select name="status"class="form-control">
                                    <option value="">Select</option>
                                    <option value="Pending">Pending</option>
                                    <option value="Success">Success</option>
                                    <option value="Cancelled">Cancel</option>
                                    <option value="rejected">Rejected</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <label>Select Admin</label>
                            <div class="form-group">
                                <select name="admin" class="form-control">
                                    <option value="">Select</option>
                                    <?php foreach($admin_list as $data){ ?>
                                    <option value="<?php echo $data['id']; ?>"><?php echo $data['username']; ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <label>Select Retailer</label>
                            <div class="form-group">
                                <select name="retailer" class="form-control">
                                    <option value="">Select</option>
                                    <?php foreach($retailer_list as $data){ ?>
                                    <option value="<?php echo $data['user_id']; ?>"><?php echo $data['username']; ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <label>Select Employee</label>
                            <div class="form-group">
                                <select name="employee" class="form-control">
                                    <option value="">Select</option>
                                    <?php foreach($employee_data as $data){ ?>
                                    <option value="<?php echo $data['username']; ?>"><?php echo $data['username']; ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <label>Create From</label>
                            <div class="form-group">
                                <input type="datetime-local" name="start_date" class="form-control">
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <label>Create To</label>
                            <div class="form-group">
                                <input type="datetime-local" name="end_date" class="form-control">
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <label>employee action From</label>
                            <div class="form-group">
                                <input type="datetime-local" name="remark_start_date" class="form-control">
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <label>employee action To</label>
                            <div class="form-group">
                                <input type="datetime-local" name="remark_end_date" class="form-control">
                            </div>
                        </div>
                        <div class="col-lg-3 mt-4">
                            <div class="form-group">
                                <button type="submit" name="search" class="btn btn-light">Search</button>
                            </div>
                        </div>
                    </div>
                </form>
                <div class="table-responsive">
                    <table id="studenttable" class="table mb-0">
                        <thead>
                            <tr class="bg-light">
                                <th>Sr.No</th>
                                <th>Ref. No.</th>
                                <th>Name</th>
                                <th>Type</th>
                                <th>Purpose</th>
                                <th>Status</th>
                                <th>Retailer</th>
                                <th>Admin</th>
                                <th>Created Date</th>
                                <th>Employee</th>
                                <th>Remark</th>
                                <th>Employee Remark Date</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $count=1; foreach($user_data as $data) {   ?>
                            <tr>
                                <td><?php echo $count++; ?>.</td>
                                <td>#<?php echo $data['ref_id']; ?></td>
                                <td><?php echo $data['member_name']; ?></td>
                                <td><?php echo $data['type']; ?></td>
                                <td><?php echo $data['purpose']; ?></td>
                                <td>
                                    <?php if($data['status']=="Success") { ?>
                                    <button class="btn btn-success btn-sm">Success</button>
                                    <?php }else if($data['status']=="Cancelled") { ?>
                                    <button class="btn btn-danger btn-sm">Cancelled</button>
                                    <?php }else if($data['status']=="rejected") { ?>
                                    <button class="btn btn-danger btn-sm">rejected</button>
                                    <?php } else { ?>
                                    <button class="btn btn-warning btn-sm">Pending</button>
                                    <?php } ?>
                                </td>
                                <td><?php echo $data['retailer']; ?></td>
                                <td><?php echo $data['username']; ?></td>
                                <td><?php echo $data['created_date']; ?></td>
                                <td><?php echo $data['employee_name']; ?></td>
                                <td><?php echo $data['remark2']; ?></td>
                                <td><?php echo $data['remark_date']; ?></td>
                                <td>
                                    <div class="btn-group">
                                        <?php if($permission_details['student_finger'] == "1") { ?>
                                        <a href="<?php echo base_url('administrator/memberdetails') ?>?member=<?php echo $data['id']; ?>" class="btn btn-light btn-sm " title="Member Details"><i class="bx bx-detail"></i></a>
                                        <?php } ?>
                                        <?php if($permission_details['student_finger'] == "1") { ?>
                                        <a href="<?php echo base_url('administrator/fingerprints') ?>?member=<?php echo $data['id']; ?>" target="_blank" class="btn btn-light btn-sm " title=" Finger Prints"><i class="bx bx-images"></i></a>
                                        <?php } ?>
                                        <?php if($permission_details['delete_student'] == "1") { ?>
                                        <button class="btn btn-light btn-sm delete-user" title="Delete Retailer" data-id="<?php echo $data['id']; ?>" data-bs-toggle="modal" data-bs-target="#deleteUserConfirmation"><i class="bx bxs-trash"></i></button>
                                        <?php } ?>
                                    </div>
                                </td>
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<!--end page wrapper -->
<div class="modal fade" id="deleteUserConfirmation" tabindex="-1" aria-labelledby="deleteUserConfirmationLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteUserConfirmationLabel">Confirmation</h5>
            </div>
            <div class="modal-body">
                Are you sure you want to Delete this Student ?
                <input type="hidden" id="delete-user-id">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" id="delete-user-btn" data-bs-dismiss="modal">Confirm</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Decline</button>
            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function() {
        var table = $('#studenttable').DataTable( {
            buttons: [ 'excel']
        } );
        
        table.buttons().container()
            .appendTo( '#studenttable_wrapper .col-md-6:eq(0)' );

        $(document).find("title").text("Members List");
        
        $(document).find(".delete-user").click(function(e){
            e.preventDefault();
            var user_id = $(document).find(this).attr("data-id");
            $(document).find("#delete-user-id").val(user_id);
        });

        $(document).find("#delete-user-btn").click(function(e){
            e.preventDefault();
            var student_id = $(document).find("#delete-user-id").val();
            if(student_id=="")
            {
                alert("Something is wrong! Try again later");
            }
            else
            { 
                $.ajax({
                url: '<?php echo base_url('administrator/deleteStudent') ?>',
                method: 'POST',
                data: {
                    student_id: student_id
                    },
                    success: function (response) 
                    {
                        var res = JSON.parse(response);
                        if(res['statusCode'] == 2)
                        {
                            success_noti(res['Message']);
                            window.location.reload();
                        }
                        else if(res['statusCode'] == 1)
                        {
                            warning_noti(res['Message']);
                        }
                        else if(res['statusCode'] == 0)
                        {
                            error_noti(res['Message']);
                        }
                    }
                });
            }
        });

    });
    
        function error_noti(message) 
		{
			Lobibox.notify('error', {
				pauseDelayOnHover: true,
				continueDelayOnInactiveTab: false,
				position: 'top right',
				icon: 'bx bx-x-circle',
				msg: message
			});
		}
		function warning_noti(message) 
		{
			Lobibox.notify('warning', {
				pauseDelayOnHover: true,
				continueDelayOnInactiveTab: false,
				position: 'top right',
				icon: 'bx bx-error',
				msg: message
			});
		}
		function success_noti(message) 
		{
			Lobibox.notify('success', {
				pauseDelayOnHover: true,
				continueDelayOnInactiveTab: false,
				position: 'top right',
				icon: 'bx bx-check-circle',
				msg: message
			});
		}
</script>