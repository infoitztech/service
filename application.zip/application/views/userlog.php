<!--start page wrapper -->
<div class="page-wrapper">
    <div class="page-content">
        <h5 class="mb-0 text-uppercase">User Log</h5>
        <hr/>
        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table id="userlog" class="table mb-0">
                        <thead>
                            <tr class="bg-light">
                                <th>Sr.No.</th>
                                <th>User</th>
                                <th>Action</th>
                                <th>IP Address</th>
                                <th>Platform</th>
                                <th>Browser</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $count=1; foreach($user_log as $data) { ?>
                            <tr>
                                <td><?php echo $count++; ?></td>
                                <td><?php echo $data['username']."." ?></td>
                                <td><?php echo $data['message'] ?></td>
                                <td><?php echo $data['ip_address'] ?></td>
                                <td><?php echo $data['platform'] ?></td>
                                <td><?php echo $data['browser'] ?>-<?php echo $data['browser_version'] ?></td>
                                <td><?php echo $data['created_date'] ?></td>
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<!--end page wrapper -->
<script>
    $(document).ready(function() {
        var table = $('#userlog').DataTable( {
            buttons: [ 'excel']
        } );
        
        table.buttons().container()
            .appendTo( '#userlog_wrapper .col-md-6:eq(0)' );

        $(document).find("title").text("Retailer Log");
    } );
    
</script>