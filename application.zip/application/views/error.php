<?php
header("Location: https://google.com");
exit();
?>