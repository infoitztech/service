<!--start page wrapper -->
<div class="page-wrapper">
    <div class="page-content">
        <div class="row">
            <div class="col-xl-7 mx-auto">
                <h5 class="mb-0 text-uppercase">Admin</h5>
                <hr/>
                <div class="card border-top border-0 border-4 border-white">
                    <div class="card-body p-5">
                        <div class="card-title d-flex align-items-center">
                            <h6 class="mb-0 text-white">Create New Admin</h6>
                        </div>
                        <hr>
                        <form class="row g-3"  method="post" enctype="multipart/form-data" id="admin-form">
                            <div class="col-md-6">
                                <label for="name" class="form-label">Name </label>
                                <input type="text" class="form-control" id="name" name="name">
                            </div>
                            <div class="col-md-6">
                                <label for="emp-code" class="form-label">Mobile No. </label>
                                <input type="text" class="form-control" id="contact" name="contact">
                            </div>
                            <div class="col-md-6">
                                <label for="mobile" class="form-label">Email </label>
                                <input type="email" class="form-control" id="email" name="email">
                            </div>
                            <div class="col-md-6">
                                <label for="profile" class="form-label">Profile Photo </label>
                                <input type="file" class="form-control" id="profile-photo" name="profile-photo">
                            </div>
                            <div class="col-md-6">
                                <label for="status" class="form-label">Profile Status</label>
                                <select class="form-select" name="status" id="status">
                                    <option value="">Select Status</option>
                                    <option value="1">Active</option>
                                    <option value="0">Inactive</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label for="email" class="form-label">Username </label>
                                <input type="text" class="form-control" id="username" name="username">
                            </div>
                            <div class="col-md-6">
                                <label for="password" class="form-label">Password </label>
                                <input type="text" class="form-control" id="password" name="password">
                            </div>
                            <div class="col-md-6">
                                <label for="email" class="form-label">Number of Retailer</label>
                                <input type="text" class="form-control" id="no_of_retailer" name="no_of_retailer">
                            </div>
                            <div class="col-md-6">
                                <label for="email" class="form-label">Number of Employee</label>
                                <input type="text" class="form-control" id="no_of_employee" name="no_of_employee">
                            </div>        
                            <div class="col-md-6"></div>                    
                            <div class="col-4 mx-auto">
                                <button type="submit" class="btn btn-light px-5">Create</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--end page wrapper -->
<script>
    $(document).ready(function () {
        $('#admin-form').on('submit', function(event){
            event.preventDefault();
            var name = $(document).find("#name").val();
            var contact = $(document).find("#contact").val();
            var email = $(document).find("#email").val();
            var status = $(document).find("#status:selected").val();
            var username = $(document).find("#username").val();
            var password = $(document).find("#password").val();
            var no_of_retailer = $(document).find("#no_of_retailer").val();            
            var no_of_employee = $(document).find("#no_of_employee").val();            
            
            if(name=="")
            {
                error_noti("Admin Name is required!");
            }
            else if(contact == "")
            {
                error_noti("Admin contact is required!");
            }
            else if(email == "")
            {
                error_noti("Admin Email is required!");
            }
            else if(status == "")
            {
                error_noti("Profile status is required!");
            }
            else if(username == "")
            {
                error_noti("Username is required!");
            }
            else if(password == "")
            {
                error_noti("Password is required!");
            }
            else if(no_of_retailer == "")
            {
                error_noti("Number of Retailer is required!");
            }
            else if(no_of_employee == "")
            {
                error_noti("Number of Employee is required!");
            }
            else
            {

                var formData = new FormData(this);
                $.ajax({
                    url: '<?php echo base_url('administrator/createAdminAth') ?>',
                    method:"POST",
                    data: formData,
                    contentType:false,
                    cache:false,
                    processData:false,
                    success:function(response)
                    {
                        var res = JSON.parse(response);
                        if(res['statusCode'] == 5)
                        {
                            success_noti(res['Message']);
                            $('#admin-form').trigger("reset");
                        }
                        else if(res['statusCode'] == 4)
                        {
                            warning_noti(res['Message']);
                        }
                        else if(res['statusCode'] == 3)
                        {
                            warning_noti(res['Message']);
                        }
                        else if(res['statusCode'] == 2)
                        {
                            warning_noti(res['Message']);
                        }
                        else if(res['statusCode'] == 1)
                        {
                            warning_noti(res['Message']);
                        }
                        else if(res['statusCode'] == 0)
                        {
                            error_noti(res['Message']);
                        }
                    }
                });
            }
        });
        function error_noti(message) 
        {
            Lobibox.notify('error', {
                pauseDelayOnHover: true,
                continueDelayOnInactiveTab: false,
                position: 'top right',
                icon: 'bx bx-x-circle',
                msg: message
            });
        }
        function warning_noti(message) 
        {
            Lobibox.notify('warning', {
                pauseDelayOnHover: true,
                continueDelayOnInactiveTab: false,
                position: 'top right',
                icon: 'bx bx-error',
                msg: message
            });
        }
        function success_noti(message) 
        {
            Lobibox.notify('success', {
                pauseDelayOnHover: true,
                continueDelayOnInactiveTab: false,
                position: 'top right',
                icon: 'bx bx-check-circle',
                msg: message
            });
        }

        $(document).find("title").text("Create Admin");
    }); 
</script>
