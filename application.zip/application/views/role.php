<!--start page wrapper -->
<div class="page-wrapper">
    <div class="page-content">
        <div class="row">
            <div class="col-xl-6">
                <h5 class="mb-0 text-uppercase">Roles & Permissions</h5>
                <hr/>
                <div class="card border-top border-0 border-4 border-white">
                    <div class="card-body p-5">
                        <div class="card-title d-flex align-items-center">
                            <h6 class="mb-0 text-white">Create New Role</h6>
                        </div>
                        <hr>
                        <form class="row g-3 role-form">
                            <div class="col-md-12">
                                <label for="role" class="form-label">Role Name</label>
                                <input type="text" class="form-control" id="role">
                            </div>
                            <div class="col-12">
                                <button type="submit" class="btn btn-light px-5" id="save-role">Save Role</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-xl-6">
                <h5 class="mb-0 text-uppercase mt-5"></h5>
                <hr/>
                <div class="card border-top border-0 border-4 border-white">
                    <div class="card-body p-5">
                        <div class="card-title d-flex align-items-center">
                            <h6 class="mb-0 text-white">Role List</h6>
                        </div>
                        <hr>
                        <form class="row g-3">
                            <div class="col-md-12">
                                <div class="table-responsive">
                                    <table class="table mb-0">
                                        <thead>
                                            <tr>
                                                <th>Sr.No</th>
                                                <th>Role</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $count=1; foreach($role_data as $data) { ?>
                                            <tr>
                                                <td><?php echo $count++; ?>.</td>
                                                <td><?php echo $data['role'] ?></td>
                                                <td>
                                                    <div class="d-flex order-actions">	
                                                        <a href="<?php echo base_url('administrator/assignrole') ?>?role_id=<?php echo $data['id'] ?>" class=""><i class="bx bx-show-alt"></i></a>
                                                        <!--<a href="javascript:;" class="ms-2"><i class="bx bxs-edit"></i></a>-->
                                                        <a href="javascript:;" class="ms-2 delete-role" data-id="<?php echo $data['id'] ?>" data-bs-toggle="modal" data-bs-target="#deleteRoleConfirmation" title="Delete Role"><i class="bx bxs-trash"></i></a>
                                                    </div>
                                                </td>
                                            </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--end page wrapper -->
<div class="modal fade" id="deleteRoleConfirmation" tabindex="-1" aria-labelledby="deleteRoleConfirmationLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteRoleConfirmationLabel">Confirmation</h5>
            </div>
            <div class="modal-body">
                Are you sure you want to Delete this Role ?
                <input type="hidden" id="delete-role-id">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" id="delete-role-btn" data-bs-dismiss="modal">Confirm</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Decline</button>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function () {
        $(document).find(".delete-role").click(function(e){
            e.preventDefault();
            var role_id = $(document).find(this).attr("data-id");
            $(document).find("#delete-role-id").val(role_id);
        });
        
        $(document).find("#delete-role-btn").click(function(e){
            e.preventDefault();
            var role_id = $(document).find("#delete-role-id").val();
            if(role_id=="")
            {
                warning_noti("Something is wrong! try again later");
            }
            else
            { 
                $.ajax({
                url: '<?php echo base_url('administrator/deleteRole') ?>',
                method: 'POST',
                data: {
                    role_id: role_id
                    },
                    success: function (response) 
                    {
                        var res = JSON.parse(response);
                        if(res['statusCode'] == 2)
                        {
                            success_noti(res['Message']);
                            window.location.reload();
                        }
                        else if(res['statusCode'] == 1)
                        {
                            warning_noti(res['Message']);
                        }
                        else if(res['statusCode'] == 0)
                        {
                            error_noti(res['Message']);
                        }
                    }
                });
            }
        });
        
        
        $('#save-role').on('click', function(event){
            event.preventDefault();
            var role = $(document).find("#role").val();
            if(role=="")
            {
                warning_noti("Role name is required!");
            }
            else
            {
                $.ajax({
                    url: '<?php echo base_url('administrator/createRoleAth') ?>',
                    method: 'POST',
                    data: {
                        role: role
                        },
                    success: function (response) 
                    {
                        var res = JSON.parse(response);
                        if(res['statusCode'] == 2)
                        {
                            success_noti(res['Message']);
                            $('.role-form').trigger("reset");
                            window.location.reload();
                        }
                        else if(res['statusCode'] == 1)
                        {
                            warning_noti(res['Message']);
                        }
                        else if(res['statusCode'] == 0)
                        {
                            error_noti(res['Message']);
                        }
                    }
                })
            }
        });
        function error_noti(message) 
        {
            Lobibox.notify('error', {
                pauseDelayOnHover: true,
                continueDelayOnInactiveTab: false,
                position: 'top right',
                icon: 'bx bx-x-circle',
                msg: message
            });
        }
        function warning_noti(message) 
        {
            Lobibox.notify('warning', {
                pauseDelayOnHover: true,
                continueDelayOnInactiveTab: false,
                position: 'top right',
                icon: 'bx bx-error',
                msg: message
            });
        }
        function success_noti(message) 
        {
            Lobibox.notify('success', {
                pauseDelayOnHover: true,
                continueDelayOnInactiveTab: false,
                position: 'top right',
                icon: 'bx bx-check-circle',
                msg: message
            });
        }

        $(document).find("title").text("OKT-Role");
    }); 
</script>