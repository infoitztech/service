<!--start page wrapper -->
<div class="page-wrapper">
    <div class="page-content">
        <h5 class="mb-0 text-uppercase">Retailer's Messages</h5>
        <hr/>
        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table id="userlog" class="table mb-0">
                        <thead>
                            <tr class="bg-light">
                                <th>Sr. No.</th>
                                <th>whatsapp</th>
                                <th>User ID</th>
                                <th>Message</th>
                                <th>Message ID</th>
                                
                                <th>contact no</th>
                                <th>admin ID</th>
                                
                                <th>name</th>
                               

                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $count=1;
                            foreach($message_data as $data) { ?>
                            <tr>
                                <td><?php echo $count++; ?>.</td>
                                <td><a href="https://api.whatsapp.com/send?phone=+91<?php echo $data['contact']; ?>&text=Hi <?php echo $data['name']; ?>(<?php echo $data['username']; ?>), we have received your message:- (<?php echo $data['message']; ?>) we are happy to help you Thanks supportdesk Service Plus"target="_blank">WhatsApp</a></td>
                               <td><?php echo $data['username']; ?></td>
                                <td>
    <a href="#" onclick="showMessage('<?php echo $data['message']; ?>')">View</a>
</td>

<script>
function showMessage(message) {
    alert(message); // replace with your own pop-up implementation
}
</script>
                                <td><?php echo $data['id']; ?></td>
                                
                                <td><?php echo $data['contact']; ?></td>
                                <td><?php echo $data['admin']; ?></td>
                                
                                <td><?php echo $data['name']; ?></td>
                               

                                
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<!--end page wrapper -->
<script>
    $(document).ready(function() {
        var table = $('#userlog').DataTable( {
            buttons: [ 'excel']
        } );
        
        table.buttons().container()
            .appendTo( '#userlog_wrapper .col-md-6:eq(0)' );

        $(document).find("title").text("Messages");
    } );
    
</script>