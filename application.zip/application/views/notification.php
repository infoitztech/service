<!--start page wrapper -->
<div class="page-wrapper">
    <div class="page-content">
        <div class="row">
            <div class="col-xl-6 mx-auto">
                <h5 class="mb-0 text-uppercase">Notification</h5>
                <hr/>
                <div class="card border-top border-0 border-4 border-white">
                    <div class="card-body p-5">
                        <div class="card-title d-flex align-items-center">
                            <h6 class="mb-0 text-white">Notification</h6>
                        </div>
                        <hr>
                        <form class="row g-3">
                            <div class="col-md-12">
                                <label for="oldpassword" class="form-label">Notification </label>
                                <textarea class="form-control" id="notification" name="notification" rows="5"><?php echo $notification_data['data'] ?></textarea>
                            </div>
                            <div class="col-12">
                                <button type="submit" class="btn btn-light px-5" id="save-changes">Save Changes</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--end page wrapper -->

<script>
    $(document).ready(function () {
        $('#save-changes').on('click', function(event){
            event.preventDefault();
            var notification = $(document).find("#notification").val();
            

            $.ajax({
                url: '<?php echo base_url('administrator/savenotification') ?>',
                method: 'POST',
                data: {
                    notification: notification
                    },
                success: function (response) 
                {
                    var res = JSON.parse(response);
                    if(res['statusCode'] == 3)
                    {
                        success_noti(res['Message']);
                        $('.password-form').trigger("reset");
                    }
                    else if(res['statusCode'] == 2)
                    {
                        warning_noti(res['Message']);
                    }
                    else if(res['statusCode'] == 1)
                    {
                        warning_noti(res['Message']);
                    }
                    else if(res['statusCode'] == 0)
                    {
                        error_noti(res['Message']);
                    }
                }
            })
            
        });
        function error_noti(message) 
        {
            Lobibox.notify('error', {
                pauseDelayOnHover: true,
                continueDelayOnInactiveTab: false,
                position: 'top right',
                icon: 'bx bx-x-circle',
                msg: message
            });
        }
        function warning_noti(message) 
        {
            Lobibox.notify('warning', {
                pauseDelayOnHover: true,
                continueDelayOnInactiveTab: false,
                position: 'top right',
                icon: 'bx bx-error',
                msg: message
            });
        }
        function success_noti(message) 
        {
            Lobibox.notify('success', {
                pauseDelayOnHover: true,
                continueDelayOnInactiveTab: false,
                position: 'top right',
                icon: 'bx bx-check-circle',
                msg: message
            });
        }

        $(document).find("title").text("Notification");
    }); 
</script>