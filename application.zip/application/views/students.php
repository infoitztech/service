<!--start page wrapper -->
<div class="page-wrapper">
    <div class="page-content">
        <h5 class="mb-0 text-uppercase">Member</h5>
        <hr/>
        <div class="card">
            <div class="card-body">
                <div class="d-lg-flex align-items-center mb-4 gap-3">
                    <div class="position-relative">
                        <h6>Member List</h6>
                    </div>
                </div>
                <div class="table-responsive">
                    <table id="studenttable" class="table mb-0">
                        <thead>
                            <tr class="bg-light">
                                <th>Sr.No</th>
                                <th>Ref. No.</th>
                                <th>Type</th>
                                <th>Name</th>
                                <th>Remark-1</th>
                                <th>Remark-2</th>
                                <th>Date</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $count=1; foreach($student_data as $data) {   ?>
                            <tr>
                                <td><?php echo $count++; ?></td>
                                <td><?php echo $data->vle_id; ?></td>
                                <td><?php echo $data->type; ?></td>
                                <td><?php echo $data->name ?></td>
                                <td><?php echo $data->remark1; ?></td>
                                <td><?php echo $data->remark2; ?></td>
                                <td><?php echo $data->created_at; ?></td>
                                <td>
                                    <div class="btn-group">
                                        <?php if($permission_details['student_finger'] == "1") { ?>
                                        <a href="<?php echo base_url('administrator/fingerprints') ?>?student=<?php echo $data->id; ?>" target="_blank" class="btn btn-light btn-sm " title="Student Finger Prints"><i class="bx bx-images"></i></a>
                                        <?php } ?>
                                        <?php if($permission_details['delete_student'] == "1") { ?>
                                        <button class="btn btn-light btn-sm delete-user" title="Delete Retailer" data-id="<?php echo $data->id; ?>" data-bs-toggle="modal" data-bs-target="#deleteUserConfirmation"><i class="bx bxs-trash"></i></button>
                                        <?php } ?>
                                    </div>
                                </td>
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<!--end page wrapper -->
<div class="modal fade" id="deleteUserConfirmation" tabindex="-1" aria-labelledby="deleteUserConfirmationLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteUserConfirmationLabel">Confirmation</h5>
            </div>
            <div class="modal-body">
                Are you sure you want to Delete this Student ?
                <input type="hidden" id="delete-user-id">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" id="delete-user-btn" data-bs-dismiss="modal">Confirm</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Decline</button>
            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function() {
        var table = $('#studenttable').DataTable( {
            buttons: [ 'excel']
        } );
        
        table.buttons().container()
            .appendTo( '#studenttable_wrapper .col-md-6:eq(0)' );

        $(document).find("title").text("Members List");
        
        $(document).find(".delete-user").click(function(e){
            e.preventDefault();
            var user_id = $(document).find(this).attr("data-id");
            $(document).find("#delete-user-id").val(user_id);
        });

        $(document).find("#delete-user-btn").click(function(e){
            e.preventDefault();
            var student_id = $(document).find("#delete-user-id").val();
            if(student_id=="")
            {
                alert("Something is wrong! Try again later");
            }
            else
            { 
                $.ajax({
                url: '<?php echo base_url('administrator/deleteStudent') ?>',
                method: 'POST',
                data: {
                    student_id: student_id
                    },
                    success: function (response) 
                    {
                        var res = JSON.parse(response);
                        if(res['statusCode'] == 2)
                        {
                            success_noti(res['Message']);
                            window.location.reload();
                        }
                        else if(res['statusCode'] == 1)
                        {
                            warning_noti(res['Message']);
                        }
                        else if(res['statusCode'] == 0)
                        {
                            error_noti(res['Message']);
                        }
                    }
                });
            }
        });

    });
    
        function error_noti(message) 
		{
			Lobibox.notify('error', {
				pauseDelayOnHover: true,
				continueDelayOnInactiveTab: false,
				position: 'top right',
				icon: 'bx bx-x-circle',
				msg: message
			});
		}
		function warning_noti(message) 
		{
			Lobibox.notify('warning', {
				pauseDelayOnHover: true,
				continueDelayOnInactiveTab: false,
				position: 'top right',
				icon: 'bx bx-error',
				msg: message
			});
		}
		function success_noti(message) 
		{
			Lobibox.notify('success', {
				pauseDelayOnHover: true,
				continueDelayOnInactiveTab: false,
				position: 'top right',
				icon: 'bx bx-check-circle',
				msg: message
			});
		}
</script>