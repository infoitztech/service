<!--start page wrapper -->
<div class="page-wrapper">
    <div class="page-content">
        <h5 class="mb-0 text-uppercase">Retailer</h5>
        <hr/>
        <div class="card">
            <div class="card-body">
                <div class="d-lg-flex align-items-center mb-4 gap-3">
                    <div class="position-relative">
                        <h6>Retailers List</h6>
                    </div>
                    <div class="ms-auto"><a href="<?php echo base_url('administrator/createuser') ?>" class="btn btn-light radius-30 mt-2 mt-lg-0"><i class="bx bxs-plus-square"></i>Create New Retailer</a></div>
                </div>
                
                <div class="table-responsive">
                    <table id="administrators" class="table mb-0">
                        <thead>
                            <tr class="bg-light">
                                <th>Sr.No</th>
                                <th>Profile</th>
                                <th>Name</th>
                                <th>Username</th>
                                <th>Admin</th>
                                <th>contact no</th>
                                <!--<th>password</th>-->
                                <th>Coins</th>
                                <th>Whatsapp</th>
                                <?php if($permission_details['retailer_status'] == "1") { ?>
                                <th>Status</th>
                                <?php } ?>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $count=1; foreach($user_data as $data) {  $profile = $data['profile']; ?>
                            <tr>
                                <td><?php echo $count++; ?></td>
                                <td><img src="<?php echo base_url('upload/user/profilephoto'); ?>/<?php echo ($profile !="") ? $profile: "profile.png"; ?>" alt class="user-img"></td>
                                <td><?php echo $data['name'] ?></td>
                                <td><?php echo $data['username'] ?></td>
                                <td><?php echo $data['admin_user'] ?></td>
                                <td><?php echo $data['contact'] ?></td>
                                <!--<td><?php echo $data['password'] ?></td>-->
                                <td><?php echo $data['coins'] ?></td>
                                <td>
                                    
                                    
  <div class="dropdown">
    <button class="btn btn-light btn-sm dropdown-toggle" type="button" id="quickMessageDropdown" data-bs-toggle="dropdown" aria-expanded="false">
      Quick Message
    </button>
    <ul class="dropdown-menu" aria-labelledby="quickMessageDropdown">
        
      <li><a class="dropdown-item" href="https://wa.me/+91<?php echo $data['contact']; ?>/?text=Hi%20<?php echo $data['name']; ?>(<?php echo $data['username']; ?>),%20we%20are%20happy%20to%20help%20you" target="_blank">We are happy to help you</a></li>
     <?php
// Generate the password
$password = substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 8);

// Use the password in the href attribute
echo '<li><a class="dropdown-item" href="https://wa.me/+91' . $data['contact']. '/?text=Hi%20' . $data['name'] . '(' . $data['username'] . '),Your password has been reset and new password is --' . $password . '.%20Do%20not%20share%20your%20password%20even%20he/she%20is%20service%20provider" target="_blank">password reset </a></li>';
?>
<?php
// Generate the password
$password = substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 8);

// Use the password in the href attribute
echo '<li><a class="dropdown-item" href="https://wa.me/+91' .$data['contact']. '/?text=Hi%20' . $data['name'] . '(' . $data['username'] . '),%20welcome%20to%20service%20plus%20your%20password%20is%20' . $password . '.%20Do%20not%20share%20your%20password%20even%20he/she%20is%20service%20provider" target="_blank">welcome to service plus </a></li>';
?>


    </ul>
  </div>
</td>

<!--                               
  <?php $whatsapp_number = $data['contact']; // Replace 'contact_number' with the actual column name in your database ?>
<!--  <a href="https://wa.me/<?php echo $whatsapp_number; ?>/?text=Hi%20<?php echo $data['name']; ?>(<?php echo $data['username']; ?>),%20we%20are%20happy%20to%20help%20you" class="btn btn-light btn-sm" target="_blank" title="Send WhatsApp Message"><i class="bx bxl-whatsapp"></i></a>-->
<!--</td>-->


                                <?php if($permission_details['retailer_status'] == "1") { ?>
                                <td>
                                    <?php if($data['status']==1) { ?>
                                        <button class="btn btn-success btn-sm profile-status" data-id="<?php echo $data['user_id']; ?>" status-id="1"  data-bs-toggle="modal" data-bs-target="#userStatusConfirmation">Active</button>
                                    <?php } else { ?>
                                        <button class="btn btn-warning btn-sm profile-status" data-id="<?php echo $data['user_id']; ?>" status-id="0" data-bs-toggle="modal" data-bs-target="#userStatusConfirmation">Inactive</button>
                                    <?php } ?>
                                </td>
                                <?php } ?>
                                <td>
                                    <div class="btn-group">
                                        <?php if($permission_details['students_list'] == "1") { ?>
                                        <a href="#" class="btn btn-light btn-sm change-password" title="Retailer" data-id="<?php echo $data['user_id']; ?>" data-bs-toggle="modal" data-bs-target="#UserPasswordConfirmation"><i class="bx bx-lock"></i></a>
                                         <button class="btn btn-light btn-sm retailer-details" title="Retailer Details" data-id="<?php echo $data['user_id']; ?>" data-bs-toggle="modal" data-bs-target="#viewaRetailerConfirmation"><i class="bx bx-detail"></i></button> 
                                        <a href="" class="btn btn-light btn-sm edit-retailer" title="Retailers" title="Edit Retailer" data-id="<?php echo $data['user_id']; ?>" data-bs-toggle="modal" data-bs-target="#editRetailerConfirmation"><i class="bx bxs-edit"></i></a>
                                         <?php } ?>
                                        <?php if($permission_details['delete_retailer'] == "1") { ?>
                                         <button class="btn btn-light btn-sm delete-user" title="Delete Retailers" data-id="<?php echo $data['user_id']; ?>" data-bs-toggle="modal" data-bs-target="#deleteUserConfirmation"><i class="bx bxs-trash"></i></button> 
                                          <?php } ?>
                                    </div>
                                </td>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<!--end page wrapper -->
<div class="modal fade" id="deleteUserConfirmation" tabindex="-1" aria-labelledby="deleteUserConfirmationLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteUserConfirmationLabel">Confirmation</h5>
            </div>
            <div class="modal-body">
                Are you sure you want to Delete this Retailer ?
                <input type="hidden" id="delete-user-id">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" id="delete-user-btn" data-bs-dismiss="modal">Confirm</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Decline</button>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="editRetailerConfirmation" tabindex="-1" aria-labelledby="editRetailerConfirmationLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editRetailerConfirmation">Edit Retailer Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-lg-12 col-sm-12">
                        <label>Name</label>
                        <div class="form-group">
                            <input type="text" id="edit-name" class="form-control">
                        </div>
                    </div>
                    <div class="col-lg-12 col-sm-12">
                        <label>Mobile Number</label>
                        <div class="form-group">
                            <input type="text" id="edit-contact" class="form-control">
                        </div>
                    </div>
                    <div class="col-lg-12 col-sm-12">
                        <label>Email</label>
                        <div class="form-group">
                            <input type="text" id="edit-email" class="form-control">
                        </div>
                    </div>
                    <div class="col-lg-12 col-sm-12">
                        <label>Activation Key</label>
                        <div class="form-group">
                            <input type="text" id="edit-key" class="form-control">
                        </div>
                    </div>
                    <input type="hidden" id="edit-user-id">
                    <div class="col-lg-4 col-sm-4 mx-auto mt-3">
                        <button class="btn btn-primary" id="update-user">Update</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="viewaRetailerConfirmation" tabindex="-1" aria-labelledby="viewaRetailerConfirmationLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="viewaRetailerConfirmation">Retailer Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-lg-12 col-sm-12">
                        <div class="d-flex flex-column align-items-center text-center">
                            <img src="" class="rounded-circle p-1 bg-primary retailer-image" style="height: 110px">
                        </div>
                    </div>
                    <div class="col-lg-12 col-sm-12">
                        <div class="text-center">
                            <p class="mb-0 mt-4">Name : <span class="name"></span></p>
                        </div>
                    </div>
                    <div class="col-lg-12 col-sm-12">
                        <div class="text-center">
                            <p class="mb-0">Contact : <span class="contact"></span></p>
                        </div>
                    </div>
                    <div class="col-lg-12 col-sm-12">
                        <div class="text-center">
                            <p class="mb-0">Email : <span class="email"></span></p>
                        </div>
                    </div>
                    <div class="col-lg-12 col-sm-12">
                        <div class="text-center">
                            <p>Username : <span class="username"></span></p>
                        </div>
                    </div>
                    <div class="col-lg-12 col-sm-12">
                        <div class="text-center">
                            <p>Admin : <span class="admin"></span></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="userStatusConfirmation" tabindex="-1" aria-labelledby="userStatusConfirmationLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="userStatusConfirmationLabel">Confirmation</h5>
            </div>
            <div class="modal-body">
                Are you sure you want to <span id="status"></span> this User ?
                <input type="hidden" id="user-id">
                <input type="hidden" id="status-id">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" id="change-status-btn" data-bs-dismiss="modal">Confirm</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Decline</button>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="viewStatusConfirmation" tabindex="-1" aria-labelledby="viewStatusConfirmationLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="viewStatusConfirmationLabel">Confirmation</h5>
            </div>
            <div class="modal-body">
                Are you sure you want to <span id="v-status"></span> this User ?
                <input type="hidden" id="v-user-id">
                <input type="hidden" id="v-status-id">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" id="change-v-status-btn" data-bs-dismiss="modal">Confirm</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Decline</button>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="UserPasswordConfirmation" tabindex="-1" aria-labelledby="UserPasswordConfirmationLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="UserPasswordConfirmationLabel">Change Password</h5>
            </div>
            <div class="modal-body">
               <div class="row">
                   <div class="col-lg-12">
                       <label>New Password</label>
                       <div class="form-group">
                           <input type="text" id="new-password" class="form-control">
                       </div>
                   </div>
                   <div class="col-lg-12">
                       <label>Confirm Password</label>
                       <div class="form-group">
                           <input type="text" id="confirm-password" class="form-control">
                       </div>
                   </div>
               </div>
            </div>
            <input type="hidden" id="password-user-id">
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" id="change-password-btn" data-bs-dismiss="modal">Save</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Decline</button>
            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function() {
        var table = $('#administrators').DataTable( {
            buttons: [ 'excel']
        } );
        
        table.buttons().container()
            .appendTo( '#administrators_wrapper .col-md-6:eq(0)' );

        $(document).find("title").text("Retailers");

        $("#administrators").on("click", ".delete-user", function(e){
            e.preventDefault();
            var user_id = $(document).find(this).attr("data-id");
            $(document).find("#delete-user-id").val(user_id);
        });
        
        $("#administrators").on("click", ".change-password", function(e){
            e.preventDefault();
            var user_id = $(document).find(this).attr("data-id");
            $(document).find("#password-user-id").val(user_id);
        });

        $(document).find("#change-password-btn").on("click", function(e){
            e.preventDefault();
            var new_password = $(document).find("#new-password").val();
            var confirm_password = $(document).find("#confirm-password").val();
            var user_id = $(document).find("#password-user-id").val();
            if(new_password=="")
            {
                warning_noti("New password is required!");
            }
            else if(confirm_password == "")
            {
                 warning_noti("Confirm password is required!");
            }
            else if(confirm_password != new_password)
            {
                 warning_noti("New Password & Confirm password must be same!");
            }
            else if(user_id == "")
            {
                warning_noti("Something is wrong! Try again later");
            }
            else
            { 
                $.ajax({
                url: '<?php echo base_url('administrator/retailerchangepassword') ?>',
                method: 'POST',
                data: {
                    new_password: new_password,
                    user_id : user_id  
                    },
                    success: function (response) 
                    {
                        if(response == "1")
                       {
                           success_noti("Password changed!");
                       }
                       else
                       {
                           warning_noti("Failed to change password!");
                       }
                    }
                });
            }
        });
        
        $(document).find("#delete-user-btn").on("click", function(e){
            e.preventDefault();
            var user_id = $(document).find("#delete-user-id").val();
            if(user_id=="")
            {
                alert("Something is wrong! Try again later");
            }
            else
            { 
                $.ajax({
                url: '<?php echo base_url('administrator/deleteUser') ?>',
                method: 'POST',
                data: {
                    user_id: user_id
                    },
                    success: function (response) 
                    {
                        var res = JSON.parse(response);
                        if(res['statusCode'] == 2)
                        {
                            success_noti(res['Message']);
                            window.location.reload();
                        }
                        else if(res['statusCode'] == 1)
                        {
                            warning_noti(res['Message']);
                        }
                        else if(res['statusCode'] == 0)
                        {
                            error_noti(res['Message']);
                        }
                    }
                });
            }
        });

        $("#administrators").on("click", ".retailer-details", function(e){
            e.preventDefault();
            var id = $(document).find(this).attr("data-id");
            if(id=="")
            {
                alert("Something is wrong! Try again later");
            }
            else
            { 
            $.ajax({
                url : '<?php echo base_url('administrator/userDetailes') ?>',
                method: 'POST',
                data: {
                    id: id
                    },
                    success: function (response) 
                    {
                        var res = JSON.parse(response);
                        if(res['0']['profile'])
                        {
                            $(document).find(".retailer-image").attr('src',"<?php echo base_url('upload/user/profilephoto/'); ?>"+res['0']['profile']);
                        }
                        else
                        {
                            $(document).find(".retailer-image").attr('src',"<?php echo base_url('upload/user/profilephoto/profile.png'); ?>");
                        }
                        $(document).find(".name").text(res['0']['name']);
                        $(document).find(".contact").text(res['0']['contact']);
                        $(document).find(".email").text(res['0']['email']);
                        $(document).find(".username").text(res['0']['username']);
                        $(document).find(".admin").text(res['1']);
                    }
                });
            }
        });
        
        $("#administrators").on("click", ".edit-retailer", function(e){
        //$(document).find(".edit-retailer").on("click", function(e){
            e.preventDefault();
            var id = $(document).find(this).attr("data-id");
            if(id=="")
            {
                alert("Something is wrong! Try again later");
            }
            else
            { 
            $.ajax({
                url : '<?php echo base_url('administrator/userDetailes') ?>',
                method: 'POST',
                data: {
                    id: id
                    },
                    success: function (response) 
                    {
                        var res = JSON.parse(response);
                        $(document).find("#edit-name").val(res['0']['name']);
                        $(document).find("#edit-contact").val(res['0']['contact']);
                        $(document).find("#edit-email").val(res['0']['email']);
                        $(document).find("#edit-key").val(res['0']['activation_key']);
                       $(document).find("#edit-user-id").val(res['0']['user_id']);
                    }
                });
            }
        });
        
        $(document).find("#update-user").on("click", function(e){
            e.preventDefault();
            var name = $(document).find("#edit-name").val();
            var contact = $(document).find("#edit-contact").val();
            var email = $(document).find("#edit-email").val();
            var user_id = $(document).find("#edit-user-id").val();
            var edit_key = $(document).find("#edit-key").val();
            if(name=="")
            {
                warning_noti("Name is required!");
            }
            else if(user_id == "")
            {
                warning_noti("Something is wrong! Try again later");
            }
            else
            { 
                $.ajax({
                    url : '<?php echo base_url('administrator/updateuser') ?>',
                    method: 'POST',
                    data: {
                        name: name,
                        contact: contact,
                        email: email,
                        user_id: user_id,
                        edit_key : edit_key
                    },
                    success: function (response) 
                    {
                       if(response == "1")
                       {
                           success_noti("Retailer Updated!");
                           window.location.reload();
                       }
                       else
                       {
                           warning_noti("Failed to update retailer!");
                       }
                    }
                });
            }
        });
        
        $("#administrators").on("click",".profile-status",function(event){
        //$(document).find(".profile-status").on("click", function(e){
            e.preventDefault();
            var user_id = $(document).find(this).attr("data-id");
            alert(user_id);
            var status = $(document).find(this).attr("status-id");
            var new_status ="";
            if(status == "1")
            {
                new_status ="Deactivate";
                status= "0";
            }
            else if(status == "0")
            {
                new_status ="Activate";
                status= "1";
            }
            $(document).find("#user-id").val(user_id);
            $(document).find("#status").text(new_status);
            $(document).find("#status-id").val(status);
        });
        
        $(document).on("click", ".profile-status", function(e){
    e.preventDefault();
    var username = $(this).data('username');
    var status_id = $(this).data('status-id');
    $("#username").val(username);
    $("#status-id").val(status_id);
    $("#userStatusConfirmation").modal('show');
});

$(document).find("#change-status-btn").on("click", function(e){
    e.preventDefault();
    var username = $(document).find("#username").val();
    var status_id = $(document).find("#status-id").val();
    if(username=="" || status_id == "")
    {
        alert("Something is wrong! Try again later");
    }
    else
    { 
        $.ajax({
            url: '<?php echo base_url('administrator/changeUserStatus') ?>',
            method: 'POST',
            data: {
                username: username,
                status_id : status_id
            },
            success: function (response) 
            {
                var res = JSON.parse(response);
                if(res['statusCode'] == 2)
                {
                    success_noti(res['Message']);
                    window.location.reload();
                }
                else if(res['statusCode'] == 1)
                {
                    warning_noti(res['Message']);
                }
                else if(res['statusCode'] == 0)
                {
                    error_noti(res['Message']);
                }
            }
        });
    }
});

        // $(document).find("#change-status-btn").on("click", function(e){
        //     e.preventDefault();
        //     var username = $(document).find("#username").val();
        //     var status_id = $(document).find("#status-id").val();
        //     if(username=="" && status_id == "")
        //     {
        //         alert("Something is wrong! Try again later");
        //     }
        //     else
        //     { 
        //         $.ajax({
        //         url: '<?php echo base_url('administrator/changeUserStatus') ?>',
        //         method: 'POST',
        //         data: {
        //             username: username,
        //             status_id : status_id
        //             },
        //             success: function (response) 
        //             {
        //                 var res = JSON.parse(response);
        //                 if(res['statusCode'] == 2)
        //                 {
        //                     success_noti(res['Message']);
        //                     window.location.reload();
        //                 }
        //                 else if(res['statusCode'] == 1)
        //                 {
        //                     warning_noti(res['Message']);
        //                 }
        //                 else if(res['statusCode'] == 0)
        //                 {
        //                     error_noti(res['Message']);
        //                 }
        //             }
        //         });
        //     }
        // });
        
        $(document).find(".view-status").on("click", function(e){
            e.preventDefault();
            var user_id = $(document).find(this).attr("data-id");
            var status = $(document).find(this).attr("status-id");
            var new_status ="";
            if(status == "1")
            {
                new_status ="Deactivate";
                status= "0";
            }
            else if(status == "0")
            {
                new_status ="Activate";
                status= "1";
            }
            $(document).find("#v-user-id").val(user_id);
            $(document).find("#v-status").text(new_status);
            $(document).find("#v-status-id").val(status);
        });
        
        $(document).find("#change-v-status-btn").on("click", function(e){
            e.preventDefault();
            var user_id = $(document).find("#v-user-id").val();
            var status_id = $(document).find("#v-status-id").val();
            if(user_id=="" && status_id == "")
            {
                alert("Something is wrong! Try again later");
            }
            else
            { 
                $.ajax({
                url: '<?php echo base_url('administrator/changeViewStatus') ?>',
                method: 'POST',
                data: {
                    user_id: user_id,
                    status_id : status_id
                    },
                    success: function (response) 
                    {
                        var res = JSON.parse(response);
                        if(res['statusCode'] == 2)
                        {
                            success_noti(res['Message']);
                            window.location.reload();
                        }
                        else if(res['statusCode'] == 1)
                        {
                            warning_noti(res['Message']);
                        }
                        else if(res['statusCode'] == 0)
                        {
                            error_noti(res['Message']);
                        }
                    }
                });
            }
        });

    });

    function error_noti(message) 
    {
        Lobibox.notify('error', {
            pauseDelayOnHover: true,
            continueDelayOnInactiveTab: false,
            position: 'top right',
            icon: 'bx bx-x-circle',
            msg: message
        });
    }
    function warning_noti(message) 
    {
        Lobibox.notify('warning', {
            pauseDelayOnHover: true,
            continueDelayOnInactiveTab: false,
            position: 'top right',
            icon: 'bx bx-error',
            msg: message
        });
    }
    function success_noti(message) 
    {
        Lobibox.notify('success', {
            pauseDelayOnHover: true,
            continueDelayOnInactiveTab: false,
            position: 'top right',
            icon: 'bx bx-check-circle',
            msg: message
        });
    }
    $password = substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 8);

</script>