<?php header('Access-Control-Allow-Origin: *'); ?>
<?php 

    require(APPPATH.'/libraries/REST_Controller.php');

    class RetailerApi extends REST_Controller
    {

        function __construct()
        {
            parent::__construct();
        }

        public function retailerlogin_post()
        {
            $username = $this->post('username');
            $password = $this->post('password');
            if($username != NULL && !empty($username) && $password != NULL && !empty($password))
            {
                $userData = $this->RetailerApi_model->retailerLogin($username, $password);
                $data = $userData['user_id'];
                if($userData)
                {
                    $this->RetailerApi_model->retailerLoginLog($data);
                    $this->response(array(
                        "status" => 1,
                        "data" =>$data
                    ), REST_Controller::HTTP_OK );
                }
                else if($userData)
                {
                    $this->response(array(
                        "status" => 0,
                    ), REST_Controller::HTTP_OK );
                }
            }
            else
            {
                $this->response(array(
                    "status" => 0,
                    "message" => "Somthing is wrong! Try again later",
                    "data" =>[]
                ), REST_Controller::HTTP_NOT_FOUND );
            }
        }
        
        public function retailersignin_post()
        {
            $username = $this->post('username');
            $password = $this->post('password');
            if($username != NULL && !empty($username) && $password != NULL && !empty($password))
            {
                $userData = $this->RetailerApi_model->retailerLogin($username, $password);
                if($userData)
                {
                    $this->RetailerApi_model->retailerLoginLog($userData['user_id']);
                    $this->response(array(
                        "status" => 1,
                        "data" =>$userData
                    ), REST_Controller::HTTP_OK );
                }
                else if($userData)
                {
                    $this->response(array(
                        "status" => 0,
                    ), REST_Controller::HTTP_OK );
                }
            }
            else
            {
                $this->response(array(
                    "status" => 0,
                    "message" => "Somthing is wrong! Try again later",
                    "data" =>[]
                ), REST_Controller::HTTP_NOT_FOUND );
            }
        }

        public function createstudent_post()
        {
            $retailer_id  = $this->post('retailer_id');
            $retailer_details =  $this->RetailerApi_model->getRetailerDetails($retailer_id);
            $admin_id = $retailer_details['admin'];
            
            $vle_id = $this->input->post('vle_id');
            $name = $this->input->post('name');
            $contact = $this->input->post('contact');
            $dob = $this->input->post('dob');
            $purpose = $this->input->post('purpose');
            $adhaar_no = $this->input->post('adhaar_no');
            $type = $this->input->post('type');
            $remark1 = $this->input->post('remark1');
            
            $student = $this->RetailerApi_model->checkrefexist($vle_id);
            if(!$student)
            {
				if($this->input->post("photo1"))
                {
                    $filename1 = $this->insertfingerprintfn($this->input->post("photo1"));
                }
                else
                {
                    $filename1 = "";
                }

                if($this->input->post("photo2"))
                {
                    $filename2 = $this->insertfingerprintfn($this->input->post("photo2"));
                }
                else
                {
                    $filename2 = "";
                }

                if($this->input->post("photo3"))
                {
                    $filename3 = $this->insertfingerprintfn($this->input->post("photo3"));
                }
                else
                {
                    $filename3 = "";
                }

                if($this->input->post("photo4"))
                {
                    $filename4 = $this->insertfingerprintfn($this->input->post("photo4"));
                }
                else
                {
                    $filename4 = "";
                }
                
                if($this->input->post("photo5"))
                {
                    $filename5 = $this->insertfingerprintfn($this->input->post("photo5"));
                }
                else
                {
                    $filename5 = "";
                }
                $studentadded = $this->RetailerApi_model->addstudent($retailer_id, $vle_id, $name, $contact, $dob, $purpose, $adhaar_no, $type, $remark1, $filename1, $filename2, $filename3, $filename4, $filename5, $admin_id);
                if($studentadded)
                {
                    $this->RetailerApi_model->studentcreatedLog($retailer_id, $name);
                    $this->response(array(
                        "status" => 1,
                    ), REST_Controller::HTTP_OK );
                }
                else
                {
                    $this->response(array(
                        "status" => 3,
                    ), REST_Controller::HTTP_OK );
                }
            }
            else
            {
                $this->response(array(
                        "status" => 3,
                    ), REST_Controller::HTTP_OK );
            }
        }
        
        public function insertfingerprint_post()
        {
            $retailer_id  = $this->post('retailer_id');
            $vle_id = $this->input->post('vle_id');
            $fingerprint = $this->input->post("finger_prints");
            if($fingerprint)
            {
               
               $screen_shot_name = rand(10000000,99999999);
                $image = base64_decode($fingerprint);
                $filename = $screen_shot_name.'.'.'png';
                $path = "upload/student/fingerprint/";
                file_put_contents($path . $filename, $image);
                
                //$filename = $this->insertfingerprintfn($fingerprint);
                // $filename1 = $this->input->post("finger_prints");
                $savefinger =  $this->RetailerApi_model->savefingers($retailer_id, $vle_id, "upload/student/fingerprint/".$filename);
                if($savefinger)
                {
                    $savefinger =  $this->RetailerApi_model->getsavedfingers($vle_id, $retailer_id);
                    $this->response(array(
                        "status" => 1,
                        "message" =>"Finger saved successfully",
                    //   "data"=>$savefinger
                    ), REST_Controller::HTTP_OK );
                }
                else
                {
                    $this->response(array(
                        "status" => 2,
                        "message" =>"Unable to save finger",
                        "data"=>""
                    ), REST_Controller::HTTP_OK );
                }
            }
            else
            {
                $this->response(array(
                        "status" => 2,
                        "message" =>"Unable to save finger",
                        "data"=>""
                    ), REST_Controller::HTTP_OK );
            }
        }
        
        
        public function createstudents_post()
        {
            $retailer_id  = $this->post('retailer_id');
            $retailer_details =  $this->RetailerApi_model->getRetailerDetails($retailer_id);
            $admin_id = $retailer_details['admin'];
            $vle_id = $this->input->post('vle_id');
            $name = $this->input->post('name');
            $contact = $this->input->post('contact');
            $dob = $this->input->post('dob');
            $purpose = $this->input->post('purpose');
            $adhaar_no = $this->input->post('adhaar_no');
            $type = $this->input->post('type');
            $remark1 = $this->input->post('remark1');
            
            $student = $this->RetailerApi_model->checkrefexist($vle_id);
            if(!$student)
            {
                $fingerslist = $this->RetailerApi_model->addedfingerslist($vle_id, $retailer_id);
                $filename1 = "";
                if(isset($fingerslist['0']['finger_print']))
                {
                    $filename1 = $fingerslist['0']['finger_print'];
                }
                $filename2 = "";
                if(isset($fingerslist['1']['finger_print']))
                {
                    $filename2 = $fingerslist['1']['finger_print'];
                }
                $filename3 = "";
                if(isset($fingerslist['2']['finger_print']))
                {
                    $filename3 = $fingerslist['2']['finger_print'];
                }
                $filename4 = "";
                if(isset($fingerslist['3']['finger_print']))
                {
                    $filename4 = $fingerslist['3']['finger_print'];
                }
                $filename5 = "";
                if(isset($fingerslist['4']['finger_print']))
                {
                    $filename5 = $fingerslist['4']['finger_print'];
                }
                $studentadded = $this->RetailerApi_model->addstudent($retailer_id, $vle_id, $name, $contact, $dob, $purpose, $adhaar_no, $type, $remark1, $filename1, $filename2, $filename3, $filename4, $filename5, $admin_id);
                if($studentadded)
                {
                    $this->RetailerApi_model->studentcreatedLog($retailer_id, $name);
                    $this->response(array(
                        "status" => 1,
                    ), REST_Controller::HTTP_OK );
                } 
                else
                {
                    $this->response(array(
                        "status" => 3,
                    ), REST_Controller::HTTP_OK );
                }
            }
            else
            {
                $this->response(array(
                        "status" => 3,
                    ), REST_Controller::HTTP_OK );
            }
        }

        public function insertfingerprintfn($image)
        {
            define('UPLOAD_DIR', 'upload/student/fingerprint/');
            $image_parts = explode(";base64,", $image);
            $image_type_aux = explode("image/", $image_parts[0]);
            $image_type = $image_type_aux[1];
            $image_base64 = base64_decode($image_parts[1]);
            $file = UPLOAD_DIR . uniqid() . '.png';
            file_put_contents($file, $image_base64);
            return $file;
        }

        public function getMemberRecord_get()
        {
            $retailer_id  = $this->get('retailer_id');
            $memberdata = $this->RetailerApi_model->getMemberRecord($retailer_id);
            $this->response(array(
                "status" => 1,
                "data" => $memberdata
            ), REST_Controller::HTTP_OK );
        }
        
        public function getMemberRecords_post()
        {
            $retailer_id  = $this->post('retailer_id');
            $memberdata = $this->RetailerApi_model->getMemberRecord($retailer_id);
            $this->response(array(
                "status" => 1,
                "data" => $memberdata
            ), REST_Controller::HTTP_OK );
        }
        
        public function getnotification_get()
        {
           $notificationdata = $this->RetailerApi_model->getnotification();
            $this->response(array(
                "status" => 1,
                "data" => $notificationdata
            ), REST_Controller::HTTP_OK );
        }
        
        public function getCoins_get()
        {
            $retailer_id  = $this->get('retailer_id');
            $totalcoins = $this->RetailerApi_model->getavailablecoins($retailer_id);
            $this->response(array(
                "status" => 1,
                "data" => $totalcoins
            ), REST_Controller::HTTP_OK );
        }
        
        public function sendmessage_post()
        {
            $message = $this->post('message');
            $retailer = $this->post('retailer');
            $messageadded = $this->RetailerApi_model->sendmessage($message, $retailer);
            if($messageadded)
            {
                $this->response(array(
                        "status" => 1,
                    ), REST_Controller::HTTP_OK );
            }
            else
            {
                $this->response(array(
                        "status" => 0,
                    ), REST_Controller::HTTP_OK );
            }
        }
        
        
        // ========================================================Employee API
        
        public function employeesignin_post()
        {
            $username = $this->post('username');
            $password = $this->post('password');
            if($username != NULL && !empty($username) && $password != NULL && !empty($password))
            {
                $userData = $this->Retailer_model->logineAuthentication($username, $password);
               // echo "<pre>"; print_r($userData); die();
                if($userData)
                {
                    $this->Retailer_model->retailerLoginLog($userData['id']);
                    $this->response(array(
                        "status" => 1,
                        "data" =>$userData
                    ), REST_Controller::HTTP_OK );
                }
                else
                {
                    $this->response(array(
                        "status" => 0,
                    ), REST_Controller::HTTP_OK );
                }
            }
            else
            {
                $this->response(array(
                    "status" => 0,
                    "message" => "Somthing is wrong! Try again later",
                    "data" =>[]
                ), REST_Controller::HTTP_NOT_FOUND );
            }
        }
        public function searchath_post()
        {
            $vle_id  = $this->post('vle_id');
            $memeberdata = $this->Retailer_model->searchath($vle_id);
            // echo "<pre>"; echo print_r($memeberdata); die();
            if($memeberdata)
            {
                $this->response(array(
                    "status" => 1,
                    "data" =>$memeberdata
                ), REST_Controller::HTTP_OK );
            }
            else
            {
                $this->response(array(
                    "status" => 0,
                ), REST_Controller::HTTP_OK );
            }
        }

        public function updateremark_post()
        {
            $member_id = $this->post('member_id');
            $remark2 = $this->post('remark2');
            $status = $this->post('status');   
            
            $employee = $this->post('employee');
            $updated = $this->Retailer_model->updateremark($remark2, $member_id, $status, $employee);
            if($updated)
            {
                $this->response(array(
                    "status" => 1,
                ), REST_Controller::HTTP_OK );
            }
            else
            {
                $this->response(array(
                    "status" => 0,
                ), REST_Controller::HTTP_OK );
            }
        }

        public function keyverification_post()
        {
            $key = $this->post('key');
            $username = $this->post('username');
            $verified = $this->Retailer_model->keyverification($key, $username);
            if($verified)
            {
                $this->response(array(
                    "status" => "Success",
                    "message" => "Activation key verified successfully!"
                ), REST_Controller::HTTP_OK );
            }
            else
            {
                $this->response(array(
                    "status" => "Failed",
                    "message" => "Unable to activate this app!"
                ), REST_Controller::HTTP_OK );
            }
        }

        public function employeekeyverification_post()
        {
            $key = $this->post('key');
            $username = $this->post('username');
            $verified = $this->Retailer_model->employeekeyverification($key, $username);
            if($verified)
            {
                $this->response(array(
                    "status" => "Success",
                    "message" => "Activation key verified successfully!"
                ), REST_Controller::HTTP_OK );
            }
            else
            {
                $this->response(array(
                    "status" => "Failed",
                    "message" => "Unable to activate this app!"
                ), REST_Controller::HTTP_OK );
            }
        }
        
        public function profile_post()
        {
            $user_id = $this->post('user_id');
            $userData = $this->RetailerApi_model->profile($user_id);
            if($userData)
            {
                $this->response(array(
                    "status" => 1,
                    "data" =>$userData
                ), REST_Controller::HTTP_OK );
            }
            else if($userData)
            {
                $this->response(array(
                    "status" => 0,
                ), REST_Controller::HTTP_OK );
            }
        }
        
        public function updateremarks_post()
        {
            $member_id = $this->post('member_id');
            $remark2 = $this->post('remark2');
            $employee_id = $this->post('employee');
            $status = $this->post('status');
            // if($member_id != NULL && !empty($member_id) && $employee_id != NULL && !empty($employee_id))
            // {
                $userData = $this->RetailerApi_model->updateremarks($member_id, $remark2, $employee_id, $status);
                if($userData)
                {
                    $this->response(array(
                        "status" => 1
                    ), REST_Controller::HTTP_OK );
                }
                else
                {
                    $this->response(array(
                        "status" => 0,
                    ), REST_Controller::HTTP_OK );
                }
            // }
            // else
            // {
            //     $this->response(array(
            //         "status" => 0,
            //         "message" => "Somthing is wrong! Try again later",
            //         "data" =>[]
            //     ), REST_Controller::HTTP_NOT_FOUND );
            // }   
        }
        
        public function searchath1_post()
        {
            $vle_id = $this->post('vle_id');
            $userData = $this->RetailerApi_model->searchath($vle_id);
            if($userData)
            {
                $this->response(array(
                    "status" => 1,
                    "data" =>$userData
                ), REST_Controller::HTTP_OK );
            }
            else if($userData)
            {
                $this->response(array(
                    "status" => 0,
                ), REST_Controller::HTTP_OK );
            }
        }
    }
?>