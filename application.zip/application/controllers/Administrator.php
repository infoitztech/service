<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Administrator extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an- underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct()
    {
        parent::__construct();
		$this->load->model('administrator_model');
    }

	public function is_logged_in()
    {
        $user = $this->session->userdata('administrator_log');
        return isset($user);
    }

	public function index()
	{
		$this->load->view('login');
	}

	public function forgetpassword()
	{
		$this->load->view('forgetpassword');
	}
	public function forgetotp()
	{
		$this->load->view('forgetotp');
	}
	public function newpassword()
	{
		$email = $this->session->userdata('administrator_email');
		$msg = $this->session->flashdata('msg');
    	if($email && $msg)
    	{
    		$this->load->view('newpassword');
    	}	
	}

	public function logout()
	{
		$this->session->sess_destroy();
		redirect('/administrator');
	}

	public function profile()
	{
		if ($this->is_logged_in())
		{
			$username = $this->session->userdata('administrator_log');
			$administrator_data = $this->administrator_model->administrator($username);
			$data['administrator_data'] = $administrator_data['0'];
			$role_id = $administrator_data['0']['role_id'];
            $data['permission_details'] = $this->administrator_model->checkroleexist($role_id);
			$this->load->view('header', $data);
			$this->load->view('profile', $data);
			$this->load->view('footer');
		}
		else
		{
			redirect('/');
		}
	}

	public function loginAuthentication()
    {
        if($this->input->post('username') != NULL && !empty($this->input->post('username')) 
        && $this->input->post('password') != NULL  && !empty($this->input->post('password'))
        )
        {
            $username = $this->input->post('username');
            $password = $this->input->post('password');
            $loginAuthenticationData = $this->administrator_model->loginAuthentication($username, $password);
            if($loginAuthenticationData != NULL && !empty($loginAuthenticationData))
            {
                if($loginAuthenticationData['status'] != NULL && !empty($loginAuthenticationData['status']) && $loginAuthenticationData['status'] == 1)
                {
                    $this->session->set_userdata('administrator_log', $loginAuthenticationData['username']);
                    $this->administrator_model->administratorLoginLog($loginAuthenticationData['user_id']);
                    echo json_encode(
                        array("statusCode"=>1, 
                        "Message"=>"Correct Username & Password. Now you are proceeding to the Dashboard!"
                        ));
                    die();
                }
                else
                {
                    echo json_encode(
                        array("statusCode"=>2, 
                        "Message"=>"Your profile has been Blocked!"
                        ));
                    die();
                }
            }
            else
            {
                echo json_encode(
                    array("statusCode"=>3, 
                    "Message"=>"Incorrect Username & Password!"
                    ));
                die();
            }
        }
        else
        {
            echo json_encode(
                array("statusCode"=>0, 
                "Message"=>"Something is wrong!, Try again later"
                ));
            die();
        }
    }

    public function resetpassath()
    {
        if($this->input->post('email') != NULL && !empty($this->input->post('email')) )
        {
        	$email = $this->input->post('email');
            $administrator_data = $this->administrator_model->getadministratorbyemail($email);
            if($administrator_data)
            {
            	//echo "<pre>"; print_r($administrator_data); die();
                $otp = rand(100000,999999); // 6 digits ka otp
            	$email = $administrator_data['email'];
            	$otpupdated = $this->administrator_model->otpupdated($email, $otp);
            	$subject = "Welcome to VLE Adda! Your Reset OTP is inside";
            	$from_email = "noreply@vleadda.in";  
        		$this->load->library('email'); 
        		$this->email->from($from_email, "VLE Adda"); 
        		$this->email->to($email);
        		$this->email->subject($subject); 
        		$this->email->message("Dear Administrator welcome to VLE Adda. You have applied for reset password. To reset your password please enter the given OTP . Your rest OTP-".$otp." ");
        		$this->email->send();
            	$this->session->set_userdata('administrator_email', $email);
            	echo json_encode(
                        array("statusCode"=>1, 
                        "Message"=>"To complete your recovering process please verify your email!"
                        ));
                    die();
			}
            else
            {
            	echo json_encode(
                        array("statusCode"=>2, 
                        "Message"=>"Email Does Not Exist!"
                        ));
                    die();

            }
            
        }
        else
        {
            echo json_encode(
                array("statusCode"=>0, 
                "Message"=>"Something is wrong!, Try again later"
                ));
            die();
        }
    }
    public function forgetotpath()
    {
    	if($this->input->post('otp') != NULL && !empty($this->input->post('otp')))
    	
    	{
    		$username = $this->session->userdata('administrator_email');
    		if($username)
    		{
    			$administrator_data = $this->administrator_model->administrator($username);
				$email = $administrator_data['0']['email'];
            
    			
    			$otp = $this->input->post('otp');
    			$otpexistance = $this->administrator_model->otpexistance($email, $otp);
    			if($otpexistance)
    			{
    				$this->session->set_flashdata('msg', 'yes');
    				echo json_encode(
                    array("statusCode"=>1, 
                    "Message"=>"Email Verified Successfully!"
                    ));
                	die();
    			}
    			else
    			{
    				echo json_encode(
                	array("statusCode"=>2, 
                	"Message"=>"You have Entered Wrong OTP!"
                    ));
                	die();
    			}
			}
    		else
    		{
    			echo json_encode(
                	array("statusCode"=>3, 
                	"Message"=>"Something Went Wrong!"
                    ));
                	die();
    		}
    	}
    	else
    	{
    		echo json_encode(
            array("statusCode"=>0, 
            "Message"=>"Something Went Wrong!"
               ));
            die();
    	}        
   	}	

   	public function newpasswordath()
   	{
   		if($this->input->post('password') != NULL && !empty($this->input->post('password')))
    	{
    		$email = $this->session->userdata('administrator_email');
    		if($username)
    		{
            	$password = $this->input->post('password');
    			$updatenewpassword = $this->administrator_model->updatenewpassword($email, $password);
    			if($updatenewpassword)
    			{
    				$this->session->sess_destroy();
    				echo json_encode(
                    array("statusCode"=>1, 
                    "Message"=>"New Password Changed Successfully!"
                    ));
                	die();
    			}
    			else
    			{
    				echo json_encode(
                	array("statusCode"=>2, 
                	"Message"=>"New Password Not Updated!"
                    ));
                	die();
    			}	
    		}
    		else
    		{
    			echo json_encode(
                array("statusCode"=>3, 
                "Message"=>"Something Went Wrong!"
                ));
                die();

    		}
    	}
    	else
    	{
    		echo json_encode(
            array("statusCode"=>0, 
            "Message"=>"Something Went Wrong!"
            ));
            die();
    	}
   	}

	public function dashboard()
	{
		if ($this->is_logged_in())
		{
			$username = $this->session->userdata('administrator_log');
			$administrator_data = $this->administrator_model->administrator($username);
			$data['administrator_data'] = $administrator_data['0'];


            $usersdata = $this->administrator_model->userscount();
            $data['total_users'] = @$usersdata['0']->users;
            
            $administratordata = $this->administrator_model->administratorcount();
            $data['total_administrators'] = @$administratordata['0']->users;

			$admindata = $this->administrator_model->admincount();
            $data['total_admins'] = @$admindata['0']->users;
            
            $studentdata = $this->administrator_model->studentcount();
            $data['total_students'] = @$studentdata['0']->users;
        
            $role_id = $administrator_data['0']['role_id'];
            $data['permission_details'] = $this->administrator_model->checkroleexist($role_id);
        
			$this->load->view('header', $data);
			$this->load->view('dashboard', $data);
			$this->load->view('footer');
		}
		else
		{
			redirect('/');
		}
	}
    
    public function editadmindetails()
    {
        $username = $this->session->userdata('administrator_log');
		$administrator_data = $this->administrator_model->administrator($username);
		$data['administrator_data'] = $administrator_data['0'];
		$user_id = @$administrator_data['0']['user_id'];
		$admin_id = $this->input->get('admin');
		$data['admin_data'] = $this->administrator_model->getAdminByAdminId($admin_id);
		$role_id = $administrator_data['0']['role_id'];
        $data['permission_details'] = $this->administrator_model->checkroleexist($role_id);
		
        // echo "<pre>"; print_r($data); die();
        
        $this->load->view('header', $data);
        $this->load->view('editadmindetails', $data);
        $this->load->view('footer');
    }
    
    public function updateadmin()
    {
        if($this->input->post('name') != NULL && !empty($this->input->post('name'))
        && $this->input->post('contact') != NULL && !empty($this->input->post('contact'))
        && $this->input->post('email') != NULL && !empty($this->input->post('email'))
        && $this->input->post('username') != NULL && !empty($this->input->post('username'))
        && $this->input->post('id') != NULL && !empty($this->input->post('id')))
        {
            $config['upload_path']="upload/admin/profilephoto";
            $config['allowed_types']='jpeg|jpg|png';
            $config['encrypt_name'] = TRUE;
            $this->load->library('upload',$config);

            
            $current_username = $this->session->userdata('administrator_log');
            $administrator_data = $this->administrator_model->administrator($current_username);
            $user_id = @$administrator_data['0']['user_id'];

            $name = $this->input->post('name');
            $contact = $this->input->post('contact');
            $email = $this->input->post('email');
            $username = $this->input->post('username');
            $admin_id = $this->input->post('id');
            
            $profile = "";
            if($this->upload->do_upload("profile-photo"))
            {
                $data = array('upload_data' => $this->upload->data());
                $profile= $data['upload_data']['file_name']; 
            }
                        
            $adminupdated = $this->administrator_model->updateadmin($name, $contact, $email, $profile, $username, $admin_id, $user_id);
                if($adminupdated)
                {
                    echo json_encode(
                        array("statusCode"=>1, 
                        "Message"=>"Admin Updated Successfully!"
                        ));
                    die();
                }
                else
                {
                    echo json_encode(
                        array("statusCode"=>2, 
                        "Message"=>"Unable to Update Admin! Try again later"
                        ));
                    die();
                }        
        }
        else
        {
            echo json_encode(
                array("statusCode"=>0, 
                "Message"=>"Something is wrong!, Try again later"
                ));
            die();
        }
    }
    public function editadministratordetails()
    {
        $username = $this->session->userdata('administrator_log');
        $administrator_data = $this->administrator_model->administrator($username);
        $data['administrator_data'] = $administrator_data['0'];
        $user_id = @$administrator_data['0']['user_id'];
        $id = $this->input->get('id');
       
		$data['admin_data'] = $this->administrator_model->getadministratorbyid($id);
		 

        $role_id = $administrator_data['0']['role_id'];
        $data['permission_details'] = $this->administrator_model->checkroleexist($role_id);
        
        // echo "<pre>"; print_r($data); die();
        
        $this->load->view('header', $data);
        $this->load->view('editadministratordetails', $data);
        $this->load->view('footer');
    }
    
    public function updateadministrator()
    {
        if($this->input->post('name') != NULL && !empty($this->input->post('name'))
        && $this->input->post('contact') != NULL && !empty($this->input->post('contact'))
        && $this->input->post('email') != NULL && !empty($this->input->post('email'))
        && $this->input->post('username') != NULL && !empty($this->input->post('username'))
        && $this->input->post('user_id') != NULL && !empty($this->input->post('user_id')))
        {
            $config['upload_path']="upload/administrator/profilephoto";
            $config['allowed_types']='jpeg|jpg|png';
            $config['encrypt_name'] = TRUE;
            $this->load->library('upload',$config);

            
            $current_username = $this->session->userdata('administrator_log');
            $administrator_data = $this->administrator_model->administrator($current_username);
            $user_id = @$administrator_data['0']['user_id'];

            $name = $this->input->post('name');
            $contact = $this->input->post('contact');
            $email = $this->input->post('email');
            $username = $this->input->post('username');
            $admin_id = $this->input->post('user_id');
            
            $profile = "";
            if($this->upload->do_upload("profile-photo"))
            {
                $data = array('upload_data' => $this->upload->data());
                $profile= $data['upload_data']['file_name']; 
            }
                        
            $administratorupdated = $this->administrator_model->updateadministrator($name, $contact, $email, $profile, $username, $user_id,$admin_id);
                if($administratorupdated)
                {
                    echo json_encode(
                        array("statusCode"=>1, 
                        "Message"=>"Administrator Updated successfully!"
                        ));
                    die();
                }
                else
                {
                    echo json_encode(
                        array("statusCode"=>2, 
                        "Message"=>"Unable to Update Administrator! Try again later"
                        ));
                    die();
                }        
        }
        else
        {
            echo json_encode(
                array("statusCode"=>0, 
                "Message"=>"Something is wrong!, Try again later"
                ));
            die();
        }
    }
    
	public function changepassword()
	{
		if ($this->is_logged_in())
		{
			$username = $this->session->userdata('administrator_log');
			$administrator_data = $this->administrator_model->administrator($username);
			$data['administrator_data'] = $administrator_data['0'];
			
			$role_id = $administrator_data['0']['role_id'];
            $data['permission_details'] = $this->administrator_model->checkroleexist($role_id);
            
			$this->load->view('header', $data);
			$this->load->view('changepassword', $data);
			$this->load->view('footer');
		}
		else
		{
			redirect('/');
		}
	}

	public function administratorlog()
	{
		if ($this->is_logged_in())
		{
			$username = $this->session->userdata('administrator_log');
			$administrator_data = $this->administrator_model->administrator($username);
			$data['administrator_data'] = $administrator_data['0'];
			$data['administrator_log'] = $this->administrator_model->administratorlog();
			
			$role_id = $administrator_data['0']['role_id'];
            $data['permission_details'] = $this->administrator_model->checkroleexist($role_id);
            
			$this->load->view('header', $data);
			$this->load->view('administratorlog', $data);
			$this->load->view('footer');
		}
		else
		{
			redirect('/');
		}
	}

	public function userlog()
	{
		if ($this->is_logged_in())
		{
			$username = $this->session->userdata('administrator_log');
			$administrator_data = $this->administrator_model->administrator($username);
			$data['administrator_data'] = $administrator_data['0'];
			$data['user_log'] = $this->administrator_model->userlog();
			// print_r($data['user_log']); die();
			$role_id = $administrator_data['0']['role_id'];
            $data['permission_details'] = $this->administrator_model->checkroleexist($role_id);
            
			$this->load->view('header', $data);
			$this->load->view('userlog', $data);
			$this->load->view('footer');
		}
		else
		{
			redirect('/');
		}
	}

	public function employeelog()
	{
		if ($this->is_logged_in())
		{
			$username = $this->session->userdata('administrator_log');
			$administrator_data = $this->administrator_model->administrator($username);
			$data['administrator_data'] = $administrator_data['0'];
			$data['employee_log'] = $this->administrator_model->employeelog();
			// print_r($data['user_log']); die();
			$role_id = $administrator_data['0']['role_id'];
            $data['permission_details'] = $this->administrator_model->checkroleexist($role_id);
            
			$this->load->view('header', $data);
			$this->load->view('employeelog', $data);
			$this->load->view('footer');
		}
		else
		{
			redirect('/');
		}
	}

	public function adminlog()
	{
		if ($this->is_logged_in())
		{
			$username = $this->session->userdata('administrator_log');
			$administrator_data = $this->administrator_model->administrator($username);
			$data['administrator_data'] = $administrator_data['0'];
			$data['employee_log'] = $this->administrator_model->adminlog();
			// print_r($data['user_log']); die();
			$role_id = $administrator_data['0']['role_id'];
            $data['permission_details'] = $this->administrator_model->checkroleexist($role_id);
            
			$this->load->view('header', $data);
			$this->load->view('adminlog', $data);
			$this->load->view('footer');
		}
		else
		{
			redirect('/');
		}
	}

	public function role()
	{
		if ($this->is_logged_in())
		{
			$username = $this->session->userdata('administrator_log');
			$administrator_data = $this->administrator_model->administrator($username);
			$data['administrator_data'] = $administrator_data['0'];
			$data['role_data'] = $this->administrator_model->role();
			
			$role_id = $administrator_data['0']['role_id'];
            $data['permission_details'] = $this->administrator_model->checkroleexist($role_id);
            
			$this->load->view('header', $data);
			$this->load->view('role', $data);
			$this->load->view('footer');
		}
		else
		{
			redirect('/');
		}
	}

	public function administrator()
	{
		if ($this->is_logged_in())
		{
			$username = $this->session->userdata('administrator_log');
			$administrator_data = $this->administrator_model->administrator($username);
			$data['administrator_data'] = $administrator_data['0'];
			$data['administrators_data'] = $this->administrator_model->administrators();
			$role_id = $administrator_data['0']['role_id'];
            $data['permission_details'] = $this->administrator_model->checkroleexist($role_id);
            
			$this->load->view('header', $data);
			$this->load->view('administrator', $data);
			$this->load->view('footer');
		}
		else
		{
			redirect('/');
		}
	}

	public function createadministrator()
	{
		if ($this->is_logged_in())
		{
			$username = $this->session->userdata('administrator_log');
			$administrator_data = $this->administrator_model->administrator($username);
			$data['administrator_data'] = $administrator_data['0'];
			$data['role_data'] = $this->administrator_model->role();
			$role_id = $administrator_data['0']['role_id'];
            $data['permission_details'] = $this->administrator_model->checkroleexist($role_id);
			$this->load->view('header', $data);
			$this->load->view('create_administrator', $data);
			$this->load->view('footer');
		}
		else
		{
			redirect('/');
		}
	}

	public function users()
	{
		if ($this->is_logged_in())
		{
			$username = $this->session->userdata('administrator_log');
			$administrator_data = $this->administrator_model->administrator($username);
			$data['administrator_data'] = $administrator_data['0'];
			$data['user_data'] = $this->administrator_model->users();
			$role_id = $administrator_data['0']['role_id'];
            $data['permission_details'] = $this->administrator_model->checkroleexist($role_id);
			$this->load->view('header', $data);
			$this->load->view('users', $data);
			$this->load->view('footer');
		}
		else
		{
			redirect('/');
		}
	}
	
	public function messages()
	{
		if ($this->is_logged_in())
		{
			$username = $this->session->userdata('administrator_log');
			$administrator_data = $this->administrator_model->administrator($username);
			$data['administrator_data'] = $administrator_data['0'];
			$data['message_data'] = $this->administrator_model->messages();
			$role_id = $administrator_data['0']['role_id'];
            $data['permission_details'] = $this->administrator_model->checkroleexist($role_id);
			$this->load->view('header', $data);
			$this->load->view('messages', $data);
			$this->load->view('footer');
		}
		else
		{
			redirect('/');
		}
	}
	
	public function members()
	{
		if ($this->is_logged_in())
		{
			$username = $this->session->userdata('administrator_log');
			$administrator_data = $this->administrator_model->administrator($username);
			$data['administrator_data'] = $administrator_data['0'];
			$role_id = $administrator_data['0']['role_id'];
            $data['permission_details'] = $this->administrator_model->checkroleexist($role_id);
            $data['admin_list'] = $this->administrator_model->adminlist();
            $data['retailer_list'] = $this->administrator_model->retailerlist();
			if(isset($_POST['search']))
			{
				$type = $this->input->post('type');
				$status = $this->input->post('status');
				$admin = $this->input->post('admin');
				$retailer = $this->input->post('retailer');
				$employee = $this->input->post('employee');
				$start_date = $this->input->post('start_date');
				$end_date = $this->input->post('end_date');
				$remark_start_date = $this->input->post('remark_start_date');
				$remark_end_date = $this->input->post('remark_end_date');
				$data['user_data'] = $this->administrator_model->filtermembers($type, $status, $admin, $retailer, $employee, $start_date, $end_date, $remark_start_date, $remark_end_date);
				//echo "<pre>"; print_r($data['user_data']); die();
			}
			else
			{
				$data['user_data'] = [];
			}
			$data['employee_data'] = $this->administrator_model->employees();
			$this->load->view('header', $data);
			$this->load->view('members', $data);
			$this->load->view('footer');
		}
		else
		{
			redirect('/');
		}
	}

	public function removefromemployee()
	{
		if ($this->is_logged_in())
		{
			$username = $this->session->userdata('administrator_log');
			$administrator_data = $this->administrator_model->administrator($username);
			$data['administrator_data'] = $administrator_data['0'];
			$data['user_data'] = $this->administrator_model->visible_to_employee();
			$role_id = $administrator_data['0']['role_id'];
            $data['permission_details'] = $this->administrator_model->checkroleexist($role_id);
			$this->load->view('header', $data);
			$this->load->view('visible_to_employee', $data);
			$this->load->view('footer');
		}
		else
		{
			redirect('/');
		}
	}

	public function removefromretailer()
	{
		if ($this->is_logged_in())
		{
			$username = $this->session->userdata('administrator_log');
			$administrator_data = $this->administrator_model->administrator($username);
			$data['administrator_data'] = $administrator_data['0'];
			$role_id = $administrator_data['0']['role_id'];
            $data['permission_details'] = $this->administrator_model->checkroleexist($role_id);
            $data['admin_list'] = $this->administrator_model->adminlist();
            $data['retailer_list'] = $this->administrator_model->retailerlist();
			if(isset($_POST['search']))
			{
				$type = $this->input->post('type');
				$status = $this->input->post('status');
				$admin = $this->input->post('admin');
				$retailer = $this->input->post('retailer');
				$employee = $this->input->post('employee');
				$start_date = $this->input->post('start_date');
				$end_date = $this->input->post('end_date');
				$remark_start_date = $this->input->post('remark_start_date');
				$remark_end_date = $this->input->post('remark_end_date');
				$data['user_data'] = $this->administrator_model->visible_to_retailer($type, $status, $admin, $retailer, $employee, $start_date, $end_date, $remark_start_date, $remark_end_date);
				//echo "<pre>"; print_r($data['user_data']); die();
			}
			else
			{
				$data['user_data'] = [];
			}
			$data['employee_data'] = $this->administrator_model->employees();

			$this->load->view('header', $data);
			$this->load->view('visible_to_retailer', $data);
			$this->load->view('footer');
		}
		else
		{
			redirect('/');
		}
	}
	
	public function memberdetails()
	{
	    $username = $this->session->userdata('administrator_log');
		$administrator_data = $this->administrator_model->administrator($username);
		$data['administrator_data'] = $administrator_data['0'];
		$role_id = $administrator_data['0']['role_id'];
        $data['permission_details'] = $this->administrator_model->checkroleexist($role_id);
	    $member_id = $this->input->get('member');
	    $data['member_data'] = $this->administrator_model->memeberdetails($member_id);
		$data['retailer'] = $this->administrator_model->getretailerdatta($data['member_data']['retailer_id']);
	    $this->load->view('header', $data);
		$this->load->view('memeberdetails', $data);
		$this->load->view('footer');
	}
	
	public function notification()
	{
		if ($this->is_logged_in())
		{
			$username = $this->session->userdata('administrator_log');
			$administrator_data = $this->administrator_model->administrator($username);
			$data['administrator_data'] = $administrator_data['0'];
			$data['notification_data'] = $this->administrator_model->getnotification();
			$role_id = $administrator_data['0']['role_id'];
            $data['permission_details'] = $this->administrator_model->checkroleexist($role_id);
			$this->load->view('header', $data);
			$this->load->view('notification', $data);
			$this->load->view('footer');
		}
		else
		{
			redirect('/');
		}
	}
	
	public function employees()
	{
		if ($this->is_logged_in())
		{
			$username = $this->session->userdata('administrator_log');
			$administrator_data = $this->administrator_model->administrator($username);
			$data['administrator_data'] = $administrator_data['0'];
			$data['employee_data'] = $this->administrator_model->employees();
			$role_id = $administrator_data['0']['role_id'];
            $data['permission_details'] = $this->administrator_model->checkroleexist($role_id);
			$this->load->view('header', $data);
			$this->load->view('employees', $data);
			$this->load->view('footer');
		}
		else
		{
			redirect('/');
		}
	}

	public function createuser()
	{
		if ($this->is_logged_in())
		{
			$username = $this->session->userdata('administrator_log');
			$administrator_data = $this->administrator_model->administrator($username);
			$data['administrator_data'] = $administrator_data['0'];
			$role_id = $administrator_data['0']['role_id'];
            $data['permission_details'] = $this->administrator_model->checkroleexist($role_id);
			$data['admin_list'] = $this->administrator_model->admins();
			$this->load->view('header', $data);
			$this->load->view('create_user', $data);
			$this->load->view('footer');
		}
		else
		{
			redirect('/');
		}
	}
	
	public function savenotification()
	{
		$username = $this->session->userdata('administrator_log');
		$administrator_data = $this->administrator_model->administrator($username);
		$user_id = $administrator_data['0']['user_id'];
	    $notification = $this->input->post('notification');
	    $saved = $this->administrator_model->savenotification($notification, $user_id);
	    if($saved)
	    {
        	echo json_encode(
				array("statusCode"=>3, 
				"Message"=>"Notification Saved Successfully!"
				));
			die();
	    }
	    else
	    {
	        echo json_encode(
				array("statusCode"=>2, 
				"Message"=>"Unable to save notification! Try again later"
				));
			die();
	    }
	}
	public function createemployee()
	{
		if ($this->is_logged_in())
		{
			$username = $this->session->userdata('administrator_log');
			$administrator_data = $this->administrator_model->administrator($username);
			$data['administrator_data'] = $administrator_data['0'];
			$role_id = $administrator_data['0']['role_id'];
            $data['permission_details'] = $this->administrator_model->checkroleexist($role_id);
			$data['admin_list'] = $this->administrator_model->admins();
			$this->load->view('header', $data);
			$this->load->view('create_employee', $data);
			$this->load->view('footer');
		}
		else
		{
			redirect('/');
		}
	}

	public function updateprofile()
	{
		if($this->input->post('user_id') != NULL && !empty($this->input->post('user_id')))
		{
			$current_username = $this->session->userdata('administrator_log');
            $administrator_data = $this->administrator_model->administrator($current_username);
            $user_id = @$administrator_data['0']['user_id'];

			$admin_id = $this->input->post('user_id');
			$name = $this->input->post('name');
			$email = $this->input->post('email');
			$phone = $this->input->post('phone');
			$config['upload_path']="upload/administrator/profilephoto";
			$config['allowed_types']='jpg|png';
			$config['encrypt_name'] = TRUE;
			$upload_file = "";
			$this->load->library('upload',$config);
			if($this->upload->do_upload("profile-photo"))
			{
	        	$data = array('upload_data' => $this->upload->data());
				$upload_file = $data['upload_data']['file_name'];
			}
			$profileupdated = $this->administrator_model->updateprofile($user_id, $admin_id, $name, $email, $phone, $upload_file);
			if($profileupdated)
			{
				echo json_encode(
					array("statusCode"=>1, 
					"Message"=>"Profile updated successfully"
					));
				die();
			}
			else
			{
				echo json_encode(
					array("statusCode"=>2, 
					"Message"=>"Unable to update your profile! Try again later"
					));
				die();
			}
		}
		else
		{
			echo json_encode(
                array("statusCode"=>0, 
                "Message"=>"Something is wrong! Try again later"
                ));
            die();
		}
	}
	

	public function changepasswordAth()
    {
        if($this->input->post('old_password') != NULL && !empty($this->input->post('old_password'))
        && $this->input->post('new_password') != NULL && !empty($this->input->post('new_password')))
        {
            $username = $this->session->userdata('administrator_log');
            $old_password = $this->input->post('old_password');
            $new_password = $this->input->post('new_password');
            $oldpasswordexistance = $this->administrator_model->checkoldpassword($username, $old_password);
            if($oldpasswordexistance)
            {
                $administrator_data = $this->administrator_model->administrator($username);
                $user_id = @$administrator_data['0']['user_id'];
                $passwordupdated = $this->administrator_model->changepasswordAth($user_id, $new_password);
                if($passwordupdated)
                {
                    echo json_encode(
                        array("statusCode"=>3, 
                        "Message"=>"Your password has been changed successfully!"
                        ));
                    die();
                }
                else
                {
                    echo json_encode(
                        array("statusCode"=>2, 
                        "Message"=>"Unable to update profile! Try again later"
                        ));
                    die();
                }
            }
            else
            {
                echo json_encode(
                    array("statusCode"=>1, 
                    "Message"=>"Your entered old password is wrong!"
                    ));
                die();
            }
        }
        else
        {
            echo json_encode(
                array("statusCode"=>0, 
                "Message"=>"Something is wrong!, Try again later"
                ));
            die();
        }
    }

	public function createRoleAth()
    {
        if($this->input->post('role') != NULL && !empty($this->input->post('role')))
        {
            $username = $this->session->userdata('administrator_log');
            $role = $this->input->post('role');
            $administrator_data = $this->administrator_model->administrator($username);
            $user_id = @$administrator_data['0']['user_id'];
            $roleAdded = $this->administrator_model->createRole($user_id, $role);
            if($roleAdded)
            {
                echo json_encode(
                    array("statusCode"=>2, 
                    "Message"=>"Role created successfully!"
                    ));
                die();
            }
            else
            {
                echo json_encode(
                    array("statusCode"=>1, 
                    "Message"=>"Unable to create Role! Try again later"
                    ));
                die();
            }
        }
        else
        {
            echo json_encode(
                array("statusCode"=>0, 
                "Message"=>"Something is wrong!, Try again later"
                ));
            die();
        }
    }


	public function createAdministratorAuth()
	{
		if($this->input->post('name') != NULL && !empty($this->input->post('name'))
		&& $this->input->post('role') != NULL && !empty($this->input->post('role'))
		&& $this->input->post('status') != NULL && !empty($this->input->post('status'))
		&& $this->input->post('username') != NULL && !empty($this->input->post('username'))
		&& $this->input->post('password') != NULL && !empty($this->input->post('password')))
		{
			$config['upload_path']="upload/administrator/profilephoto";
			$config['allowed_types']='jpeg|jpg|png';
			$config['encrypt_name'] = TRUE;
			$this->load->library('upload',$config);

			$current_username = $this->session->userdata('administrator_log');
			$administrator_data = $this->administrator_model->administrator($current_username);
			$user_id = @$administrator_data['0']['user_id'];

			$name = $this->input->post('name');
			$contact = $this->input->post('contact');
			$email = $this->input->post('email');
			$role = $this->input->post('role');
			$status = $this->input->post('status');
			$username = $this->input->post('username');
			$password = $this->input->post('password');
	
			if($this->checkUserExist($username))
			{
				if(strlen($password) >= 8)
				{
					if($this->passwordValidation($password))
					{
						$profile = "";
						if($this->upload->do_upload("profile-photo"))
						{
							$data = array('upload_data' => $this->upload->data());
							$profile= $data['upload_data']['file_name']; 
						}
						$administratorAdded = $this->administrator_model->createAdministrator($name, $contact, $email, $role, $status, $username, $password, $profile, $user_id);
						if($administratorAdded)
						{
							echo json_encode(
								array("statusCode"=>5, 
								"Message"=>"New administrator has been created successfully!"
								));
							die();
						}
						else
						{
							echo json_encode(
								array("statusCode"=>4, 
								"Message"=>"Unable to create administrator! Try again later"
								));
							die();
						}
					}
					else
					{
						echo json_encode(
							array("statusCode"=>3, 
							"Message"=>"Password must be alphanumeric!"
							));
						die();
					}
				}
				else
				{
					echo json_encode(
						array("statusCode"=>2, 
						"Message"=>"Password must be minimum 8 characters!"
						));
					die();
				}
			}
			else
			{
				echo json_encode(
					array("statusCode"=>1, 
					"Message"=>"Username already exists!"
					));
				die();
			}
		}
		else
		{
			echo json_encode(
				array("statusCode"=>1, 
				"Message"=>"Something is wrong!, Try again later"
				));
			die();
		}
	}

	public function checkUserExist($username)
    {
        $user_data = $this->administrator_model->checkUserExist($username);
        if($user_data=="")
        {
            return TRUE;

        }
        return FALSE;
    }

    public function passwordValidation($password)
    {
        if (preg_match('#[0-9]#', $password) && preg_match('#[a-zA-Z]#', $password)) 
        {
            return TRUE;
        }
        return FALSE;
    }

	public function deleteAdmin()
	{
		if($this->input->post('user_id') != NULL && !empty($this->input->post('user_id')))
        {
			$current_username = $this->session->userdata('administrator_log');
            $administrator_data = $this->administrator_model->administrator($current_username);
            $user_id = @$administrator_data['0']['user_id'];
            
			$admin_id = $this->input->post('user_id');
			$user_details = $this->administrator_model->getUserByUserId($admin_id);
			$username = @$user_details['email'];
			$statusUpdated = $this->administrator_model->deleteUser($admin_id, $user_id, $username);
			if($statusUpdated)
			{
				echo json_encode(
					array("statusCode"=>2, 
					"Message"=>"Administrator has been Deleted successfully!"
					));
				die();
			}
			else
			{
				echo json_encode(
					array("statusCode"=>1, 
					"Message"=>"Unable to Delete this Administrator! Try again later"
					));
				die();
			}
		}
		else
		{
			echo json_encode(
                array("statusCode"=>0, 
                "Message"=>"Something is wrong!, Try again later"
                ));
            die();
		}
	}

	public function createretailerath()
	{
		if($this->input->post('name') != NULL && !empty($this->input->post('name'))
		&& $this->input->post('status') != NULL && !empty($this->input->post('status'))
		&& $this->input->post('username') != NULL && !empty($this->input->post('username'))
		&& $this->input->post('password') != NULL && !empty($this->input->post('password')))
		{
			$config['upload_path']="upload/user/profilephoto";
			$config['allowed_types']='jpeg|jpg|png';
			$config['encrypt_name'] = TRUE;
			$this->load->library('upload',$config);

			$current_username = $this->session->userdata('administrator_log');
			$administrator_data = $this->administrator_model->administrator($current_username);
			$user_id = @$administrator_data['0']['user_id'];

			$name = $this->input->post('name');
			$contact = $this->input->post('contact');
			$email = $this->input->post('email');
			$status = $this->input->post('status');
			$username = $this->input->post('username');
			$password = $this->input->post('password');
			$admin = $this->input->post('admin');
	
			if($this->checkRetailerExist($username))
			{
				if(strlen($password) >= 8)
				{
					if($this->passwordValidation($password))
					{
						$profile = "";
						if($this->upload->do_upload("profile-photo"))
						{
							$data = array('upload_data' => $this->upload->data());
							$profile= $data['upload_data']['file_name']; 
						}
						$administratorAdded = $this->administrator_model->createretailer($name, $contact, $email, $status, $username, $password, $profile, $user_id, $admin);
						if($administratorAdded)
						{
							echo json_encode(
								array("statusCode"=>5, 
								"Message"=>"New Retailer has been created successfully!"
								));
							die();
						}
						else
						{
							echo json_encode(
								array("statusCode"=>4, 
								"Message"=>"Unable to create Retailer! Try again later"
								));
							die();
						}
					}
					else
					{
						echo json_encode(
							array("statusCode"=>3, 
							"Message"=>"Password must be alphanumeric!"
							));
						die();
					}
				}
				else
				{
					echo json_encode(
						array("statusCode"=>2, 
						"Message"=>"Password must be minimum 8 characters!"
						));
					die();
				}
			}
			else
			{
				echo json_encode(
					array("statusCode"=>1, 
					"Message"=>"Username already exists!"
					));
				die();
			}
		}
		else
		{
			echo json_encode(
				array("statusCode"=>1, 
				"Message"=>"Something is wrong!, Try again later"
				));
			die();
		}
		
	}

	public function createemployeeath()
	{
		if($this->input->post('name') != NULL && !empty($this->input->post('name'))
		&& $this->input->post('status') != NULL && !empty($this->input->post('status'))
		&& $this->input->post('username') != NULL && !empty($this->input->post('username'))
		&& $this->input->post('password') != NULL && !empty($this->input->post('password')))
		{
			$config['upload_path']="upload/employee/profilephoto";
			$config['allowed_types']='jpeg|jpg|png';
			$config['encrypt_name'] = TRUE;
			$this->load->library('upload',$config);

			$current_username = $this->session->userdata('administrator_log');
			$administrator_data = $this->administrator_model->administrator($current_username);
			$user_id = @$administrator_data['0']['user_id'];

			$name = $this->input->post('name');
			$contact = $this->input->post('contact');
			$email = $this->input->post('email');
			$status = $this->input->post('status');
			$username = $this->input->post('username');
			$password = $this->input->post('password');
	
			if($this->checkEmployeeExist($username))
			{
				if(strlen($password) >= 4)
				{
					if($this->passwordValidation($password))
					{
						$profile = "";
						if($this->upload->do_upload("profile-photo"))
						{
							$data = array('upload_data' => $this->upload->data());
							$profile= $data['upload_data']['file_name']; 
						}
						$administratorAdded = $this->administrator_model->createemployee($name, $contact, $email, $status, $username, $password, $profile, $user_id);
						if($administratorAdded)
						{
							echo json_encode(
								array("statusCode"=>5, 
								"Message"=>"New Employee has been created successfully!"
								));
							die();
						}
						else
						{
							echo json_encode(
								array("statusCode"=>4, 
								"Message"=>"Unable to create Employee! Try again later"
								));
							die();
						}
					}
					else
					{
						echo json_encode(
							array("statusCode"=>3, 
							"Message"=>"Password must be alphanumeric!"
							));
						die();
					}
				}
				else
				{
					echo json_encode(
						array("statusCode"=>2, 
						"Message"=>"Password must be minimum 8 characters!"
						));
					die();
				}
			}
			else
			{
				echo json_encode(
					array("statusCode"=>1, 
					"Message"=>"Username already exists!"
					));
				die();
			}
		}
		else
		{
			echo json_encode(
				array("statusCode"=>1, 
				"Message"=>"Something is wrong!, Try again later"
				));
			die();
		}
		
	}


	public function checkRetailerExist($username)
	{
		 $user_data = $this->administrator_model->checkRetailerExist($username);
        if($user_data=="")
        {
            return TRUE;

        }
        return FALSE;
	}
	public function checkEmployeeExist($username)
	{
		 $user_data = $this->administrator_model->checkEmployeeExist($username);
        if($user_data=="")
        {
            return TRUE;

        }
        return FALSE;
	}

	public function deleteUser()
	{
		if($this->input->post('user_id') != NULL && !empty($this->input->post('user_id')))
        {
			$current_username = $this->session->userdata('administrator_log');
            $administrator_data = $this->administrator_model->administrator($current_username);
            $user_id = @$administrator_data['0']['user_id'];
            
			$retailer_id = $this->input->post('user_id');
			$user_details = $this->administrator_model->getRetailerByUserId($retailer_id);
			$username = @$user_details['email'];
			$statusUpdated = $this->administrator_model->deleteRetailer($retailer_id, $user_id, $username);
			if($statusUpdated)
			{
				echo json_encode(
					array("statusCode"=>2, 
					"Message"=>"Retailer has been Deleted successfully!"
					));
				die();
			}
			else
			{
				echo json_encode(
					array("statusCode"=>1, 
					"Message"=>"Unable to Delete this Retailer! Try again later"
					));
				die();
			}
		}
		else
		{
			echo json_encode(
                array("statusCode"=>0, 
                "Message"=>"Something is wrong!, Try again later"
                ));
            die();
		}
	}

	public function userDetailes()
	{
		if($this->input->post('id') != NULL && !empty($this->input->post('id')))
        {           
			$retailer_id = $this->input->post('id');
			$retailerdetails = $this->administrator_model->getRetailerByUserId($retailer_id);
			$admin = $retailerdetails['admin'];
			$admindetails = $this->administrator_model->getAdminByAdminId($admin);
			$admin_username = $admindetails['username'];
			echo json_encode(array($retailerdetails, $admin_username));
			die();
		}
	}

	public function adminDetailes()
	{
		if($this->input->post('id') != NULL && !empty($this->input->post('id')))
        {           
			$admin_id = $this->input->post('id');
			$admindetails = $this->administrator_model->getUserByUserId($admin_id);
			echo json_encode($admindetails);
			die();
		}
	}
	
	public function employeedetail()
	{
		if($this->input->post('id') != NULL && !empty($this->input->post('id')))
        {           
			$employee_id = $this->input->post('id');
			$admindetails = $this->administrator_model->getEmployeeByUserId($employee_id);
			echo json_encode($admindetails);
			die();
		}
	}

	public function students()
	{
		if ($this->is_logged_in())
		{
			$retailer = $this->input->get('retailer');
			$username = $this->session->userdata('administrator_log');
			$administrator_data = $this->administrator_model->administrator($username);
			$data['administrator_data'] = $administrator_data['0'];
			$data['student_data'] = $this->Retailer_model->students($retailer);
			
			$role_id = $administrator_data['0']['role_id'];
            $data['permission_details'] = $this->administrator_model->checkroleexist($role_id);
            
			$this->load->view('header', $data);
			$this->load->view('students', $data);
			$this->load->view('footer');
		}
		else
		{
			redirect('/');
		}
	}

	public function fingerprints()
    {
		if ($this->is_logged_in())
		{
			$student_id = $this->input->get('member');
			$retailer = $this->input->get('retailer');
			$username = $this->session->userdata('administrator_log');
			$administrator_data = $this->administrator_model->administrator($username);
			$data['administrator_data'] = $administrator_data['0'];
			$data['student_finger_data'] = $this->Retailer_model->studentsfingers($student_id);
			//$this->load->view('header', $data);
			$this->load->view('fingerprints', $data);
			//$this->load->view('footer');
		}
		else
		{
			redirect('/');
		}
    }
    
    public function deleteStudent()
	{
		if($this->input->post('student_id') != NULL && !empty($this->input->post('student_id')))
        {
            
			$current_username = $this->session->userdata('administrator_log');
            $administrator_data = $this->administrator_model->administrator($current_username);
            $user_id = @$administrator_data['0']['user_id'];
            
			$student_id = $this->input->post('student_id');
			$statusUpdated = $this->administrator_model->deleteStudent($student_id, $user_id);
			if($statusUpdated)
			{
			    
				echo json_encode(
					array("statusCode"=>2, 
					"Message"=>"Student has been Deleted successfully!"
					));
				die();
			}
			else
			{
				echo json_encode(
					array("statusCode"=>1, 
					"Message"=>"Unable to Delete this Student! Try again later"
					));
				die();
			}
		}
		else
		{
			echo json_encode(
                array("statusCode"=>0, 
                "Message"=>"Something is wrong!, Try again later"
                ));
            die();
		}
	}
	
	public function changeUserStatus()
	{
		if($this->input->post('user_id') != NULL && !empty($this->input->post('user_id')))
        {
			$current_username = $this->session->userdata('administrator_log');
            $administrator_data = $this->administrator_model->administrator($current_username);
            $admin_id = @$administrator_data['0']['user_id'];
            
			$user_id = $this->input->post('user_id');
			$status_id = $this->input->post('status_id');
			$user_status = "";
			if($status_id =="1")
			{
				$user_status = "Activated";
			}
			else if($status_id =="0")
			{
				$user_status = "Deactivated";
			}
			$statusUpdated = $this->administrator_model->changeUserStatus($status_id, $user_id, $admin_id);
			if($statusUpdated)
			{
				echo json_encode(
					array("statusCode"=>2, 
					"Message"=>"User has been ".$user_status." successfully!"
					));
				die();
			}
			else
			{
				echo json_encode(
					array("statusCode"=>1, 
					"Message"=>"Unable to update status! Try again later"
					));
				die();
			}
		}
		else
		{
			echo json_encode(
                array("statusCode"=>0, 
                "Message"=>"Something is wrong!, Try again later"
                ));
            die();
		}
	}
	
	public function changeEmployeeStatus()
	{
		if($this->input->post('user_id') != NULL && !empty($this->input->post('user_id')))
        {
			$current_username = $this->session->userdata('administrator_log');
            $administrator_data = $this->administrator_model->administrator($current_username);
            $admin_id = @$administrator_data['0']['user_id'];
            
			$user_id = $this->input->post('user_id');
			$status_id = $this->input->post('status_id');
			$user_status = "";
			if($status_id =="1")
			{
				$user_status = "Activated";
			}
			else if($status_id =="0")
			{
				$user_status = "Deactivated";
			}
			$statusUpdated = $this->administrator_model->changeEmployeeStatus($status_id, $user_id, $admin_id);
			if($statusUpdated)
			{
				echo json_encode(
					array("statusCode"=>2, 
					"Message"=>"User has been ".$user_status." successfully!"
					));
				die();
			}
			else
			{
				echo json_encode(
					array("statusCode"=>1, 
					"Message"=>"Unable to update status! Try again later"
					));
				die();
			}
		}
		else
		{
			echo json_encode(
                array("statusCode"=>0, 
                "Message"=>"Something is wrong!, Try again later"
                ));
            die();
		}
	}

	public function changeAdminStatus()
	{
		if($this->input->post('user_id') != NULL && !empty($this->input->post('user_id')))
        {
			$current_username = $this->session->userdata('administrator_log');
            $administrator_data = $this->administrator_model->administrator($current_username);
            $admin_id = @$administrator_data['0']['user_id'];
            
			$user_id = $this->input->post('user_id');
			$status_id = $this->input->post('status_id');
			$user_status = "";
			if($status_id =="1")
			{
				$user_status = "Activated";
			}
			else if($status_id =="0")
			{
				$user_status = "Deactivated";
			}
			$statusUpdated = $this->administrator_model->changeAdminStatus($status_id, $user_id, $admin_id);
			if($statusUpdated)
			{
				echo json_encode(
					array("statusCode"=>2, 
					"Message"=>"User has been ".$user_status." successfully!"
					));
				die();
			}
			else
			{
				echo json_encode(
					array("statusCode"=>1, 
					"Message"=>"Unable to update status! Try again later"
					));
				die();
			}
		}
		else
		{
			echo json_encode(
                array("statusCode"=>0, 
                "Message"=>"Something is wrong!, Try again later"
                ));
            die();
		}
	}
	
	public function changeViewStatus()
	{
		if($this->input->post('user_id') != NULL && !empty($this->input->post('user_id')))
        {
			$current_username = $this->session->userdata('administrator_log');
            $administrator_data = $this->administrator_model->administrator($current_username);
            $admin_id = @$administrator_data['0']['user_id'];
            
			$user_id = $this->input->post('user_id');
			$status_id = $this->input->post('status_id');
			$user_status = "";
			if($status_id =="1")
			{
				$user_status = "Activated";
			}
			else if($status_id =="0")
			{
				$user_status = "Deactivated";
			}
			$statusUpdated = $this->administrator_model->changeViewStatus($status_id, $user_id, $admin_id);
			if($statusUpdated)
			{
				echo json_encode(
					array("statusCode"=>2, 
					"Message"=>"User has been ".$user_status." successfully!"
					));
				die();
			}
			else
			{
				echo json_encode(
					array("statusCode"=>1, 
					"Message"=>"Unable to update status! Try again later"
					));
				die();
			}
		}
		else
		{
			echo json_encode(
                array("statusCode"=>0, 
                "Message"=>"Something is wrong!, Try again later"
                ));
            die();
		}
	}
	
	public function deleteRole()
	{
	    if($this->input->post('role_id') != NULL && !empty($this->input->post('role_id')))
        {
			$current_username = $this->session->userdata('administrator_log');
            $administrator_data = $this->administrator_model->administrator($current_username);
            $user_id = @$administrator_data['0']['user_id'];
            
			$role_id = $this->input->post('role_id');
			$statusUpdated = $this->administrator_model->deleteRole($role_id, $user_id);
			if($statusUpdated)
			{
				echo json_encode(
					array("statusCode"=>2, 
					"Message"=>"Role has been Deleted successfully!"
					));
				die();
			}
			else
			{
				echo json_encode(
					array("statusCode"=>1, 
					"Message"=>"Unable to Delete this Role! Try again later"
					));
				die();
			}
		}
		else
		{
			echo json_encode(
                array("statusCode"=>0, 
                "Message"=>"Something is wrong!, Try again later"
                ));
            die();
		}
	}
	
	public function assignrole()
	{
	    if ($this->is_logged_in())
		{
			$username = $this->session->userdata('administrator_log');
			$administrator_data = $this->administrator_model->administrator($username);
			$data['administrator_data'] = $administrator_data['0'];
			
			$role_id = $administrator_data['0']['role_id'];
            $data['permission_details'] = $this->administrator_model->checkroleexist($role_id);

			$this->load->view('header', $data);
			$this->load->view('assignrole', $data);
			$this->load->view('footer');
		}
		else
		{
			redirect('/');
		}
	}
	
	public function assignroleath()
	{
	    $create_retailer = $this->input->post('create_retailer');
	    $retailers_list = $this->input->post('retailers_list');
	    $retailer_status = $this->input->post('retailer_status');
	    $students_list = $this->input->post('students_list');
	    $view_status = $this->input->post('view_status');
	    $view_student = $this->input->post('view_student');
	    $delete_student = $this->input->post('delete_student');
	    $student_finger = $this->input->post('student_finger');
	    $administrator = $this->input->post('administrator');
	    $roleandpermission = $this->input->post('roleandpermission');
	    $delete_retailer = $this->input->post('delete_retailer');
	    $role_id = $this->input->post('role_id');
	    $roleexist = $this->administrator_model->checkroleexist($role_id);
	    if($roleexist)
	    {
	        $inserted = $this->administrator_model->updateroleassign($create_retailer, $retailers_list, $retailer_status, $students_list, $view_status, $view_student, $delete_student, $student_finger, $role_id, $roleandpermission, $administrator, $delete_retailer);
    	    if($inserted)
    	    {
    	        echo json_encode(
    				array("statusCode"=>1, 
    				"Message"=>"Changes Saved Successfully!"
    				));
    			die();
    	    }
    	    else
    	    {
    	        echo json_encode(
    				array("statusCode"=>2, 
    				"Message"=>"Unable to Save changes!"
    				));
    			die();
    	    }
	    }
	    else
	    {
	        $inserted = $this->administrator_model->assignrolenew($create_retailer, $retailers_list, $retailer_status, $students_list, $view_status, $view_student, $delete_student, $student_finger, $role_id, $roleandpermission, $administrator, $delete_retailer);
    	    if($inserted)
    	    {
    	        echo json_encode(
    				array("statusCode"=>2, 
    				"Message"=>"Unable to Save changes!"
    				));
    			die();
    	    }
    	    else
    	    {
    	        echo json_encode(
    				array("statusCode"=>1, 
    				"Message"=>"Changes Saved Successfully!"
    				));
    			die();
    	    }
	    }
	}

	public function admin()
	{
		if ($this->is_logged_in())
		{
			$username = $this->session->userdata('administrator_log');
			$admin_data = $this->administrator_model->administrator($username);
			$data['administrator_data'] = $admin_data['0'];
			$data['admin_data'] = $this->administrator_model->admins();
			$role_id = $admin_data['0']['role_id'];
            $data['permission_details'] = $this->administrator_model->checkroleexist($role_id);
			$this->load->view('header', $data);
			$this->load->view('admin', $data);
			$this->load->view('footer');
		}
		else
		{
			redirect('/');
		}
	}

	public function createadmin()
	{
		if ($this->is_logged_in())
		{
			$username = $this->session->userdata('administrator_log');
			$administrator_data = $this->administrator_model->administrator($username);
			$data['administrator_data'] = $administrator_data['0'];
			$data['role_data'] = $this->administrator_model->role();
			$role_id = $administrator_data['0']['role_id'];
            $data['permission_details'] = $this->administrator_model->checkroleexist($role_id);
			$this->load->view('header', $data);
			$this->load->view('create_admin', $data);
			$this->load->view('footer');
		}
		else
		{
			redirect('/');
		}
	}

	public function admindetail()
	{
		if($this->input->post('id') != NULL && !empty($this->input->post('id')))
        {           
			$admin_id = $this->input->post('id');
			$admindetails = $this->administrator_model->getAdminByAdminId($admin_id);
			echo json_encode($admindetails);
			die();
		}
	}

	public function deleteadmins()
	{
		if($this->input->post('user_id') != NULL && !empty($this->input->post('user_id')))
        {
			$current_username = $this->session->userdata('administrator_log');
            $administrator_data = $this->administrator_model->administrator($current_username);
            $user_id = @$administrator_data['0']['user_id'];
            
			$admin_id = $this->input->post('user_id');
			$user_details = $this->administrator_model->getAdminByAdminId($admin_id);
			$username = @$user_details['email'];
			$statusUpdated = $this->administrator_model->deleteAdmin($admin_id, $user_id, $username);
			if($statusUpdated)
			{
				echo json_encode(
					array("statusCode"=>2, 
					"Message"=>"Admin has been Deleted successfully!"
					));
				die();
			}
			else
			{
				echo json_encode(
					array("statusCode"=>1, 
					"Message"=>"Unable to Delete this Admin! Try again later"
					));
				die();
			}
		}
		else
		{
			echo json_encode(
                array("statusCode"=>0, 
                "Message"=>"Something is wrong!, Try again later"
                ));
            die();
		}
	}

	public function createAdminAth()
	{
		if($this->input->post('name') != NULL && !empty($this->input->post('name'))
		&& $this->input->post('status') != NULL && !empty($this->input->post('status'))
		&& $this->input->post('username') != NULL && !empty($this->input->post('username'))
		&& $this->input->post('password') != NULL && !empty($this->input->post('password')))
		{
			$config['upload_path']="upload/admin/profilephoto";
			$config['allowed_types']='jpeg|jpg|png';
			$config['encrypt_name'] = TRUE;
			$this->load->library('upload',$config);

			$current_username = $this->session->userdata('administrator_log');
			$administrator_data = $this->administrator_model->administrator($current_username);
			$user_id = @$administrator_data['0']['user_id'];

			$name = $this->input->post('name');
			$contact = $this->input->post('contact');
			$email = $this->input->post('email');
			$status = $this->input->post('status');
			$username = $this->input->post('username');
			$password = $this->input->post('password');
			$no_of_retailer = $this->input->post('no_of_retailer');
			$no_of_employee = $this->input->post('no_of_employee');

			if($this->checkAdminExist($username))
			{
				if(strlen($password) >= 8)
				{
					if($this->passwordValidation($password))
					{
						$profile = "";
						if($this->upload->do_upload("profile-photo"))
						{
							$data = array('upload_data' => $this->upload->data());
							$profile= $data['upload_data']['file_name']; 
						}
						$administratorAdded = $this->administrator_model->createAdmin($name, $contact, $email, $status, $username, $password, $profile, $user_id, $no_of_retailer, $no_of_employee);
						if($administratorAdded)
						{
							echo json_encode(
								array("statusCode"=>5, 
								"Message"=>"New Admin has been created successfully!"
								));
							die();
						}
						else
						{
							echo json_encode(
								array("statusCode"=>4, 
								"Message"=>"Unable to create Admin! Try again later"
								));
							die();
						}
					}
					else
					{
						echo json_encode(
							array("statusCode"=>3, 
							"Message"=>"Password must be alphanumeric!"
							));
						die();
					}
				}
				else
				{
					echo json_encode(
						array("statusCode"=>2, 
						"Message"=>"Password must be minimum 8 characters!"
						));
					die();
				}
			}
			else
			{
				echo json_encode(
					array("statusCode"=>1, 
					"Message"=>"Username already exists!"
					));
				die();
			}
		}
		else
		{
			echo json_encode(
				array("statusCode"=>1, 
				"Message"=>"Something is wrong!, Try again later"
				));
			die();
		}
	}

	public function checkAdminExist($username)
    {
        $user_data = $this->administrator_model->checkAdminExist($username);
        if($user_data=="")
        {
            return TRUE;

        }
        return FALSE;
    }
    
    public function updateuser()
    {
		$current_username = $this->session->userdata('administrator_log');
		$administrator_data = $this->administrator_model->administrator($current_username);
		$admin_id = @$administrator_data['0']['user_id'];

        $name = $this->input->post('name');
		$contact = $this->input->post('contact');
		$email = $this->input->post('email');
		$edit_key = $this->input->post('edit_key');
		$user_id = $this->input->post('user_id');
		$updated = $this->administrator_model->updateuser($name, $contact, $email, $edit_key, $user_id, $admin_id);	
		if($updated)
		{
		    echo json_encode(1);
		    die();
		}
		else
		{
		    echo json_encode(2);
		    die();
		}
    }
    
    public function updateemployee()
    {
		$current_username = $this->session->userdata('administrator_log');
		$administrator_data = $this->administrator_model->administrator($current_username);
		$admin_id = @$administrator_data['0']['user_id'];

        $name = $this->input->post('name');
		$contact = $this->input->post('contact');
		$email = $this->input->post('email');
		$user_id = $this->input->post('user_id');
		$vle_id = $this->input->post('vle_id');
		$edit_key = $this->input->post('edit_key');
		$updated = $this->administrator_model->updateemployee($name, $contact, $email, $user_id, $vle_id, $edit_key, $admin_id);	
		if($updated)
		{
		    echo json_encode(1);
		    die();
		}
		else
		{
		    echo json_encode(2);
		    die();
		}
    }
    
    public function retailerchangepassword()
    {
		$current_username = $this->session->userdata('administrator_log');
		$administrator_data = $this->administrator_model->administrator($current_username);
		$admin_id = @$administrator_data['0']['user_id'];

        $new_password = $this->input->post('new_password');
		$user_id = $this->input->post('user_id');
		$updated = $this->administrator_model->retailerchangepassword($new_password, $user_id, $admin_id);	
		if($updated)
		{
		    echo json_encode(1);
		    die();
		}
		else
		{
		    echo json_encode(2);
		    die();
		}
    }
    public function changepassworduserath()
    {
        if($this->input->post('user_id') != NULL && !empty($this->input->post('user_id'))
        && $this->input->post('new_password') != NULL && !empty($this->input->post('new_password')))
        {
            $username = $this->session->userdata('administrator_log');
            $administrator_data = $this->administrator_model->administrator($username);
            
            $user_id = $administrator_data['0']['user_id'];
            
            $users_id = $this->input->post('user_id');
            $new_password = $this->input->post('new_password');
            $passwordupdated = $this->administrator_model->changepassworduserath($users_id, $new_password, $user_id);
           	if($passwordupdated)
            {
                echo json_encode(
                    array("statusCode"=>3, 
                    "Message"=>"Retailer password has been changed successfully!"
                    ));
                die();
            }
            else
            {
                echo json_encode(
                    array("statusCode"=>2, 
                    "Message"=>"Unable to update Password! Try again later"
                    ));
                die();
            }
            
        }
        else
        {
            echo json_encode(
                array("statusCode"=>0, 
                "Message"=>"Something is wrong!, Try again later"
                ));
            die();
        }
    }
    public function changepasswordadminath()
    {
        if($this->input->post('admin_id') != NULL && !empty($this->input->post('admin_id'))
        && $this->input->post('new_password') != NULL && !empty($this->input->post('new_password')))
        {
            $username = $this->session->userdata('administrator_log');
            $administrator_data = $this->administrator_model->administrator($username);
            
            $user_id = $administrator_data['0']['user_id'];
            
            $admin_id = $this->input->post('admin_id');
            $new_password = $this->input->post('new_password');
            $passwordupdated = $this->administrator_model->changepasswordadminath($admin_id, $new_password, $user_id);
           	if($passwordupdated)
            {
                echo json_encode(
                    array("statusCode"=>3, 
                    "Message"=>"Admin password has been changed successfully!"
                    ));
                die();
            }
            else
            {
                echo json_encode(
                    array("statusCode"=>2, 
                    "Message"=>"Unable to update Password! Try again later"
                    ));
                die();
            }
            
        }
        else
        {
            echo json_encode(
                array("statusCode"=>0, 
                "Message"=>"Something is wrong!, Try again later"
                ));
            die();
        }
    }

    public function changepasswordemployeeath()
    {
        if($this->input->post('employee_id') != NULL && !empty($this->input->post('employee_id'))
        && $this->input->post('new_password') != NULL && !empty($this->input->post('new_password')))
        {
            $username = $this->session->userdata('administrator_log');
            $administrator_data = $this->administrator_model->administrator($username);
            
            $user_id = $administrator_data['0']['user_id'];
            
            $employee_id = $this->input->post('employee_id');
            $new_password = $this->input->post('new_password');
            $passwordupdated = $this->administrator_model->changepasswordemployeeath($employee_id, $new_password, $user_id);
            if($passwordupdated)
            {
                echo json_encode(
                    array("statusCode"=>3, 
                    "Message"=>"Employee password has been changed successfully!"
                    ));
                die();
            }
            else
            {
                echo json_encode(
                    array("statusCode"=>2, 
                    "Message"=>"Unable to update Password! Try again later"
                    ));
                die();
            }
            
        }
        else
        {
            echo json_encode(
                array("statusCode"=>0, 
                "Message"=>"Something is wrong!, Try again later"
                ));
            die();
        }
    }

	public function adminchangepassword()
    {
        $new_password = $this->input->post('new_password');
		$user_id = $this->input->post('user_id');
		$updated = $this->administrator_model->adminchangepassword($new_password, $user_id);	
		if($updated)
		{
		    echo json_encode(1);
		    die();
		}
		else
		{
		    echo json_encode(2);
		    die();
		}
    }
    
    public function employeechangepassword()
    {
        $new_password = $this->input->post('new_password');
		$user_id = $this->input->post('user_id');
		$updated = $this->administrator_model->employeechangepassword($new_password, $user_id);	
		if($updated)
		{
		    echo json_encode(1);
		    die();
		}
		else
		{
		    echo json_encode(2);
		    die();
		}
    }
    
    public function administratorchangepassword()
    {
        $new_password = $this->input->post('new_password');
		$user_id = $this->input->post('user_id');
		$updated = $this->administrator_model->administratorchangepassword($new_password, $user_id);	
		if($updated)
		{
		    echo json_encode(1);
		    die();
		}
		else
		{
		    echo json_encode(2);
		    die();
		}
    }

	public function retailerlog()
	{
		if ($this->is_logged_in())
		{
			$username = $this->session->userdata('administrator_log');
			$administrator_data = $this->administrator_model->administrator($username);
			$data['administrator_data'] = $administrator_data['0'];
			$data['retailer_log'] = $this->administrator_model->retailerlog();
			
			$role_id = $administrator_data['0']['role_id'];
            $data['permission_details'] = $this->administrator_model->checkroleexist($role_id);
			$this->load->view('header', $data);
			$this->load->view('retailer_log', $data);
			$this->load->view('footer');
		}
		else
		{
			redirect('/');
		}
	}

	public function updateremark()
	{
		$username = $this->session->userdata('administrator_log');
		$administrator_data = $this->administrator_model->administrator($username);
		$user_id = $administrator_data['0']['user_id'];

		$member_id = $this->input->post('member_id');
		$remark1 = $this->input->post('remark1');
		$remark2 = $this->input->post('remark2');
		$remark3 = $this->input->post('remark3');
		$status = $this->input->post('status');
		
		$retailer_visible_access = $this->input->post('retailer_visible_access');
		$employee_visible_access = $this->input->post('employee_visible_access');
	
		$updated = $this->administrator_model->memberstatusupdate($member_id, $remark1, $remark2, $remark3, $status, $user_id, $retailer_visible_access, $employee_visible_access);
		if($updated)
		{
		    echo json_encode(1);
		    die();
		}
		else
		{
		    echo json_encode(2);
		    die();
		}
	}

	public function removefromemployeeath()
	{
		$member_id = $this->input->post('member_id');
        $username = $this->session->userdata('administrator_log');
		$administrator_data = $this->administrator_model->administrator($username);
		$user_id = $administrator_data['0']['user_id'];
        foreach($member_id as $id)
        {
            $member_id = $id;
            $this->administrator_model->removefromemployeeath($member_id, $user_id);
        }
        echo json_encode(
            array("statusCode"=>2
            ));
        die();
	}

	public function removefromretailerath()
	{
		$member_id = $this->input->post('member_id');
        $username = $this->session->userdata('administrator_log');
		$administrator_data = $this->administrator_model->administrator($username);
		$user_id = $administrator_data['0']['user_id'];
        foreach($member_id as $id)
        {
            $member_id = $id;
            $this->administrator_model->removefromretailerath($member_id, $user_id);
        }
        echo json_encode(
            array("statusCode"=>2
            ));
        die();
	}

    public function rechargecoins()
    {
        if($this->input->post('admin_id') != NULL && !empty($this->input->post('admin_id')) && $this->input->post('coins') != NULL && !empty($this->input->post('coins')))
        {
            $username = $this->session->userdata('administrator_log');
            $admin_id = $this->input->post('admin_id');
            $coins = $this->input->post('coins');
            $administrator_data = $this->administrator_model->administrator($username);
            $user_id = @$administrator_data['0']['user_id'];
            $recharge_added = $this->administrator_model->rechargedone($user_id, $admin_id, $coins);
            if($recharge_added)
            {
                $coinsupdated = $this->administrator_model->updatecoins($admin_id, $coins);
                if($coinsupdated)
                {
            
                    echo json_encode(
                        array("statusCode"=>3, 
                        "Message"=>"Recharge done Successfully!"
                        ));
                    die();
                }
                else
                {
                    echo json_encode(
                        array("statusCode"=>2, 
                        "Message"=>"Something is wrong! Try Again Later!"
                        ));
                    die();
                }
            }
            else
            {
                echo json_encode(
                    array("statusCode"=>1, 
                    "Message"=>"Unable to Recharge! Try again later"
                    ));
                die();
            }
        }
        else
        {
            echo json_encode(
                array("statusCode"=>0, 
                "Message"=>"Something is wrong!, Try again later"
                ));
            die();
        }
    }

    public function searchmemeber()
    {
        if ($this->is_logged_in())
        {
            $username = $this->session->userdata('administrator_log');
            $administrator_data = $this->administrator_model->administrator($username);
            $data['administrator_data'] = $administrator_data['0'];
            
            $role_id = $administrator_data['0']['role_id'];
            $data['permission_details'] = $this->administrator_model->checkroleexist($role_id);
            
            $this->load->view('header', $data);
            $this->load->view('searchmember', $data);
            $this->load->view('footer');
        }
        else
        {
            redirect('/');
        }
    }

    public function searchath()
    {
        $vle_id = $this->input->post('vle_id');
        $memeberdata = $this->administrator_model->searchath($vle_id);
       
        if($memeberdata)
        {
            echo json_encode(
                array("statusCode"=>1, 
                "data"=>$memeberdata['0']
                ));
            die();
        }
        else
        {
            echo json_encode(
                array("statusCode"=>2, 
                "Message"=>"Record Not Found!"
                ));
            die();
        }
    }

    public function rechargecoinswithusername()
    {
        if($this->input->post('admin_username') != NULL && !empty($this->input->post('admin_username')) && $this->input->post('coins') != NULL && !empty($this->input->post('coins')))
        {
            $username = $this->session->userdata('administrator_log');
            $administrator_data = $this->administrator_model->administrator($username);
            $user_id = @$administrator_data['0']['user_id'];
            
            $admin_username = $this->input->post('admin_username');
            $coins = $this->input->post('coins');

            $admin_data = $this->administrator_model->admin($admin_username);
            $admin_id = @$admin_data['0']['id'];
            $recharge_added = $this->administrator_model->rechargedone($user_id, $admin_id, $coins);
            if($recharge_added)
            {
                $coinsupdated = $this->administrator_model->updatecoins($admin_id, $coins);
                if($coinsupdated)
                {
            
                    echo json_encode(
                        array("statusCode"=>3, 
                        "Message"=>"Recharge done Successfully!"
                        ));
                    die();
                }
                else
                {
                    echo json_encode(
                        array("statusCode"=>2, 
                        "Message"=>"Something is wrong! Try Again Later!"
                        ));
                    die();
                }
            }
            else
            {
                echo json_encode(
                    array("statusCode"=>1, 
                    "Message"=>"Unable to Recharge! Try again later"
                    ));
                die();
            }
        }
        else
        {
            echo json_encode(
                array("statusCode"=>0, 
                "Message"=>"Something is wrong!, Try again later"
                ));
            die();
        }
    }
    
    public function admincoinshistory()
    {
        if ($this->is_logged_in())
        {
            $username = $this->session->userdata('administrator_log');
            $administrator_data = $this->administrator_model->administrator($username);
            $data['administrator_data'] = $administrator_data['0'];
            $data['admin_coins'] = $this->administrator_model->admincoinshistory();
            
            $role_id = $administrator_data['0']['role_id'];
            $data['permission_details'] = $this->administrator_model->checkroleexist($role_id);
            $this->load->view('header', $data);
            $this->load->view('admincoinshistory', $data);
            $this->load->view('footer');
        }
        else
        {
            redirect('/');
        }
    }

    public function revertadmincoins()
    {
        if($this->input->post('id') != NULL && !empty($this->input->post('id')) && $this->input->post('coins') != NULL && !empty($this->input->post('coins')))
        {
            $current_username = $this->session->userdata('administrator_log');
            $administrator_data = $this->administrator_model->administrator($current_username);
            $user_id = @$administrator_data['0']['user_id'];
            
            $id = $this->input->post('id');
            $coins = $this->input->post('coins');
            $admin_data = $this->administrator_model->adminbyId($id);
            $admin_id = @$admin_data['admin_id'];
            $coinsupdated = $this->administrator_model->revertadmincoins($id, $coins, $user_id, $admin_id);
            if($coinsupdated)
            {
                echo json_encode(
                    array("statusCode"=>2, 
                    "Message"=>"Status changed successfully!"
                    ));
                die();
            }
            else
            {
                echo json_encode(
                    array("statusCode"=>1, 
                    "Message"=>"Unable to update status! Try again later"
                    ));
                die();
            }
        }
        else
        {
            echo json_encode(
                array("statusCode"=>0, 
                "Message"=>"Something is wrong!, Try again later"
                ));
            die();
        }
    }

    public function retailercoinshistory()
    {
        if ($this->is_logged_in())
        {
            $username = $this->session->userdata('administrator_log');
            $administrator_data = $this->administrator_model->administrator($username);
            $data['administrator_data'] = $administrator_data['0'];
            $data['retailer_coins'] = $this->administrator_model->retailercoinshistory();
            
            $role_id = $administrator_data['0']['role_id'];
            $data['permission_details'] = $this->administrator_model->checkroleexist($role_id);
            // echo "<pre>"; print_r($data); die();
            $this->load->view('header', $data);
            $this->load->view('retailercoinshistory', $data);
            $this->load->view('footer');
        }
        else
        {
            redirect('/');
        }
    }

    public function revertretailercoins()
    {
        if($this->input->post('id') != NULL && !empty($this->input->post('id')) && $this->input->post('coins') != NULL && !empty($this->input->post('coins')))
        {
            $current_username = $this->session->userdata('administrator_log');
            $administrator_data = $this->administrator_model->administrator($current_username);
            $user_id = @$administrator_data['0']['user_id'];
            
            $id = $this->input->post('id');
            $coins = $this->input->post('coins');
            $admin_data = $this->administrator_model->retailerbyId($id);
            $retailer_id = @$admin_data['retailer_id'];
            $coinsupdated = $this->administrator_model->revertretailercoins($id, $coins, $user_id, $retailer_id);
            if($coinsupdated)
            {
                echo json_encode(
                    array("statusCode"=>2, 
                    "Message"=>"Status changed successfully!"
                    ));
                die();
            }
            else
            {
                echo json_encode(
                    array("statusCode"=>1, 
                    "Message"=>"Unable to update status! Try again later"
                    ));
                die();
            }
        }
        else
        {
            echo json_encode(
                array("statusCode"=>0, 
                "Message"=>"Something is wrong!, Try again later"
                ));
            die();
        }
    }
	
	public function chat()
	{
		if ($this->is_logged_in())
		{
			$username = $this->session->userdata('administrator_log');
            $administrator_data = $this->administrator_model->administrator($username);
            $data['administrator_data'] = $administrator_data['0'];
			$role_id = $administrator_data['0']['role_id'];
            $data['permission_details'] = $this->administrator_model->checkroleexist($role_id);
			$chat_data = $this->administrator_model->chatusers();
			$chat_data_users = [];
			foreach($chat_data as $dataa)
			{
				array_push($chat_data_users, $dataa['send_id']);
				array_push($chat_data_users, $dataa['receiver_id']);
			}
			$chat_data_users = array_unique($chat_data_users);
			$chat_data_arr = [];
			foreach($chat_data_users as $dataa)
			{
				if($dataa != "admin")
				{
					$user_details = $this->administrator_model->getUserByUserIds($dataa);
					//echo "<pre>"; print_r($user_details); die();
					$chat_details = $this->administrator_model->getLatestChatByUserId($dataa);
					if($chat_details)
					{
						$message_date = $chat_details['0']['created_date'];
						if($chat_details['0']['content_type'] == "2")
						{
							$message = "Image";
						}
						else
						{
							$message = $chat_details['0']['chat_content'];
						}
					}
					if($user_details['profile'] == "")
					{
						$profile = "profile.png";
					}
					array_push($chat_data_arr, array("user_id"=>$user_details['user_id'],"name"=>$user_details['username'], "profile"=>$profile, "message"=>$message, "message_date"=>$message_date));
				}
			}
			$data['chat_conent'] = $this->administrator_model->getChatByUserId($chat_data_users['0']);
			$data['chat_data'] = $chat_data_arr;
			$this->load->view('header', $data);
			$this->load->view('chat', $data);
			$this->load->view('footer');
		}
		else
		{
			redirect('/');
		}
	}

	public function sendmessage()
	{
	    $user_id = $this->input->post('user_id');
	    $text_message = $this->input->post('text_message');
	    $sent = $this->administrator_model->sendmessage($user_id, $text_message);
	    if($sent)
	    {
	        echo json_encode(1); die();
	    }
	    else
	    {
	        echo json_encode(0); die();
	    }
	}

	public function getchathistory()
	{
		$user_id = $this->input->post('user_id');
		$chatdata = $this->administrator_model->getChatByUserIds($user_id);
		$chatdatas = [];
		foreach($chatdata as $data)
		{
		    $data['created_date'] = date_format(date_create($data['created_date']), "M").", ".date_format(date_create($data['created_date']), "h:i a"); 
		    array_push($chatdatas, $data);
		}
		$user_details = $this->administrator_model->getUserByUserIdss($user_id);
		echo json_encode(array($chatdatas, $user_details)); die();
	}
}


