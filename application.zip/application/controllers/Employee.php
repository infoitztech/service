<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Employee extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an- underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct()
    {
        parent::__construct();
    }

	public function is_logged_in()
    {
        $user = $this->session->userdata('employee_log');
        return isset($user);
    }

	public function index()
	{
		$this->load->view('employee/login');
	}

	public function logout()
	{
		$this->session->sess_destroy();
		redirect('employee');
	}

	public function loginAuthentication()
    {
        if($this->input->post('username') != NULL && !empty($this->input->post('username')) 
        && $this->input->post('password') != NULL  && !empty($this->input->post('password'))
        )
        {
            $username = $this->input->post('username');
            $password = $this->input->post('password');
            $loginAuthenticationData = $this->Retailer_model->logineAuthentication($username, $password);
            if($loginAuthenticationData != NULL && !empty($loginAuthenticationData))
            {
                if($loginAuthenticationData['status'] != NULL && !empty($loginAuthenticationData['status']) && $loginAuthenticationData['status'] == 1)
                {
                    $this->Retailer_model->employeeLoginLog($loginAuthenticationData['id']);                    
                    $this->session->set_userdata('employee_log', $loginAuthenticationData['username']);
                    echo json_encode(
                        array("statusCode"=>1, 
                        "Message"=>"Correct Username & Password. Now you are proceeding to the Dashboard!"
                        ));
                    die();
                }
                else
                {
                    echo json_encode(
                        array("statusCode"=>2, 
                        "Message"=>"Your profile has been Blocked!"
                        ));
                    die();
                }
            }
            else
            {
                echo json_encode(
                    array("statusCode"=>3, 
                    "Message"=>"Incorrect Username & Password!"
                    ));
                die();
            }
        }
        else
        {
            echo json_encode(
                array("statusCode"=>0, 
                "Message"=>"Something is wrong!, Try again later"
                ));
            die();
        }
    }

	public function dashboard()
	{
		if ($this->is_logged_in())
		{
			$username = $this->session->userdata('employee_log');
			$employee_data = $this->Retailer_model->employee($username);
			$data['employee_data'] = $employee_data;
			$this->load->view('employee/header', $data);
			$this->load->view('employee/dashboard');
			$this->load->view('employee/footer');
		}
		else
		{
			redirect('/');
		}
	}

  
    public function fingerprints()
    {
//         if ($this->is_logged_in())
// 		{
            $student_id = $this->input->get('student');
            $username = $this->session->userdata('employee_log');
            $employee_data = $this->Retailer_model->user($username);
            $data['employee_data'] = $employee_data;
            $data['student_finger_data'] = $this->Retailer_model->studentsfingers($student_id);
            // echo "<pre>";
            // print_r($data); die();
           // $this->load->view('retailer/header', $data);
            $this->load->view('employee/fingerprints', $data);
           // $this->load->view('retailer/footer');
// 		}
// 		else
// 		{
// 			redirect('/');
// 		}
    }

    public function changepassword()
    {
        if ($this->is_logged_in())
		{
			$username = $this->session->userdata('employee_log');
			$employee_data = $this->Retailer_model->employee($username);
			$data['employee_data'] = $employee_data;
			$this->load->view('employee/header', $data);
			$this->load->view('employee/changepassword');
			$this->load->view('employee/footer');
		}
		else
		{
			redirect('/');
		}
    }

    public function changepasswordAth()
    {
        if($this->input->post('old_password') != NULL && !empty($this->input->post('old_password'))
        && $this->input->post('new_password') != NULL && !empty($this->input->post('new_password')))
        {
            $username = $this->session->userdata('employee_log');
            $old_password = $this->input->post('old_password');
            $new_password = $this->input->post('new_password');
            $oldpasswordexistance = $this->Retailer_model->checkoldpasswords($username, $old_password);
            if($oldpasswordexistance)
            {
                $passwordupdated = $this->Retailer_model->changepasswordAths($username, $new_password);
                if(!$passwordupdated)
                {
                    echo json_encode(
                        array("statusCode"=>3, 
                        "Message"=>"Your password has been changed successfully!"
                        ));
                    die();
                }
                else
                {
                    echo json_encode(
                        array("statusCode"=>2, 
                        "Message"=>"Unable to update profile! Try again later"
                        ));
                    die();
                }
            }
            else
            {
                echo json_encode(
                    array("statusCode"=>1, 
                    "Message"=>"Your entered old password is wrong!"
                    ));
                die();
            }
        }
        else
        {
            echo json_encode(
                array("statusCode"=>0, 
                "Message"=>"Something is wrong!, Try again later"
                ));
            die();
        }
    }

    public function searchmemeber()
    {
        if ($this->is_logged_in())
		{
			$username = $this->session->userdata('employee_log');
			$employee_data = $this->Retailer_model->employee($username);
			$data['employee_data'] = $employee_data;
			$this->load->view('employee/header', $data);
			$this->load->view('employee/searchmemeber');
			$this->load->view('employee/footer');
		}
		else
		{
			redirect('/');
		}
    }

    public function searchath()
    {
        $vle_id = $this->input->post('vle_id');
        $memeberdata = $this->Retailer_model->searchath($vle_id);
        if($memeberdata)
        {
            echo json_encode(
                array("statusCode"=>1, 
                "data"=>$memeberdata['0']
                ));
            die();
        }
        else
        {
            echo json_encode(
                array("statusCode"=>2, 
                "Message"=>"Record Not Found!"
                ));
            die();
        }
    }

    public function updateremark()
    {
        $username = $this->session->userdata('employee_log');
		$employee_data = $this->Retailer_model->employee($username);
		$data['employee_data'] = $employee_data;
        $member_id = $this->input->post('member_id');
        $remark2 = $this->input->post('remark2');
        $status = $this->input->post('status');
        $updated = $this->Retailer_model->updateremark($remark2, $member_id, $status, $employee_data['username']);
        if($updated)
        {
            echo json_encode(
                array("statusCode"=>1, 
                "Message"=>"Remark Updated Successfully!"
                ));
            die();
        }
        else
        {
            echo json_encode(
                array("statusCode"=>2, 
                "Message"=>"Something is wrong! Try again later"
                ));
            die();
        }
    }

    public function myfinger()
    {
        $user_id = $this->input->get('user_id'); 
        $employee_data = $this->Retailer_model->getemployeebyid($user_id);
        if($employee_data)
        {
            $member_data = $this->Retailer_model->getmemberbyvleid($employee_data['vle_id']);
            if($member_data)
            {
                $data['student_finger_data'] = $member_data;
                $this->load->view('employee/myfinger', $data);
            }
            else
            {
                echo "<h1>My Data not addedds</h1>";
            }
            
        }
        else
        {
            echo "<h1>My Data not addedds</h1>";
        }
    }
}

