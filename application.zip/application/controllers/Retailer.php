<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Retailer extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an- underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct()
    {
        parent::__construct();
    }

	public function is_logged_in()
    {
        $user = $this->session->userdata('retailer_log');
        return isset($user);
    }

	public function index()
	{
// 		$this->load->view('retailer/login');
		$this->load->view('error.php');
	}

	public function logout()
	{
		$this->session->sess_destroy();
		redirect('/');
	}

	public function loginAuthentication()
    {
        if($this->input->post('username') != NULL && !empty($this->input->post('username')) 
        && $this->input->post('password') != NULL  && !empty($this->input->post('password'))
        )
        {
            $username = $this->input->post('username');
            $password = $this->input->post('password');
            $loginAuthenticationData = $this->Retailer_model->loginAuthentication($username, $password);
            if($loginAuthenticationData != NULL && !empty($loginAuthenticationData))
            {
                if($loginAuthenticationData['status'] != NULL && !empty($loginAuthenticationData['status']) && $loginAuthenticationData['status'] == 1)
                {
                    $this->Retailer_model->retailerLoginLog($loginAuthenticationData['user_id']);                    
                    $this->session->set_userdata('retailer_log', $loginAuthenticationData['username']);
                    echo json_encode(
                        array("statusCode"=>1, 
                        "Message"=>"Correct Username & Password. Now you are proceeding to the Dashboard!"
                        ));
                    die();
                }
                else
                {
                    echo json_encode(
                        array("statusCode"=>2, 
                        "Message"=>"Your profile has been Blocked!"
                        ));
                    die();
                }
            }
            else
            {
                echo json_encode(
                    array("statusCode"=>3, 
                    "Message"=>"Incorrect Username & Password!"
                    ));
                die();
            }
        }
        else
        {
            echo json_encode(
                array("statusCode"=>0, 
                "Message"=>"Something is wrong!, Try again later"
                ));
            die();
        }
    }

	public function dashboard()
	{
		if ($this->is_logged_in())
		{
			$username = $this->session->userdata('retailer_log');
			$data['retailer_data'] = $this->Retailer_model->user($username);

            $retailer_coins = $this->Retailer_model->coinscount($data['retailer_data']['user_id']);
            $data['total_coins'] = @$retailer_coins['0']->coins;
            // echo "<pre>"; print_r($data); die();
            
			$this->load->view('retailer/header', $data);
			$this->load->view('retailer/dashboard');
			$this->load->view('retailer/footer');
		}
		else
		{
			redirect('/');
		}
	}

    public function createmember()
    {
        if ($this->is_logged_in())
		{
			$username = $this->session->userdata('retailer_log');
			$retailer_data = $this->Retailer_model->user($username);
			$data['retailer_data'] = $retailer_data;
			$this->load->view('retailer/header', $data);
			$this->load->view('retailer/createstudent');
			$this->load->view('retailer/footer');
		}
		else
		{
			redirect('/');
		}
    }

    public function createstudentath()
    {
        $username = $this->session->userdata('retailer_log');
		$retailer_data = $this->Retailer_model->user($username);
        $retailer_id  = $retailer_data['user_id'];
        $admin_id  = $retailer_data['admin'];
        
        $vle_id = $this->input->post('vle_id');
        $name = $this->input->post('name');
        $contact = $this->input->post('contact');
        $dob = $this->input->post('dob');
        $purpose = $this->input->post('purpose');
        $adhaar_no = $this->input->post('adhaar_no');
        $type = $this->input->post('type');
        $remark1 = $this->input->post('remark1');
        $student = $this->RetailerApi_model->checkstudentexist($name);
        if(!$student)
        {
            if($this->input->post("photo1"))
            {
                $filename1 = $this->insertfingerprint($this->input->post("photo1"));
            }
            else
            {
                $filename1 = "";
            }

            if($this->input->post("photo2"))
            {
                $filename2 = $this->insertfingerprint($this->input->post("photo2"));
            }
            else
            {
                $filename2 = "";
            }

            if($this->input->post("photo3"))
            {
                $filename3 = $this->insertfingerprint($this->input->post("photo3"));
            }
            else
            {
                $filename3 = "";
            }

            if($this->input->post("photo4"))
            {
                $filename4 = $this->insertfingerprint($this->input->post("photo4"));
            }
            else
            {
                $filename4 = "";
            }
            
            if($this->input->post("photo5"))
            {
                $filename5 = $this->insertfingerprint($this->input->post("photo5"));
            }
            else
            {
                $filename5 = "";
            }
            $studentadded = $this->RetailerApi_model->addstudent($retailer_id, $vle_id, $name, $contact, $dob, $purpose, $adhaar_no, $type, $remark1, $filename1, $filename2, $filename3, $filename4, $filename5, $admin_id);
            if($studentadded)
            {
                $this->RetailerApi_model->studentcreatedLog($retailer_id, $name);
                echo json_encode(
                    array("statusCode"=>1
                    ));
                die();
            }
            else
            {
                echo json_encode(
                    array("statusCode"=>2
                    ));
                die();
            }
        }
        else
        {
            echo json_encode(
                array("statusCode"=>3
                ));
            die();
        }
    }

    public function insertfingerprint($image)
    {
        if (!defined('UPLOAD_DIR')) define('UPLOAD_DIR', 'upload/student/fingerprint/');
        $image_parts = explode(";base64,", $image);
        $image_type_aux = explode("image/", $image_parts[0]);
        $image_type = $image_type_aux[1];
        $image_base64 = base64_decode($image_parts[1]);
        $file = UPLOAD_DIR . uniqid() . '.png';
        file_put_contents($file, $image_base64);
        return $file;
    }

    public function students()
	{
        if ($this->is_logged_in())
		{
			$username = $this->session->userdata('retailer_log');
            $retailer_data = $this->Retailer_model->user($username);
            $data['retailer_data'] = $retailer_data;
            $retailer_id  = $retailer_data['user_id'];
            $data['studentdata_data'] = $this->Retailer_model->students($retailer_id);
            $this->load->view('retailer/header', $data);
            $this->load->view('retailer/students', $data);
            $this->load->view('retailer/footer');
		}
		else
		{
			redirect('/');
		}
	}

    public function fingerprints()
    {
        $student_id = $this->input->get('student');
        $username = $this->session->userdata('retailer_log');
        $retailer_data = $this->Retailer_model->user($username);
        $data['retailer_data'] = $retailer_data;
        $data['student_finger_data'] = $this->Retailer_model->studentsfingers($student_id);
        // echo "<pre>";
        // print_r($data); die();
       // $this->load->view('retailer/header', $data);
        $this->load->view('retailer/fingerprints', $data);
       // $this->load->view('retailer/footer');
    }

    public function changepassword()
    {
        if ($this->is_logged_in())
		{
			$username = $this->session->userdata('retailer_log');
			$retailer_data = $this->Retailer_model->user($username);
			$data['retailer_data'] = $retailer_data;
			$this->load->view('retailer/header', $data);
			$this->load->view('retailer/changepassword');
			$this->load->view('retailer/footer');
		}
		else
		{
			redirect('/');
		}
    }

    public function changepasswordAth()
    {
        if($this->input->post('old_password') != NULL && !empty($this->input->post('old_password'))
        && $this->input->post('new_password') != NULL && !empty($this->input->post('new_password')))
        {
            $username = $this->session->userdata('retailer_log');
            $old_password = $this->input->post('old_password');
            $new_password = $this->input->post('new_password');
            $oldpasswordexistance = $this->Retailer_model->checkoldpassword($username, $old_password);
            if($oldpasswordexistance)
            {
                $passwordupdated = $this->Retailer_model->changepasswordAth($username, $new_password);
                if(!$passwordupdated)
                {
                    echo json_encode(
                        array("statusCode"=>3, 
                        "Message"=>"Your password has been changed successfully!"
                        ));
                    die();
                }
                else
                {
                    echo json_encode(
                        array("statusCode"=>2, 
                        "Message"=>"Unable to update profile! Try again later"
                        ));
                    die();
                }
            }
            else
            {
                echo json_encode(
                    array("statusCode"=>1, 
                    "Message"=>"Your entered old password is wrong!"
                    ));
                die();
            }
        }
        else
        {
            echo json_encode(
                array("statusCode"=>0, 
                "Message"=>"Something is wrong!, Try again later"
                ));
            die();
        }
    }

    public function memberlist()
    {
        if ($this->is_logged_in())
		{
			$username = $this->session->userdata('retailer_log');
			$retailer_data = $this->Retailer_model->user($username);
			$data['retailer_data'] = $retailer_data;
            $retailer_id  = $retailer_data['user_id'];
            $data['studentdata_data'] = $this->Retailer_model->students($retailer_id);
			$this->load->view('retailer/header', $data);
			$this->load->view('retailer/students');
			$this->load->view('retailer/footer');
		}
		else
		{
			redirect('/');
		}
    }

    public function chat()
    {
        $user_id = $this->input->get('user_id');
        $chatcontent = $this->Retailer_model->getChatByUserId($user_id);
        $chatdata = [];
        foreach($chatcontent as $dataa)
        {
            $dataa['created_date'] = date_format(date_create($dataa['created_date']), "M").", ".date_format(date_create($dataa['created_date']), "H:i");
            array_push($chatdata, $dataa);
        }
        $data['chat_content'] = $chatdata;
        $this->load->view('retailer/chat', $data);
    }
    
    public function sendmessage()
    {
        $user_id = $this->input->post('user_id');
        $text_message = $this->input->post('text_message');
        $added = $this->Retailer_model->sendmessage($user_id, $text_message);   
        if($added)
        {
            echo json_encode(1); die();
        }
        else
        {
            echo json_encode(0); die();
        }
    }
}

