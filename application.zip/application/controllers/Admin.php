<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an- underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct()
    {
        parent::__construct();
    }

	public function is_logged_in()
    {
        $user = $this->session->userdata('admin_log');
        return isset($user);
    }

	public function index()
	{
		$this->load->view('admin/login');
	}

	public function forgetpassword()
	{
		$this->load->view('forgetpassword');
	}

	public function logout()
	{
		$this->session->sess_destroy();
		redirect('/admin');
	}

	public function loginAuthentication()
    {
        if($this->input->post('username') != NULL && !empty($this->input->post('username')) 
        && $this->input->post('password') != NULL  && !empty($this->input->post('password'))
        )
        {
            $username = $this->input->post('username');
            $password = $this->input->post('password');
            $loginAuthenticationData = $this->admin_model->loginAuthentication($username, $password);
            if($loginAuthenticationData != NULL && !empty($loginAuthenticationData))
            {
                if($loginAuthenticationData['status'] != NULL && !empty($loginAuthenticationData['status']) && $loginAuthenticationData['status'] == 1)
                {
                    $this->session->set_userdata('admin_log', $loginAuthenticationData['username']);
                    $this->admin_model->adminLoginLog($loginAuthenticationData['id']);
                    echo json_encode(
                        array("statusCode"=>1, 
                        "Message"=>"Correct Username & Password. Now you are proceeding to the Dashboard!"
                        ));
                    die();
                }
                else
                {
                    echo json_encode(
                        array("statusCode"=>2, 
                        "Message"=>"Your profile has been Blocked!"
                        ));
                    die();
                }
            }
            else
            {
                echo json_encode(
                    array("statusCode"=>3, 
                    "Message"=>"Incorrect Username & Password!"
                    ));
                die();
            }
        }
        else
        {
            echo json_encode(
                array("statusCode"=>0, 
                "Message"=>"Something is wrong!, Try again later"
                ));
            die();
        }
    }

	public function dashboard()
	{
		if ($this->is_logged_in())
		{
			$username = $this->session->userdata('admin_log');
			$data['admin_data'] = $this->admin_model->admin($username);

            $usersdata = $this->admin_model->userscount($data['admin_data']['id']);
            $data['total_users'] = @$usersdata['0']->users;
            
            $studentdata = $this->admin_model->studentcount($data['admin_data']['id']);
            $data['total_students'] = @$studentdata['0']->users;

            $admin_coins = $this->admin_model->coinscount($data['admin_data']['id']);
            $data['total_coins'] = @$admin_coins['0']->coins;
        
			$this->load->view('admin/header', $data);
			$this->load->view('admin/dashboard', $data);
			$this->load->view('admin/footer');
		}
		else
		{
			redirect('/');
		}
	}

	public function changepassword()
	{
		if ($this->is_logged_in())
		{
			$username = $this->session->userdata('admin_log');
			$data['admin_data'] = $this->admin_model->admin($username);
			$this->load->view('admin/header', $data);
			$this->load->view('admin/changepassword', $data);
			$this->load->view('admin/footer');
		}
		else
		{
			redirect('/');
		}
	}

	public function changepasswordAth()
    {
        if($this->input->post('old_password') != NULL && !empty($this->input->post('old_password'))
        && $this->input->post('new_password') != NULL && !empty($this->input->post('new_password')))
        {
            $username = $this->session->userdata('admin_log');
            $old_password = $this->input->post('old_password');
            $new_password = $this->input->post('new_password');
            $oldpasswordexistance = $this->admin_model->checkoldpassword($username, $old_password);
            if($oldpasswordexistance)
            {
                $admin_data = $this->admin_model->admin($username);
                $user_id = @$admin_data['id'];
                $passwordupdated = $this->admin_model->changepasswordAth($user_id, $new_password);
                if($passwordupdated)
                {
                    echo json_encode(
                        array("statusCode"=>3, 
                        "Message"=>"Your password has been changed successfully!"
                        ));
                    die();
                }
                else
                {
                    echo json_encode(
                        array("statusCode"=>2, 
                        "Message"=>"Unable to update profile! Try again later"
                        ));
                    die();
                }
            }
            else
            {
                echo json_encode(
                    array("statusCode"=>1, 
                    "Message"=>"Your entered old password is wrong!"
                    ));
                die();
            }
        }
        else
        {
            echo json_encode(
                array("statusCode"=>0, 
                "Message"=>"Something is wrong!, Try again later"
                ));
            die();
        }
    }

	public function profile()
	{
		if ($this->is_logged_in())
		{
			$username = $this->session->userdata('admin_log');
			$data['admin_data'] = $this->admin_model->admin($username);
			$this->load->view('admin/header', $data);
			$this->load->view('admin/profile', $data);
			$this->load->view('admin/footer');
		}
		else
		{
			redirect('/');
		}
	}

	public function updateprofile()
	{
		if($this->input->post('user_id') != NULL && !empty($this->input->post('user_id')))
		{
			$current_username = $this->session->userdata('admin_log');
            $admin_data = $this->admin_model->admin($current_username);
            $user_id = $admin_data['id'];
			$name = $this->input->post('name');
			$email = $this->input->post('email');
			$phone = $this->input->post('phone');
			$config['upload_path']="upload/administrator/profilephoto";
			$config['allowed_types']='jpg|png';
			$config['encrypt_name'] = TRUE;
			$upload_file = "";
			$this->load->library('upload',$config);
			if($this->upload->do_upload("profile-photo"))
			{
	        	$data = array('upload_data' => $this->upload->data());
				$upload_file = $data['upload_data']['file_name'];
			}
			$profileupdated = $this->admin_model->updateprofile($user_id, $name, $email, $phone, $upload_file);
			if($profileupdated)
			{
				echo json_encode(
					array("statusCode"=>1, 
					"Message"=>"Profile Updated successfully"
					));
				die();
			}
			else
			{
				echo json_encode(
					array("statusCode"=>2, 
					"Message"=>"Unable to update your profile! Try again later"
					));
				die();
			}
		}
		else
		{
			echo json_encode(
                array("statusCode"=>0, 
                "Message"=>"Something is wrong! Try again later"
                ));
            die();
		}
	}

	public function createuser()
	{
		if ($this->is_logged_in())
		{
			$username = $this->session->userdata('admin_log');
			$data['admin_data'] = $this->admin_model->admin($username);
			$this->load->view('admin/header', $data);
			$this->load->view('admin/create_user', $data);
			$this->load->view('admin/footer');
		}
		else
		{
			redirect('/');
		}
	}

	public function searchuser()
	{
		if ($this->is_logged_in())
		{
			$username = $this->session->userdata('admin_log');
			$data['admin_data'] = $this->admin_model->admin($username);
			$this->load->view('admin/header', $data);
			$this->load->view('admin/create_user', $data);
			$this->load->view('admin/footer');
		}
		else
		{
			redirect('/');
		}
	}
	public function createemployee()
	{
		if ($this->is_logged_in())
		{
			$username = $this->session->userdata('admin_log');
			$data['admin_data'] = $this->admin_model->admin($username);
			$this->load->view('admin/header', $data);
			$this->load->view('admin/create_employee', $data);
			$this->load->view('admin/footer');
		}
		else
		{
			redirect('/');
		}
	}

	public function createretailerath()
	{ 
		if($this->input->post('name') != NULL && !empty($this->input->post('name'))
		&& $this->input->post('username') != NULL && !empty($this->input->post('username'))
		&& $this->input->post('password') != NULL && !empty($this->input->post('password')))
		{ 
			$config['upload_path']="upload/user/profilephoto";
			$config['allowed_types']='jpeg|jpg|png';
			$config['encrypt_name'] = TRUE;
			$this->load->library('upload',$config);

			$current_username = $this->session->userdata('admin_log');
			$admin_data = $this->admin_model->admin($current_username);
			$user_id = $admin_data['id'];

			$name = $this->input->post('name');
			$contact = $this->input->post('contact');
			$email = $this->input->post('email');
			$username = $this->input->post('username');
			$password = $this->input->post('password');
	
			if($this->checkRetailerExist($username))
			{
				if(strlen($password) >= 8)
				{
					if($this->passwordValidation($password))
					{
						$profile = "";
						if($this->upload->do_upload("profile-photo"))
						{
							$data = array('upload_data' => $this->upload->data());
							$profile= $data['upload_data']['file_name']; 
						}
						$adminAdded = $this->admin_model->createretailer($name, $contact, $email, $username, $password, $profile, $user_id);
						if($adminAdded)
						{
							echo json_encode(
								array("statusCode"=>5, 
								"Message"=>"New Retailer has been created successfully!"
								));
							die();
						}
						else
						{
							echo json_encode(
								array("statusCode"=>4, 
								"Message"=>"Unable to create Retailer! Try again later"
								));
							die();
						}
					}
					else
					{
						echo json_encode(
							array("statusCode"=>3, 
							"Message"=>"Password must be alphanumeric!"
							));
						die();
					}
				}
				else
				{
					echo json_encode(
						array("statusCode"=>2, 
						"Message"=>"Password must be minimum 8 characters!"
						));
					die();
				}
			}
			else
			{
				echo json_encode(
					array("statusCode"=>1, 
					"Message"=>"Username already exists!"
					));
				die();
			}
		}
		else
		{
			echo json_encode(
				array("statusCode"=>1, 
				"Message"=>"Something is wrong!, Try again later"
				));
			die();
		}
	}

	public function createemployeeath()
	{ 
		if($this->input->post('name') != NULL && !empty($this->input->post('name'))
		&& $this->input->post('status') != NULL && !empty($this->input->post('status'))
		&& $this->input->post('username') != NULL && !empty($this->input->post('username'))
		&& $this->input->post('password') != NULL && !empty($this->input->post('password')))
		{ 
			$config['upload_path']="upload/employee/profilephoto";
			$config['allowed_types']='jpeg|jpg|png';
			$config['encrypt_name'] = TRUE;
			$this->load->library('upload',$config);

			$current_username = $this->session->userdata('admin_log');
			$admin_data = $this->admin_model->admin($current_username);
			$user_id = $admin_data['id'];

			$name = $this->input->post('name');
			$contact = $this->input->post('contact');
			$email = $this->input->post('email');
			$status = $this->input->post('status');
			$username = $this->input->post('username');
			$password = $this->input->post('password');
	
			if($this->checkEmployeeExist($username))
			{
				if(strlen($password) >= 8)
				{
					if($this->passwordValidation($password))
					{
						$profile = "";
						if($this->upload->do_upload("profile-photo"))
						{
							$data = array('upload_data' => $this->upload->data());
							$profile= $data['upload_data']['file_name']; 
						}
						$adminAdded = $this->admin_model->createemployee($name, $contact, $email, $status, $username, $password, $profile, $user_id);
						if($adminAdded)
						{
							echo json_encode(
								array("statusCode"=>5, 
								"Message"=>"New Employee has been created successfully!"
								));
							die();
						}
						else
						{
							echo json_encode(
								array("statusCode"=>4, 
								"Message"=>"Unable to create Employee! Try again later"
								));
							die();
						}
					}
					else
					{
						echo json_encode(
							array("statusCode"=>3, 
							"Message"=>"Password must be alphanumeric!"
							));
						die();
					}
				}
				else
				{
					echo json_encode(
						array("statusCode"=>2, 
						"Message"=>"Password must be minimum 8 characters!"
						));
					die();
				}
			}
			else
			{
				echo json_encode(
					array("statusCode"=>1, 
					"Message"=>"Username already exists!"
					));
				die();
			}
		}
		else
		{
			echo json_encode(
				array("statusCode"=>1, 
				"Message"=>"Something is wrong!, Try again later"
				));
			die();
		}
	}

	public function checkRetailerExist($username)
	{
		$user_data = $this->admin_model->checkRetailerExist($username);
        if($user_data=="")
        {
            return TRUE;

        }
        return FALSE;
	}

	public function checkEmployeeExist($username)
	{
		$user_data = $this->admin_model->checkEmployeeExist($username);
        if($user_data=="")
        {
            return TRUE;

        }
        return FALSE;
	}

	public function passwordValidation($password)
    {
        if (preg_match('#[0-9]#', $password) && preg_match('#[a-zA-Z]#', $password)) 
        {
            return TRUE;
        }
        return FALSE;
    }

	public function users()
	{
		if ($this->is_logged_in())
		{
			$username = $this->session->userdata('admin_log');
			$data['admin_data'] = $this->admin_model->admin($username);
	
			$data['user_data'] = $this->admin_model->users($data['admin_data']['id']);
			$this->load->view('admin/header', $data);
			$this->load->view('admin/users', $data);
			$this->load->view('admin/footer');
		}
		else
		{
			redirect('/');
		}
	}

	public function employees()
	{
		if ($this->is_logged_in())
		{
			$username = $this->session->userdata('admin_log');
			$data['admin_data'] = $this->admin_model->admin($username);
	
			$data['user_data'] = $this->admin_model->employees($data['admin_data']['id']);
			$this->load->view('admin/header', $data);
			$this->load->view('admin/employees', $data);
			$this->load->view('admin/footer');
		}
		else
		{
			redirect('/');
		}
	}

	public function deleteUser()
	{
		if($this->input->post('id') != NULL && !empty($this->input->post('id')))
        {
			$current_username = $this->session->userdata('admin_log');
            $admin_data = $this->admin_model->admin($current_username);
            $user_id = $admin_data['id'];
            
			$retailer_id = $this->input->post('id');
			$user_details = $this->admin_model->getRetailerByUserId($retailer_id);
			$username = @$user_details['email'];
			$statusUpdated = $this->admin_model->deleteRetailer($retailer_id, $user_id, $username);
			if($statusUpdated)
			{
				echo json_encode(
					array("statusCode"=>2, 
					"Message"=>"Retailer has been Deleted successfully!"
					));
				die();
			}
			else
			{
				echo json_encode(
					array("statusCode"=>1, 
					"Message"=>"Unable to Delete this Retailer! Try again later"
					));
				die();
			}
		}
		else
		{
			echo json_encode(
                array("statusCode"=>0, 
                "Message"=>"Something is wrong!, Try again later"
                ));
            die();
		}
	}

	public function changeViewStatus()
	{
		if($this->input->post('id') != NULL && !empty($this->input->post('id')))
        {
			$current_username = $this->session->userdata('admin_log');
            $admin_data = $this->admin_model->admin($current_username);
            $admin_id = $admin_data['id'];
            
			$user_id = $this->input->post('id');
			$status_id = $this->input->post('status_id');
			$user_status = "";
			if($status_id =="1")
			{
				$user_status = "Activated";
			}
			else if($status_id =="0")
			{
				$user_status = "Deactivated";
			}
			$statusUpdated = $this->admin_model->changeViewStatus($status_id, $user_id, $admin_id);
			if($statusUpdated)
			{
				echo json_encode(
					array("statusCode"=>2, 
					"Message"=>"User has been ".$user_status." successfully!"
					));
				die();
			}
			else
			{
				echo json_encode(
					array("statusCode"=>1, 
					"Message"=>"Unable to update status! Try again later"
					));
				die();
			}
		}
		else
		{
			echo json_encode(
                array("statusCode"=>0, 
                "Message"=>"Something is wrong!, Try again later"
                ));
            die();
		}
	}

	public function students()
	{
		if ($this->is_logged_in())
		{
			$retailer = $this->input->get('retailer');
			$username = $this->session->userdata('admin_log');
			$data['admin_data'] = $this->admin_model->admin($username);
			$data['student_data'] = $this->Retailer_model->students($retailer);
		
			$this->load->view('admin/header', $data);
			$this->load->view('admin/students', $data);
			$this->load->view('admin/footer');
		}
		else
		{
			redirect('/');
		}
	}

	public function fingerprints()
    {
		if ($this->is_logged_in())
		{
			$student_id = $this->input->get('student');
			$username = $this->session->userdata('admin_log');
			$data['student_finger_data'] = $this->Retailer_model->studentsfingers($student_id);
			$this->load->view('admin/fingerprints', $data);
		}
		else
		{
			redirect('/');
		}
    }

    public function rechargecoins()
    {
        if($this->input->post('retailer_id') != NULL && !empty($this->input->post('retailer_id')) && $this->input->post('coins') != NULL && !empty($this->input->post('coins')))
        {
            $retailer_id = $this->input->post('retailer_id');
            $coins = $this->input->post('coins');
            $current_username = $this->session->userdata('admin_log');
            $admin_data = $this->admin_model->admin($current_username);
            $admin_id = $admin_data['id'];
            $admin_coins = $admin_data['coins'];
            if($admin_coins >= $coins)
            {
            	$recharge_added = $this->admin_model->rechargedone($admin_id, $retailer_id, $coins);
	            if($recharge_added)
	            {
	                $coinsupdated = $this->admin_model->updatecoins($retailer_id, $coins);
	                if($coinsupdated)
	                {
	            
	                    echo json_encode(
	                        array("statusCode"=>3, 
	                        "Message"=>"Recharge done Successfully!"
	                        ));
	                    die();
	                }
	                else
	                {
	                    echo json_encode(
	                        array("statusCode"=>2, 
	                        "Message"=>"Something is wrong! Try Again Later!"
	                        ));
	                    die();
	                }
	            }
	            else
	            {
	                echo json_encode(
	                    array("statusCode"=>1, 
	                    "Message"=>"Unable to Recharge! Try again later"
	                    ));
	                die();
	            }
            }
            else
            {
            	echo json_encode(
	                array("statusCode"=>4, 
	                "Message"=>"Admin Don't have sufficient balance! Try Again Later!"
	                ));
	            die();
            }
        }
        else
        {
            echo json_encode(
                array("statusCode"=>0, 
                "Message"=>"Something is wrong!, Try again later"
                ));
            die();
        }
    }

    public function rechargecoinswithusername()
    {
        if($this->input->post('retailer_username') != NULL && !empty($this->input->post('retailer_username')) && $this->input->post('coins') != NULL && !empty($this->input->post('coins')))
        {
            $retailer_username = $this->input->post('retailer_username');
            $coins = $this->input->post('coins');
            $current_username = $this->session->userdata('admin_log');
            $admin_data = $this->admin_model->admin($current_username);
            $admin_id = $admin_data['id'];
            $admin_coins = $admin_data['coins'];
            if($admin_coins >= $coins)
            {
            	$retailer_data = $this->admin_model->retailer($retailer_username);
            	$retailer_id = @$retailer_data['0']['user_id'];
            
            	$recharge_added = $this->admin_model->rechargedone($admin_id, $retailer_id, $coins);
	            if($recharge_added)
	            {
	                $coinsupdated = $this->admin_model->updatecoins($retailer_id, $coins);
	                $admincoinsupdated = $this->admin_model->updateadmincoins($admin_id, $coins);
	                if($coinsupdated && $admincoinsupdated)
	                {
	                    echo json_encode(
	                        array("statusCode"=>3, 
	                        "Message"=>"Recharge done Successfully!"
	                        ));
	                    die();
	                }
	                else
	                {
	                    echo json_encode(
	                        array("statusCode"=>2, 
	                        "Message"=>"Unable to Recharge! Try again later!"
	                        ));
	                    die();
	                }
	            }
	            else
	            {
	                echo json_encode(
	                    array("statusCode"=>1, 
	                    "Message"=>"something is wrong! Try Again later!"
	                    ));
	                die();
	            }
            }
            else
            {
            	echo json_encode(
	                array("statusCode"=>4, 
	                "Message"=>"Admin Don't have sufficient balance! Try Again Later!"
	                ));
	            die();
            }
        }
        else
        {
            echo json_encode(
                array("statusCode"=>0, 
                "Message"=>"Something is wrong!, Try again later"
                ));
            die();
        }
    }

    
}

